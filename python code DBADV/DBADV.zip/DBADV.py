import numpy as np
from scipy.spatial.distance import pdist, squareform
import scipy.stats as st


def binary_search_perplexity(X, perplexity):
    n = len(X)
    sum_X = np.sum(np.square(X), 1)
    D = np.add(np.add(-2 * np.dot(X, X.T), sum_X).T, sum_X)
    beta = np.ones((n, 1))
    logU = np.log(perplexity)
    tol = 1e-5

    for i in range(n):
        betamin = -np.inf
        betamax = np.inf
        Di = D[i, np.concatenate((np.r_[0:i], np.r_[i + 1:n]))]

        P = np.exp(-Di.copy() * beta[i])
        sumP = sum(P)
        H = np.log(sumP) + beta[i] * np.sum(Di * P) / sumP

        Hdiff = H - logU
        tries = 0
        while np.abs(Hdiff) > tol and tries < 50:

            if Hdiff > 0:
                betamin = beta[i].copy()
                if betamax == np.inf or betamax == -np.inf:
                    beta[i] = beta[i] * 2.
                else:
                    beta[i] = (beta[i] + betamax) / 2.
            else:
                betamax = beta[i].copy()
                if betamin == np.inf or betamin == -np.inf:
                    beta[i] = beta[i] / 2.
                else:
                    beta[i] = (beta[i] + betamin) / 2.

            P = np.exp(-Di.copy() * beta[i])
            sumP = sum(P)
            H = np.log(sumP) + beta[i] * np.sum(Di * P) / sumP
            Hdiff = H - logU
            tries += 1

    sigma = np.sqrt(1 / beta)
    return sigma


def DBADV(X, perplexity, MinPts, probability):
    c = 0
    n = len(X)
    label = np.ones((n, 1), dtype=int) * -1
    D = squareform(pdist(X, 'euclidean'))
    visited = np.zeros((n, 1), dtype=bool)
    sigma = binary_search_perplexity(X, perplexity)

    F = np.zeros((n, 1))
    for i in range(n):
        F[i] = st.norm.ppf(probability, loc=0, scale=sigma[i])

    F_i = np.repeat(F, n).reshape(n, n)
    F_j = np.transpose(F_i)
    neighborhoods_mutual = (D <= F_i) & (D <= F_j)

    for i in range(n):
        if ~visited[i]:
            visited[i] = True
            neighbors = np.where(neighborhoods_mutual[i])[0]
            if neighbors.size >= MinPts:
                label[i] = c
                k = 0
                while True:
                    j = neighbors[k]
                    if ~visited[j]:
                        visited[j] = True
                        neighbors2 = np.where(neighborhoods_mutual[j])[0]
                        if neighbors2.size >= MinPts:
                            neighbors = np.append(neighbors, neighbors2)
                    if label[j] == -1:
                        label[j] = c
                    k = k + 1
                    if k > neighbors.size - 1:
                        break
                c = c + 1
    return label
