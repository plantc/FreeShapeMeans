/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comparisonMethods;

import boostmeans.IO;
import weka.core.Instances;

/**
 *
 *
 */
public class DbscanMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        IO ea = new IO();
        
       //String dir = "twoMoons5000Scatter015.mat"; //löuft nicht mit seed 1: 0.98.24, gut mit seed 5: 0.9829
 //String dir = "seeds.arff"; 
 String dir = "soybean-large.arff"; 
//        String dir = "dist3_4.mat";
//       
//        double[][] data = ea.readMatlabMatrix(dir, "data");
//        int[] labels = ea.readLabels(dir, "labels");
        
        
         //String dir = "statlog-image-segmentation.arff"; 
         
         // String dir = "leaf.arff"; 
          
          //String dir = "statlog-landsat-satellite.arff"; 
          
//          String dir = "zoo.arff"; 
//         
          Instances inst = ea.readArffFile(dir);
          inst.setClassIndex(0);
          double[][] data = ea.getDataFromArff(inst);
         data = ea.scaleData(data);
          int[] labels = ea.getClassLabelFromArff(inst);
//        
         

        DataObject[] dd = new DataObject[data.length];
        for (int i = 0; i < data.length; i++) {
            dd[i] = new DataObject(data[i], i, labels[i]);

        }
        DB db = new DB(dd);
        Dbscan dbscan = new Dbscan();
        dbscan.NormalDbscan(db, 0.002, 10);
        int[] ids = dbscan.getClust_id();
        double[][] idsd = new double[ids.length][1];
        for (int i = 0; i < idsd.length; i++) {
            idsd[i][0] = ids[i];
        }
        ea.writeDoubleToMatlab(idsd, "id", "idsDbscan");

    }

}
