/*
 * Cluster.java
 *
 * Created on 03 October 2005, 16:14
 */

package comparisonMethods;

/**
 *
 * @author Administrator
 */
public class Cluster {
    public int ID;
    double cost;
    boolean subspaceCluster;
    double[][] eigenVector;
    double[] eigenValue;
    double[] invEigenValue;
    double[] lb;
    double[] ub;
    public double[] mean;
    int dim;
    int numObj;
    
    public Cluster(){
       
        
    }
    
    public Cluster(int id){
        this.ID = id;
    }
    
   
    /** Creates a new instance of Cluster */
    public Cluster(double[] mean, int id, int dim) {
        //this.eigenVector = eigenVector;
        this.dim = dim;
        this.mean = mean;
        this.ID = id;
    }
    
    public Cluster(int id, int numObj, int dim){
        this.dim = dim;
        this.ID = id;
        this.numObj = numObj;
    }
    
    public void setNumObj(int num){
        numObj = num;
    }
    
    public void setEigenVector(double[][] ev){
        eigenVector = ev;
    }
    
    public void setEigenValue(double[] ew){
        eigenValue = ew;
        double v = 1.0;
        double magic = 10.0;
        invEigenValue = new double[eigenValue.length];
        for(int i = 0; i < invEigenValue.length; i++)
            //if(eigenValue[i] < 1/magic)
              //  invEigenValue[i] = magic;
            //else 
                invEigenValue[i] = Math.sqrt(1/eigenValue[i]);
         for(int i = 0; i < eigenValue.length; i++)
              v*= Math.pow(invEigenValue[i], 1.0/dim);
         for(int i = 0; i < eigenValue.length; i++)
              invEigenValue[i]/=v;
              
         // TEST TEST enhance Eigenvalues
         for (int i=0 ; i<eigenValue.length; i++)
              invEigenValue[i] = Math.pow (invEigenValue[i], 2.5) ;
    }
    
    public void setMean(double[] mean){
        this.mean = mean;
    }
    
    
    
    
    
}
