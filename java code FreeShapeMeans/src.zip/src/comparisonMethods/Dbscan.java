/*
 * Dbscan.java
 *
 * Created on 13. November 2005, 20:58
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package comparisonMethods;


/**
 *
 * 
 */

 
    
    
 

public class Dbscan {
    static int nfeature; // dim
    
    static int N; // Zahl Datenobjekte
    
     int[] clust_id; // clusterID
    
    static int cur_id = 0;
    
    
    public Dbscan() {
    }

    public int[] getClust_id() {
        return clust_id;
    }
    
    
    
    //    einfacher DBSCAN
    public void NormalDbscan(DB db, double epsilon, int min_pts){
        double eps_sq = Math.pow(epsilon, 2);
//        System.out.print("Performing DBSCAN ... ");
//        System.out.println();
        N = db.store.length;
        nfeature = db.store[0].coord.length;
        clust_id = new int[N];
        int[] tempArray = new int[N];
        cur_id = 1;
        int numCoreObj = 0;
        int noise = 0;
        int clusterCount = 0;  //wieviele Punkte im Cluster
        for (int i = 0; i < N; i++) { // Schleife über alle Datenobjekte
            if (clust_id[i] == 0) {
                boolean wasCluster = false;
                int tempArrayCt = 1;
                tempArray[0] = i;
                for (int i2 = 0; i2 < tempArrayCt; i2++) {
                    int count = 0;
                    for (int j = 0; j < N; j++) {   //zähle in count, wieviele pkte in eps-Umgebung
                        DataObject first = db.store[tempArray[i2]];
                        DataObject second = db.store[j];
                        if (first.distance(second) <= eps_sq) {
                            count++;
                        }
                    }//j
                    if (count >= min_pts) { // coreObject gefunden
                        //clusterCount++;
                        DataObject akt = db.store[tempArray[i2]];
                        wasCluster = true;
                        clust_id[tempArray[i2]] = cur_id;
                        akt.clusterID = cur_id;
                        numCoreObj++;
                        for (int j = 0; j < N; j++) { // al le Obj aufsammeln
                            DataObject second = db.store[j];
                            if (clust_id[j] == 0
                                    && akt.distance(second) <= eps_sq) { // sind
                                // das
                                // Randpunkte?
                                clust_id[j] = cur_id;
                                clusterCount++;
                                second.clusterID = cur_id;
                                tempArray[tempArrayCt] = j;
                                tempArrayCt++;
                            }// if
                        }// for
                    }// if minPts
                } // for sammle alle pkte von aktuellem Cluster auf
                if (wasCluster) { // neuen Cluster beginnen
                   // System.out.println("Cluster " + cur_id + " : " + clusterCount);
                    clusterCount = 0;
                    cur_id++;
                }
            }// if clust_id
        }
        noise(db);
    }
    
    
    
    
    public void noise(DB db) {
        int noiseCounter = 0;
        for (int i = 0; i < db.store.length; i++) {
            if (db.store[i].clusterID == 0) {
                noiseCounter++;
            }
        }
        double noisePerc = (double) noiseCounter / (double) db.store.length;
       // System.out.println("Noise " + noisePerc);
    }
    
        
    
    
}
    

