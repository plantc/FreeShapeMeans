/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boostmeans;

/**
 *
 * @author plantc59cs
 */
public class BoostMeansMain {

    /**
     * 
     */
    public static void main(String[] args) {
        // TODO code application logic here
        IO ea = new IO();
        // String dir = "twoMoons5000.mat";
        //String dir = "twoMoonsOneGaussian.mat";
         String dir = "twoMoons5000scatter015.mat"; //perfekt mit seed 5
        //String dir = "outlier2000.mat";
        //String dir = "threeGaussians3000.mat";
        // String dir = "random.mat";
        //String dir = "syn3.mat"; //kreis
        //String dir = "syn2.mat"; //ebene mit 2 clustern
        // String dir = "syn4.mat"; //kreis sparse
        //double[][] data = ea.readMatlabMatrix(dir, "x");
        double[][] data = ea.readMatlabMatrix(dir, "data");
        int[] labels = ea.readLabels(dir, "labels");
        //int[] labels = ea.readLabels(dir, "trueLabel");

        int seed = 5;
        int k = 2;
        int nRep = 1;

        int[] numRep = new int[k];
        for (int i = 0; i < numRep.length; i++) {
            numRep[i] = nRep;
        }

        KMeans km = new KMeans(k, data);
        //int[] ll = km.run(0);
        int[] ll = km.randomInit(1);
        ea.displayClusters(data, labels, ll, new double[data.length], "random");
        //public FreeShapeMeans(int[] ids, double[][] data, int k, int numTry, int seed) {
        //BoostMeans bm = new FreeShapeMeans(ll, data, 2, 100, 1);
        //public FreeShapeMeans(int[] ids, double[][] data, int k, int reps, int numTry, int seed)
        //CompleteEnumeration bm = new CompleteEnumeration(ll, data, k, 7, 1, 1);

       FreeShapeMeans bm = new FreeShapeMeans(ll, data, k, numRep, 1, seed);
        //BoostMeansAvg bm = new BoostMeansAvg(ll, data, k, numRep, 1, 1);
        //bm.setRepPerCluster(0.01);
        // BoostMeansAvg bm = new BoostMeansAvg(ll, data, k, numRep, 1, 1);

        int iter = 500;
        for (int i = 0; i < iter; i++) {
            if (i % 10 == 0) {
                double[] m = bm.checkObj();
                if (m.length > 1) {
                    System.out.println(i + " " + m[0] + " " + m[1] + " " + m[2]);
                } else {
                    System.out.println(i + " " + m[0]);
                }
                bm.setRepPerCluster(0.01);
                //System.out.println(bm.reps[0] + " " + bm.reps[1]);
                // System.out.println(bm.j);

            }
            bm.immediateUpdate();

        }

        BMResult res = new BMResult(bm.getIds(), bm.getCertainty(), bm.getReps(), bm.getClusterQuality(), bm.getClusterCount(), bm.checkObj()[0], bm.seed);
        BMResult.writeToFile("initAvg", res);

        ////        //System.out.println("clusterChanged " + clusterChanged);
        ea.displayClusters(data, labels, bm.getIds(), bm.getCertainty(), "init");
        // ea.displayCertainty(data, labels, bm.getIds(), bm.getCertainty());

        System.out.println("refinement");

        nRep = 20;
        for (int i = 0; i < numRep.length; i++) {
            numRep[i] = nRep;
        }

        //numRep[2] = 1;

        //BoostMeans bmRefine = new FreeShapeMeans(bm.getIds(), data, k, numRep, 50, 1);
        BoostMeansAvg bmRefine = new BoostMeansAvg(bm.getIds(), data, k, numRep, 10, 1);
        //bm.setRepPerCluster(0.01);

        // BoostMeansAvg bmRefine = new BoostMeansAvg(bm.getIds(), data, k, numRep, 100, 1);
        int iterRefine = 100;
        for (int i = 0; i <= iterRefine; i++) {
            if (i % 10 == 0) {
                double[] m = bmRefine.checkObj();
                // bmRefine.checkRepPerCluster();
                // System.out.println(bmRefine.reps[0] + " " + bmRefine.reps[1]);
                if (m.length > 1) {
                    System.out.println(i + " " + m[0] + " " + m[1] + " " + m[2]);
                } else {
                    System.out.println(i + " " + m[0]);
                }
                //  System.out.println(bmRefine.j);
                 // bm.setRepPerCluster(0.01);
            }
            bmRefine.immediateUpdate();

        }
        // ea.displayBorder(1000, data, bmRefine);

//        System.out.println("clusterChanged " + clusterChanged);
        ea.displayClusters(data, labels, bmRefine.getIds(), bmRefine.getCertainty(), "result");
        //ea.displayCertainty(data, labels, bmRefine.getIds(), bmRefine.getCertainty());
        ea.saveforNMI(bmRefine.getIds(), labels);
         BMResult.writeToFile("refineAvg", res);

    }

}
