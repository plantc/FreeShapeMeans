/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boostmeans;

import com.jmatio.io.MatFileReader;
import com.jmatio.io.MatFileWriter;
import com.jmatio.types.MLDouble;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.Vector;
import weka.core.Instances;

/**
 *
 * 
 */
public class IO {

    public Instances readArffFile(String filePath) {

        //System.out.println("loading dataset...");
        File file = new File(filePath);

        try {
            FileReader fileReader = new FileReader(file);
            Instances instances = new Instances(fileReader);
            instances.setClassIndex(instances.numAttributes() - 1);
            //System.out.println(instances.numInstances() + " instances with "
            //		+ instances.numAttributes() + " attributes loaded.");
            fileReader.close();
            return instances;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public double[][] getDataFromArff(Instances inst) {
        double[][] data = new double[inst.numInstances()][inst.numAttributes() - 1];
        for (int i = 0; i < inst.numInstances(); i++) {
            int count = 0;
            for (int j = 0; j < inst.numAttributes(); j++) {
                if (j != inst.classIndex()) {
                    data[i][count] = inst.instance(i).value(j);
                    count++;
                }
            }
        }
        return data;
    }

    public int[] getClassLabelFromArff(Instances inst) {
        int[] label = new int[inst.numInstances()];
        for (int i = 0; i < label.length; i++) {
            label[i] = (int) inst.instance(i).value(inst.classIndex());
        }
        return label;
    }

    public DataObject[] coordClassCluster(double[][] coord, double[][] labels, int[] ids) {
        DataObject[] d = new DataObject[coord.length];
        for (int i = 0; i < d.length; i++) {
            d[i] = new DataObject(coord[i], (int) labels[i][0], ids[i], i);
        }
        return d;
    }

    public double[][] combine(double[][] a, double[][] b) {
        double[][] r = new double[a.length + b.length][a[0].length];
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                r[i][j] = a[i][j];
            }
        }
        int counter = 0;
        for (int i = a.length; i < r.length; i++) {
            for (int j = 0; j < b[counter].length; j++) {
                r[i][j] = b[counter][j];
            }
            counter++;
        }
        return r;
    }

    public DataObject[] appendTestObj(DataObject[] train, double[][] test) {
        DataObject[] comb = new DataObject[train.length + test.length];
        for (int i = 0; i < train.length; i++) {
            comb[i] = new DataObject(train[i]);
        }
        int counter = 0;
        int samplingID = 100;
        for (int i = train.length; i < comb.length; i++) {
            comb[i] = new DataObject(test[counter], samplingID, samplingID, train.length + counter);
            counter++;
        }
        return comb;
    }

    public DataObject[] appendTestObj(DataObject[] train, double[][] test, int[] idTest) {
        DataObject[] comb = new DataObject[train.length + test.length];
        for (int i = 0; i < train.length; i++) {
            comb[i] = new DataObject(train[i]);
        }
        int counter = 0;
        int samplingID = 100;
        for (int i = train.length; i < comb.length; i++) {
            comb[i] = new DataObject(test[counter], samplingID, idTest[counter], train.length + counter);
            counter++;
        }
        return comb;
    }

    //assumes that the last attribute is the class attribute
    public double[][] getDataMatrix(Instances instances) {
        double[][] dd = new double[instances.numInstances()][instances.numAttributes() - 1];
        for (int i = 0; i < instances.numInstances(); i++) {
            for (int j = 0; j < instances.numAttributes() - 1; j++) {
                dd[i][j] = instances.instance(i).value(j);
            }
        }
        return dd;
    }

    //res[0]: min, res[1]: max
    public double[][] displayRange(double epsilon, double[][] data) {
        double[][] res = new double[2][2];
        int d = data[0].length;
        int n = data.length;
        for (int i = 0; i < d; i++) {
            res[i][0] = Double.MAX_VALUE;
            res[i][1] = -Double.MAX_VALUE;
        }
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < d; j++) {
                if (data[i][j] < res[j][0]) {
                    res[j][0] = data[i][j];
                }
                if (data[i][j] > res[j][1]) {
                    res[j][1] = data[i][j];
                }
            }
        }
        for (int i = 0; i < d; i++) {
            res[i][0] -= epsilon;
            res[i][1] += epsilon;
        }
        return res;
    }

    public void scale(double[][] data) {
        double nMin = 0;
        double nMax = 60;
        int n = data.length;
        int d = data[0].length;
        double[] min = new double[d];
        for (int i = 0; i < d; i++) {
            min[i] = Double.MAX_VALUE;
        }
        double[] max = new double[d];
        for (int i = 0; i < d; i++) {
            max[i] = -Double.MAX_VALUE;
        }
        for (int i = 0; i < data.length; i++) {
            for (int j = 0; j < d; j++) {
                if (data[i][j] < min[j]) {
                    min[j] = data[i][j];
                }
                if (data[i][j] > max[j]) {
                    max[j] = data[i][j];
                }
            }
        }
        double[][] datan = new double[n][d];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < d; j++) {
                datan[i][j] = (data[i][j] - min[j]) / (max[j] - min[j]);
                datan[i][j] *= nMax;
            }
        }
        writeDoubleToMatlab(datan, "data", "scaled");

    }

    public double[][] scaleData(double[][] data) {
        double nMin = 0;
        double nMax = 100;
        int n = data.length;
        int d = data[0].length;
        double[] min = new double[d];
        for (int i = 0; i < d; i++) {
            min[i] = Double.MAX_VALUE;
        }
        double[] max = new double[d];
        for (int i = 0; i < d; i++) {
            max[i] = -Double.MAX_VALUE;
        }
        for (int i = 0; i < data.length; i++) {
            for (int j = 0; j < d; j++) {
                if (data[i][j] < min[j]) {
                    min[j] = data[i][j];
                }
                if (data[i][j] > max[j]) {
                    max[j] = data[i][j];
                }
            }
        }
        double[][] datan = new double[n][d];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < d; j++) {
                datan[i][j] = (data[i][j] - min[j]) / (max[j] - min[j]);
                datan[i][j] *= 100;
            }
        }
        return datan;

    }

    public double[] scaleObj(double[] obj) {
        double[] min = new double[obj.length];
        for (int i = 0; i < min.length; i++) {
            min[i] = (double) 1 / (double) (i + 2);
        }

        double[] res = new double[obj.length];
        for (int i = 0; i < res.length; i++) {
            res[i] = (obj[i] - min[i]) / (1 - min[i]);
        }
        return res;
    }

    public double scaleObjNew(double obj, int[] clusterID) {
        Arrays.sort(clusterID);
        Vector<Integer> clusters = new Vector<Integer>();
        for (int i = 0; i < clusterID.length; i++) {
            if (!clusters.contains(clusterID[i])) {
                clusters.add(clusterID[i]);
            }
        }
        int numClusters = clusters.size();
        int[] clusterSize = new int[numClusters];

        for (int i = 0; i < clusters.size(); i++) {
            int curId = clusters.elementAt(i);
            for (int j = 0; j < clusterID.length; j++) {
                if (clusterID[j] == curId) {
                    clusterSize[i]++;
                }
            }
        }
        int maxClusterSize = -1;
        for (int i = 0; i < clusterSize.length; i++) {
            if (clusterSize[i] > maxClusterSize) {
                maxClusterSize = clusterSize[i];
            }
        }
       // double[] res = new double[clusterID.length];
        double min = (double) maxClusterSize / (double) clusterID.length;

       // for (int i = 0; i < res.length; i++) {
         double   res  = (obj - min) / (1 - min);
        //}
        return res;

    }

    public void addUniformNoise(double[][] data, int[] labels, double percentage, int seed) {
        Random r = new Random(seed);
        int numNoiseObj = (int) Math.round(data.length * percentage);
        double[][] dataN = new double[data.length + numNoiseObj][data[0].length];
        double[][] labelsN = new double[data.length + numNoiseObj][1];
        int maxLabel = -1;
        double[] min = new double[data[0].length];
        double[] max = new double[data[0].length];
        for (int i = 0; i < min.length; i++) {
            min[i] = Double.MAX_VALUE;
            max[i] = -Double.MAX_VALUE;
        }
        for (int i = 0; i < data.length; i++) {
            if (labels[i] > maxLabel) {
                maxLabel = labels[i];
            }
            labelsN[i][0] = labels[i];
            for (int j = 0; j < data[0].length; j++) {
                dataN[i][j] = data[i][j];
                if (data[i][j] < min[j]) {
                    min[j] = data[i][j];
                }
                if (data[i][j] > max[j]) {
                    max[j] = data[i][j];
                }
            }
        }
        for (int i = 0; i < numNoiseObj; i++) {
            labelsN[data.length + i][0] = maxLabel + 1;
            for (int j = 0; j < dataN[0].length; j++) {
                double rr = r.nextDouble() * (max[j] - min[j]);
                dataN[data.length + i][j] = rr + min[j];
            }
        }
        writeDoubleToMatlab(dataN, "data", "dataNoise");
        writeDoubleToMatlab(labelsN, "labels", "labelsNoise");
    }

    public void displayBorder(int resolution, double[][] data, KMeans km) {
        double[][] id = new double[resolution][resolution];
        double[][] pdf = new double[resolution][resolution];
        //double[][] certainty = new double[resolution][resolution];
        double[] stepSize = new double[2];
        double[][] gridSize = displayRange(10, data);
        for (int i = 0; i < 2; i++) {
            stepSize[i] = (gridSize[i][1] - gridSize[i][0]) / (double) resolution;
        }
        double[] start = new double[2];
        for (int i = 0; i < 2; i++) {
            start[i] = gridSize[i][0] + stepSize[i] / (double) 2;
        }
        double var = km.getVar();
        System.out.println("var: " + var);
        //double var = 200;
        for (int i = 0; i < resolution; i++) {
            for (int j = 0; j < resolution; j++) {
                double[] akt = new double[2];
                akt[0] = start[0] + i * stepSize[0];
                akt[1] = start[1] + j * stepSize[1];
                //determine the cluster id of this point
                int ido = km.getClusterId(akt);
                id[i][j] = ido;
                pdf[i][j] = km.getPDF(akt, ido, var);
                //certainty[i][j] = idCertainty[1];
            }
        }
        writeDoubleToMatlab(id, "id", "id");
        writeDoubleToMatlab(pdf, "pdf", "pdf");
        //writeDoubleToMatlab(certainty, "cert", "cert");
    }

    //ids and labels start with one
    public void saveforNMI(int[] ids, int[] labels) {
        double[][] labelsd = new double[labels.length][1];
        double[][] idsd = new double[ids.length][1];
        for (int i = 0; i < ids.length; i++) {
            labelsd[i][0] = labels[i] + 1;
            idsd[i][0] = ids[i];
        }
        writeDoubleToMatlab(idsd, "ids", "ids");
        writeDoubleToMatlab(labelsd, "labels", "labels");
    }

    public void displayBorder(int resolution, double[][] data, BoostMeansAvg bm) {
        double[][] id = new double[resolution][resolution];
        //double[][] certainty = new double[resolution][resolution];
        double[][] pdf = new double[resolution][resolution];
        double[] stepSize = new double[2];
        //0.7 is good for twoMoons, 40 für 3 Gaussians
        double[][] gridSize = displayRange(10, data);
        for (int i = 0; i < 2; i++) {
            stepSize[i] = (gridSize[i][1] - gridSize[i][0]) / (double) resolution;
        }
        double[] start = new double[2];
        for (int i = 0; i < 2; i++) {
            start[i] = gridSize[i][0] + stepSize[i] / (double) 2;
        }

        Random r = new Random(2);
        double var = bm.j / (double) (bm.numObj - 1);
        System.out.println(var);
        var = 34.6;
        int numT = 100;

        for (int i = 0; i < resolution; i++) {
            for (int j = 0; j < resolution; j++) {
                double[] akt = new double[2];
                akt[0] = start[0] + i * stepSize[0];
                akt[1] = start[1] + j * stepSize[1];
                //determine the cluster id of this point
                double[] idpdf = bm.assignmentPDF(akt, numT, var, r);
                id[i][j] = idpdf[0];
                //certainty[i][j] = idCertainty[1];
                pdf[i][j] = idpdf[1];
            }
        }

        writeDoubleToMatlab(pdf, "pdf", "pdf");
        writeDoubleToMatlab(id, "id", "id");
        ///writeDoubleToMatlab(certainty, "cert", "cert");

        System.out.println("results written.");
    }

    public void displayBorder(int resolution, double[][] data, FreeShapeMeans bm) {
        double[][] id = new double[resolution][resolution];
        double[][] certainty = new double[resolution][resolution];
        double[][] pdf = new double[resolution][resolution];
        double[] stepSize = new double[2];
        //0.7 is good for twoMoons, 40 für 3 Gaussians
        double[][] gridSize = displayRange(0.7, data);
        for (int i = 0; i < 2; i++) {
            stepSize[i] = (gridSize[i][1] - gridSize[i][0]) / (double) resolution;
        }
        double[] start = new double[2];
        for (int i = 0; i < 2; i++) {
            start[i] = gridSize[i][0] + stepSize[i] / (double) 2;
        }
        //only determine variance
        Random r = new Random(2);
        double var = 0.0;
        for (int i = 0; i < bm.numObj; i++) {
            double[] idCertainty = bm.getIdCertainty(bm.data[i], r, -1);
            var += idCertainty[idCertainty.length - 1];
        }

        var /= bm.numObj;
        System.out.println("var: " + var);
        //  r = new Random(2);

        for (int i = 0; i < resolution; i++) {
            for (int j = 0; j < resolution; j++) {
                double[] akt = new double[2];
                akt[0] = start[0] + i * stepSize[0];
                akt[1] = start[1] + j * stepSize[1];
                //determine the cluster id of this point
                double[] idCertainty = bm.getIdCertainty(akt, r, var);
                id[i][j] = idCertainty[0];
                certainty[i][j] = idCertainty[1];
                pdf[i][j] = idCertainty[2];
            }
        }

        writeDoubleToMatlab(pdf, "pdf", "pdf");
        writeDoubleToMatlab(id, "id", "id");
        writeDoubleToMatlab(certainty, "cert", "cert");

        System.out.println("results written.");
    }

    public boolean saveArffFile(String path, Instances instances) {

        System.out.println("saving dataset: " + path);
        File file = new File(path);

        try {
            FileWriter fileWriter = new FileWriter(file);
            fileWriter.write("@relation bla\n\n");

            for (int i = 0; i < instances.numAttributes(); i++) {
                fileWriter.write(instances.attribute(i).toString() + "\n");
            }
            fileWriter.write("\n");
            fileWriter.write("@data\n");
            for (int i = 0; i < instances.numInstances(); i++) {
                fileWriter.write(instances.instance(i).toString() + "\n");
            }
            fileWriter.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return true;
    }

    public int[] readLabels(String dir, String vName) {
        double[][] labels = readMatlabMatrix(dir, vName);
        int[] res = new int[labels.length];
        for (int i = 0; i < res.length; i++) {
            res[i] = (int) labels[i][0];
        }
        return res;
    }

    public void printConfusionMatrix(int[] classID, int[] clusterID) {
        Arrays.sort(classID);
        Arrays.sort(clusterID);
        Vector<Integer> clusters = new Vector<Integer>();
        for (int i = 0; i < clusterID.length; i++) {
            if (!clusters.contains(clusterID[i])) {
                clusters.add(clusterID[i]);
            }
        }
        int numClusters = clusters.size();

        Vector<Integer> classes = new Vector<Integer>();
        for (int i = 0; i < clusterID.length; i++) {
            if (!classes.contains(clusterID[i])) {
                classes.add(clusterID[i]);
            }
        }
        int numClasses = classes.size();

        int[] classSize = new int[numClasses];
        int[] clusterSize = new int[numClusters];
        int[] classLabel = new int[numClasses];
        int[] clusterLabel = new int[numClusters];

        for (int i = 0; i < clusters.size(); i++) {
            int curId = clusters.elementAt(i);
            clusterLabel[i] = curId;
            for (int j = 0; j < clusterID.length; j++) {
                if (clusterID[j] == curId) {
                    clusterSize[i]++;
                }
            }
        }

        for (int i = 0; i < classes.size(); i++) {
            int curId = classes.elementAt(i);
            classLabel[i] = curId;
            for (int j = 0; j < classID.length; j++) {
                if (classID[j] == curId) {
                    classSize[i]++;
                }
            }
        }

        int[][] conf = new int[numClusters][numClasses];

        for (int i = 0; i < clusterLabel.length; i++) {
            //   for (int j = 0; j < numClasse; j++) {
            System.out.println("cluster " + clusterLabel[i] + " " + clusterSize[i] + "----------");
            for (int k = 0; k < classLabel.length; k++) {
                int count = 0;
                int curId = classLabel[k];
                for (int l = 0; l < clusterID.length; l++) {
                    if (clusterID[l] == clusterLabel[i] && classID[l] == curId) {
                        count++;
                    }
                }
                System.out.println("class " + classLabel[k] + " " + count + " of " + classSize[k]);
            }
        }
        // }
    }

    public void displayCertainty(double[][] d, int[] classId, int[] clusterId, double[] c) {
        DataObject[] dd = new DataObject[d.length];
        for (int i = 0; i < dd.length; i++) //public DataObject(double[] coord, int clusterID, double certainty, int classID, int number) {
        {
            dd[i] = new DataObject(d[i], clusterId[i], c[i], classId[i], i);
        }
        VisuCost vi = new VisuCost(dd, c, "clustering");
        vi.setSize(700, 700);
        vi.setVisible(true);
    }

    public void displayClusters(double[][] d, int[] classId, int[] clusterId, double[] c, String title) {
        DataObject[] dd = new DataObject[d.length];
        for (int i = 0; i < dd.length; i++) {
            dd[i] = new DataObject(d[i], clusterId[i], c[i], classId[i], i);
            //dd[i] = new DataObject(d[i], classId[i], clusterId[i], i);
        }
        VisuFigure vi = new VisuFigure(dd, title);
        //VisuInfo vi = new VisuInfo(dd, title);
        vi.setSize(700, 700);
        vi.setVisible(true);
    }

    public void downsampleCluster(double perc, int id, double[][] orig, int[] labels) {
        boolean[] included = new boolean[orig.length];
        Random r = new Random(50);
        int size = 0;
        for (int i = 0; i < orig.length; i++) {
            if (labels[i] != id) {
                included[i] = true;
                size++;
            } else {
                if (r.nextDouble() < perc) {
                    included[i] = true;
                    size++;
                }
            }
        }
        double[][] data = new double[size][orig[0].length];
        double[][] ll = new double[size][1];
        int counter = 0;
        for (int i = 0; i < orig.length; i++) {
            if (included[i]) {
                for (int j = 0; j < orig[0].length; j++) {
                    data[counter][j] = orig[i][j];
                }
                ll[counter][0] = labels[i];
                counter++;
            }
        }
        writeDoubleToMatlab(data, "data", "dataS");
        writeDoubleToMatlab(ll, "labels", "labelsS");

    }

    public double[][] readMatlabMatrix(String dir, String variableName) {
        double[][] data = new double[1][1];

        MatFileReader mfr = null;
        try {
            mfr = new MatFileReader(dir);
        } catch (IOException e) {
        }

        if (mfr != null) {
            data = ((MLDouble) mfr.getMLArray(variableName)).getArray();
        }
        return data;
    }

    public void writeDoubleToMatlab(double[][] d, String variablename, String filename) {
        MLDouble q = new MLDouble(variablename, d);
        ArrayList ll = new ArrayList();
        ll.add(q);
        MatFileWriter mw = new MatFileWriter();
        try {
            String name = filename + ".mat";
            mw.write(name, ll);
        } catch (IOException ex) {
            //     Logger.getLogger(VI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
