/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boostmeans;

/**
 *
 * 
 */
public class KMeansMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        IO ea = new IO();
        //String dir = "twoMoons5000.mat";
       // String dir = "threeGaussians3000.mat";
           String dir = "twoOverlappingGaussians.mat";
        //String dir = "outlier2000.mat";
        // String dir = "random.mat";
        //String dir = "syn3.mat"; //kreis
        //String dir = "syn2.mat"; //ebene mit 2 clustern
        // String dir = "syn4.mat"; //kreis sparse
        //double[][] data = ea.readMatlabMatrix(dir, "x");
        double[][] data = ea.readMatlabMatrix(dir, "data");
        int[] labels = ea.readLabels(dir, "labels");
        //int[] labels = ea.readLabels(dir, "trueLabel");

     
         int k = 2;
        int seed = 12;

        
        
        KMeans km = new KMeans(k, data);
        int[] ll = km.run(seed);
        double[] c = new double[data.length];
        ea.displayClusters(data, labels, ll, c, "result");
        ea.displayBorder(1000, data, km);
        ea.saveforNMI(km.getIds(), labels);
        System.out.println("results written.");

    }

}
