/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boostmeans;

/**
 *
 *
 */
public class CompleteEnumerationMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        IO ea = new IO();
        //String dir = "twoMoons5000.mat";
         // String dir = "random.mat";
        //String dir = "syn3.mat"; //kreis
        //String dir = "syn2.mat"; //ebene mit 2 clustern
        String dir = "small.mat"; //kreis sparse
        //double[][] data = ea.readMatlabMatrix(dir, "x");
        double[][] data = ea.readMatlabMatrix(dir, "data");
        int[] labels = ea.readLabels(dir, "labels");
        //int[] labels = ea.readLabels(dir, "trueLabel");
        
        int k = 2;
        
        KMeans km = new KMeans(k, data);
        //int[] ll = km.run(0);
        int[] ll = km.randomInit(999);
        ea.displayClusters(data, labels, ll, new double[data.length], "random");
        //public BoostMeans(int[] ids, double[][] data, int k, int numTry, int seed) {
        //BoostMeans bm = new BoostMeans(ll, data, 2, 100, 1);
        //public BoostMeans(int[] ids, double[][] data, int k, int reps, int numTry, int seed)
        CompleteEnumeration bm = new CompleteEnumeration(ll, data, k, 2, 1, 1);
        //BoostMeans bm = new BoostMeans(ll, data, k, 7, 1, 1);
        boolean clusterChanged = false;
        int iter = 3;
        for (int i = 0; i < iter; i++) {
            //if(i % 10 == 0){
                double[] m = bm.checkObj();
                
            //}
            double d = bm.roundwiseUpdate();
           // boolean b = bm.immediateUpdate();
           System.out.println(i + " " + m[0] + " " +  m[1] + " " + d); 
           String s = Integer.toString(i);
           ea.displayClusters(data, labels, bm.getIds(), bm.getCertainty(), s);
        }

        ////        //System.out.println("clusterChanged " + clusterChanged);
//        ea.displayClusters(data, labels, bm.getIds(), bm.getCertainty(), "result");
//        ea.displayCertainty(data, labels, bm.getIds(), bm.getCertainty());

    }

}
