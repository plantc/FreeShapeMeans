/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boostmeans;

import java.util.Random;

/**
 *
 * 
 */
public class BoilDownAvg {

    double[][] data;
    int labels[];
    BMResult bestResult;
    int numTry;
    int k;
    int d;
    int numObj;
    int seed;
    Random r;
    static int checkIntervall = 10; //number of steps before check of objective function
    static int backTrackingCounter = 3; //number of steps in backtracking
    static int maxIterations = 1000; //maximmal number of iterations in the algorithm
    static int maxNumRep = 100;
    static double imprSig = 0.1; //check for significant improvement of objective function
    static double initPercentage = 0.01; //how many reps in the initialization phase
    static boolean verbose = true;

    public BoilDownAvg(double[][] data, int k, int seed, int[] labels) {
        this.data = data;
        this.labels = labels;
        numObj = data.length;
        d = data[0].length;
        this.k = k;
        this.seed = seed;
        r = new Random(seed);
        bestResult = new BMResult();
        bestResult.setObj(Double.MAX_VALUE);

    }

    public BoilDownAvg(double[][] data, int k, int seed, int[] labels, BMResult bestResult) {
        this.data = data;
        this.labels = labels;
        numObj = data.length;
        d = data[0].length;
        this.bestResult = bestResult;
        this.k = k;
        this.seed = seed;
        r = new Random(seed);
    }

    public int[] randomInit() {
        KMeans km = new KMeans(k, data);
        return km.randomInit(seed);

    }

    public void run() {

        initalizationPhase();
        refine();
    }

    public void refine() {
        printClusterSummary();
        displayClusters("starting refinement");
         //reduceComplexityGlobal();
        int[] aRep = new int[k];
        for (int i = 0; i < k; i++) {
            aRep[i] = setComplexityBottomUp(i);
            if (aRep[i] == -1) {
                aRep[i] = bestResult.getReps()[i];
            }
        }
       iterateDown(aRep, 3);
        aRep = new int[k];
        for (int i = 0; i < k; i++) {
            aRep[i] = setComplexityBottomUp(i);
            if (aRep[i] == -1) {
                aRep[i] = bestResult.getReps()[i];
            }
        }
         //reduceComplexityGlobal();
        iterateDown(aRep, 5);
         aRep = new int[k];
        for (int i = 0; i < k; i++) {
            aRep[i] = setComplexityBottomUp(i);
            if (aRep[i] == -1) {
                aRep[i] = bestResult.getReps()[i];
            }
        }
        displayCertainty();
        
//        System.out.println("m");
//        aRep = new int[k];
//        for (int i = 0; i < k; i++) {
//            aRep[i] = setComplexityBottomUp(i);
//            if (aRep[i] == -1) {
//                aRep[i] = bestResult.getReps()[i];
//            }
//        }
//        // refinementPhase();

    }

    //returns true if result was best
    private BMResult improvementFixedIter(int[] nReps, int[] currIds, int nTry, int iter) {
        BoostMeansAvg bm = new BoostMeansAvg(currIds, data, k, nReps, nTry, r.nextInt());
        for (int i = 0; i < iter; i++) {
            bm.immediateUpdate();
        }
        BMResult res = new BMResult(bm.getIds(), bm.getCertainty(), bm.getReps(), bm.getClusterQuality(), bm.getClusterCount(), bm.checkObj()[0], bm.seed);
        return res;
    }

    private BMResult improvementFixedIterInit(int[] currIds, int iter) {
        BoostMeansAvg bm = new BoostMeansAvg(currIds, data, k, 1, r.nextInt());
        for (int i = 0; i < iter; i++) {
            bm.setRepPerCluster(initPercentage);
            bm.immediateUpdate();
        }
        BMResult res = new BMResult(bm.getIds(), bm.getCertainty(), bm.getReps(), bm.getClusterQuality(), bm.getClusterCount(), bm.checkObj()[0], bm.seed);
        return res;
    }

    private double checkObj(int[] nReps, int[] currIds) {
        BoostMeansAvg bm = new BoostMeansAvg(currIds, data, k, nReps, r.nextInt());
        return bm.checkObj()[0];
    }

    //adjust cluster wise complexity
    public int setComplexityBottomUp(int cl) {
        System.out.println("so far best cost: " + bestResult.getObj());
        if (verbose) {
            System.out.println("adjusting complexity of cluster " + (cl + 1));
        }
        int[] currReps = new int[k];
        for (int i = 0; i < k; i++) {
            currReps[i] = bestResult.getReps()[i];
        }
        int numRep = 1;
        currReps[cl] = 1;
        boolean improvement = true;
        //baseline cost: costs with one rep
        double bestObj = checkObj(currReps, bestResult.getClId());
        if (verbose) {
            System.out.println("1: " + bestObj);
        }
        int count = 0;
        int bestNumRep = 1;
        while (improvement) {
            numRep++;
            currReps[cl] = numRep;
            double obj = checkObj(currReps, bestResult.getClId());
            if (verbose) {
                System.out.println(numRep + " " + obj);
            }
            if (obj < (bestObj - imprSig)) {
                bestObj = obj;
                count = 0;
                bestNumRep = numRep;
            } else {
                count++;
                if (count == backTrackingCounter) {
                    improvement = false;
                }
            }
        }

        if (bestObj < bestResult.getObj()) {
            bestNumRep = -1;
        }
        if (verbose) {
            System.out.println("bestComplexity: " + bestNumRep);
        }
        return bestNumRep;
    }

    public void reduceComplexityGlobal() {
        boolean improvement = true;
        int[] currReps = new int[k];
        int minReps = Integer.MAX_VALUE;
        for (int i = 0; i < k; i++) {
            currReps[i] = bestResult.getReps()[i];
            if (currReps[i] < minReps) {
                minReps = currReps[i];
            }
        }
        int count = 0;
        while (improvement && minReps > 1) {
            for (int i = 0; i < k; i++) {
                currReps[i]--;
            }
            minReps--;
            double obj = checkObj(currReps, bestResult.getClId());
//            if(verbose)
//                System.out.println(obj);
            if (obj >= bestResult.getObj()) {
                bestResult.setObj(obj);
                bestResult.setReps(currReps);
                count = 0;
            } else {
                count++;
                if (count == backTrackingCounter) {
                    improvement = false;
                }
            }
        }
        if (verbose) {
            System.out.println("After reduceComplexityGlobal:");
            printClusterSummary();
        }

    }

//    //try to reach a new local Optimum of the objective function with this configuration. For all clusters the same number of represenatives. If yes, writes global variables, if no, returns false
//    private boolean localOptimum(int[] nReps, int nTry) {
//        BoostMeans bm = new BoostMeans(ids, data, k, nReps, nTry);
//        int iter = 0;
//        int backtrack = 0;
//        boolean improvement = true;
//        boolean optimumFound = false;
//        while (improvement) {
//            if (iter % checkIntervall == 0) {
//                double[] m = bm.checkObj();
//                if (verbose) {
//                    System.out.println(iter + " " + m[0] + " " + m[1] + " " + m[2]);
//                }
//                if (m[0] > bestObj) {
//                    //copy ids, certainty and bestObj
//                    bestObj = m[0];
//                    for (int i = 0; i < numObj; i++) {
//                        ids[i] = bm.ids[i];
//                    }
//                    for (int i = 0; i < numObj; i++) {
//                        certainty[i] = bm.certainty[i];
//                    }
//                    numTry = nTry;
//                    for (int i = 0; i < k; i++) {
//                        numRep[i] = nReps[i];
//                    }
//                    backtrack = 0;
//                    optimumFound = true;
//                } else {
//                    backtrack++;
//                    if (backtrack > backTrackingCounter) {
//                        improvement = false;
//                    }
//                }
//            }
//            bm.immediateUpdate();
//            iter++;
//            if (iter > maxIterations) {
//                improvement = false;
//            }
//        }
//        return optimumFound;
//    }
    //try to decrease the number of reps for each cluster; without new assignment? and then with new assignment; increase the number of trials
    private void refinementPhase() {
        int aktNumTry = 5;
        iterateDown(bestResult.getReps(), aktNumTry);

    }

    private void displayClusters(String title) {
        IO ea = new IO();
        ea.displayClusters(data, labels, bestResult.getClId(), bestResult.getObjectQuality(), title);

    }
    
     private void displayCertainty() {
        IO ea = new IO();
        ea.displayCertainty(data, labels, bestResult.getClId(), bestResult.getObjectQuality());

    }

    private void initalizationPhase() {
        boolean improvement = true;
        int[] currIds = randomInit();
        int count = 0;
        while (improvement) {
            BMResult b = improvementFixedIterInit(currIds, checkIntervall);
            if (verbose) {
                System.out.println(b.obj);
            }
            if (b.obj < bestResult.getObj()) {
                bestResult = new BMResult(b);
                for (int i = 0; i < numObj; i++) {
                    currIds[i] = b.getClId()[i];
                }
                //System.arraycopy(b.getClId(), 0, currIds, 0, numObj);
                count = 0;
            } else {
                count++;
                if (count == backTrackingCounter) {
                    improvement = false;
                } else {
                    for (int i = 0; i < numObj; i++) {
                        currIds[i] = b.getClId()[i];
                    }
                    // System.arraycopy(b.getClId(), 0, currIds, 0, numObj);
                }
            }
        }
        if (verbose) {
            printClusterSummary();
            BMResult.writeToFile("init", bestResult);
            displayClusters("initialization phase");
        }
        //reduceComplexityGlobal();
    }

    private void iterateDown(int[] nReps, int nTry) {
        boolean improvement = true;
        int[] currIds = new int[numObj];
        for (int i = 0; i < numObj; i++) {
            currIds[i] = bestResult.getClId()[i];
        }
        double currCost = Double.MAX_VALUE;
        int count = 0;
        while (improvement) {
            BMResult b = improvementFixedIter(nReps, currIds, nTry, checkIntervall);
            if (verbose) {
                System.out.println(b.obj);
            }
            if (b.obj < currCost) {
                bestResult = new BMResult(b);
                currCost = b.obj;
                System.arraycopy(b.getClId(), 0, currIds, 0, numObj);
                count = 0;
            } else {
                count++;
                if (count == backTrackingCounter) {
                    improvement = false;
                } else {
                    System.arraycopy(b.getClId(), 0, currIds, 0, numObj);
                }
            }
        }
        if (verbose) {
            printClusterSummary();
            //BMResult.writeToFile("init", bestResult);
            displayClusters("iterated down with numTry " + nTry);
        }
        //reduceComplexityGlobal();

    }

    private void printClusterSummary() {
        System.out.println("---Best result---");
        System.out.println("Obj: " + bestResult.getObj());
        for (int i = 0; i < k; i++) {
            System.out.println("cluster " + (i + 1) + " " + bestResult.getClusterCount()[i] + " objects " + bestResult.getReps()[i] + " reps. Quality: " + bestResult.getClusterQuality()[i]);
        }

    }

//    //use for all clusters the same number of reps and nTry = 1
//    private void intitializationPhaseSelectNumRep() {
//        //select initial best number of reps
//        int nRep = 1;
//        int nTry = 1;
//        int[] reps = new int[k];
//        for (int i = 0; i < reps.length; i++) {
//            reps[i] = nRep;
//        }
//        int[] currIds = new int[numObj];
//        for (int i = 0; i < ids.length; i++) {
//            currIds[i] = ids[i];
//        }
//        boolean improvement = true;
//        int checkIter = 10;
//        int count = 0;
//        while (improvement) {
//            BMResult b = improvementFixedIter(reps, currIds, nTry, checkIter);
//            if (verbose) {
//                System.out.println(nRep + " " + b.obj);
//            }
//            if (b.obj > (bestObj + imprSig)) {
//                bestObj = b.obj;
//                for (int i = 0; i < numObj; i++) {
//                    ids[i] = b.clId[i];
//                }
//                for (int i = 0; i < k; i++) {
//                    numRep[i] = nRep;
//                }
//                count = 0;
//            } else {
//                count++;
//                if (count == backTrackingCounter) {
//                    improvement = false;
//                }
//            }
//            nRep++;
//            for (int i = 0; i < k; i++) {
//                reps[i] = nRep;
//            }
//        }
//        if (verbose) {
//            System.out.println("bestnumRep: " + numRep[0]);
//            displayClusters("initialization phase");
//        }
//    }
}
