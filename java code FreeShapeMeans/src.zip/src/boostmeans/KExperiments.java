/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boostmeans;

import java.awt.image.BufferedImage;
import java.io.File;
import java.util.Random;
import javax.imageio.ImageIO;
import weka.core.Instance;
import weka.core.Instances;

/**
 *
 *
 */
public class KExperiments {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        IO ea = new IO();
        //String dir = "twoMoons5000scatter015Outlier.mat"; //perfekt mit seed 5
        //String dir = "twoMoonsOneGaussianOverlap.mat"; //läuft nicht
        String dir = "twoMoonsOneGaussianLessOverlap.mat"; //löuft nicht mit seed 1: 0.98.24, gut mit seed 5: 0.9829
        //String dir = "twoMoonsOneGaussianLessOverlapNoise1.mat"; //löuft nicht mit seed 1: 0.98.24, gut mit seed 5: 0.9829
        // String dir = "dipTransformedData.mat"; //löuft nicht mit seed 1: 0.98.24, gut mit seed 5: 0.9829

//String dir = "twoOverlappingGaussians.mat"; //nicht gut mit seed 5, gut mit seed 1
        //String dir = "outlier2000.mat"; //perfekt mit seed 1
        //String dir = "twoMoonsOneGaussian.mat"; //perfekt mit seed 1; aber Endlosschleife :-)
        //String dir = "twoMoonsOneGaussianNoise10.mat"; //perfekt mit seed 1; aber Endlosschleife :-)
        //String dir = "threeGaussians3000.mat"; //perfekt mit seed 1; aber Endlosschleife :-)
        // String dir = "random.mat";
        //String dir = "syn3.mat"; //kreis
        //String dir = "syn2.mat"; //ebene mit 2 clustern
        // String dir = "syn4.mat"; //kreis sparse
        //double[][] data = ea.readMatlabMatrix(dir, "x");
        double[][] data = ea.readMatlabMatrix(dir, "data");
        int[] labels = ea.readLabels(dir, "labels");
        //int[] labels = ea.readLabels(dir, "trueLabel");
        //ea.addUniformNoise(data, labels, 0.01, 0);
        //String dir = "banknote-authentication.arff"; 
        //String dir = "iris.arff";
//        String dir = "statlog-image-segmentation.arff";
//        Instances inst = ea.readArffFile(dir);
//
//        //inst.setClassIndex(0);
//        double[][] data = ea.getDataFromArff(inst);
//        data = ea.scaleData(data);
//        int[] labels = ea.getClassLabelFromArff(inst);
          

        int seed = 5;
        int kmin = 2;
        int kmax = 10;
        int kSteps = kmax - kmin + 1;
        int numObj = data.length;
        
        double[] obj = new double[kSteps];
        
        

        int[][] ids = new int[kSteps][numObj];
       

        for (int i = 0; i < kSteps; i++) {
            int kakt = kmin + i;
            BoilDown bd = new BoilDown(data, kakt, seed, labels);
            bd.run();
            ids[i] = bd.bestResult.clId;
            double si = ea.scaleObjNew(bd.bestResult.obj, ids[i]);
            System.out.println(kakt + " " + bd.bestResult.obj + " " + si);
            obj[i] = bd.bestResult.obj;

        }
        
        double[][] objj = new double[obj.length][1];
        for(int i = 0; i < objj.length; i++)
            objj[i][0] = obj[i];
      
        double[][] ll = new double[numObj][1];
        double[][] idss = new double[kSteps][numObj];
        for (int i = 0; i < numObj; i++) {
            ll[i][0] = labels[i];
        }
       
        for (int i = 0; i < kSteps; i++) {
            for (int j = 0; j < numObj; j++) {
                idss[i][j] = ids[i][j];
            }
        }
        
        
        
        ea.writeDoubleToMatlab(objj, "obj", "obj");;
        ea.writeDoubleToMatlab(ll, "labels", "labels");
        ea.writeDoubleToMatlab(idss, "ids", "ids");
      
        ea.writeDoubleToMatlab(data, "data", "data");
        
        System.out.println("scaled globally----------");
        double[] os = ea.scaleObj(obj);
        for(int i = 0; i < os.length; i++)
            System.out.println(os[i]);
        
        

//        ea.displayBorder(1000, data, bd.bestClusterer);
//     ea.displayCertainty(data, labels, bd.bestResult.clId, bd.bestResult.objectQuality);
    }

}
