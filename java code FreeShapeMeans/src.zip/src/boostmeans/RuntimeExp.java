/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boostmeans;

import comparisonMethods.DB;
import comparisonMethods.Dbscan;
import java.time.Duration;
import java.time.Instant;

/**
 *
 * 
 */
public class RuntimeExp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String[] dir = new String[15];
        dir[0] = "data20000.mat";
        dir[1] = "data50000.mat";
        dir[2] = "data100000.mat";
//        dir[3] = "data4000.mat";
//        dir[4] = "data5000.mat";
//        dir[5] = "data6000.mat";
//        dir[6] = "data7000.mat";
//        dir[7] = "data8000.mat";
//        dir[8] = "data9000.mat";
//        dir[9] = "data10000.mat";
//        dir[10] = "data11000.mat";
//        dir[11] = "data12000.mat";
//        dir[12] = "data13000.mat";
//        dir[13] = "data14000.mat";
//        dir[14] = "data15000.mat";

        int k = 2;
//        int nRep = 20;
//
//        int[] numRep = new int[k];
//        for (int i = 0; i < numRep.length; i++) {
//            numRep[i] = nRep;
//        }
        IO ea = new IO();
        int seed = 1;

        for (int i = 0; i < 3; i++) {
            double[][] data = ea.readMatlabMatrix(dir[i], "data");
            int[] labels = new int[data.length];
            BoilDown bd = new BoilDown(data, k, seed, labels);
            Instant start = Instant.now();
            bd.run();
            Instant finish = Instant.now();
            long timeFreeShape = Duration.between(start, finish).getSeconds();

            KMeans km = new KMeans(k, data);
            start = Instant.now();
            int[] ll = km.run(seed);
            finish = Instant.now();
            long timeKM = Duration.between(start, finish).getSeconds();

            comparisonMethods.DataObject[] dd = new comparisonMethods.DataObject[data.length];
            for (int j = 0; j < data.length; j++) {
                dd[j] = new comparisonMethods.DataObject(data[j], j, labels[j]);

            }
            
           start = Instant.now();
            DB db = new DB(dd);
            Dbscan dbscan = new Dbscan();
            dbscan.NormalDbscan(db, 2, 10);
              finish = Instant.now();
             long timeDBSCAN = Duration.between(start, finish).toMillis();
             
             System.out.println(timeFreeShape + " " + timeKM + " " + timeDBSCAN);
            

        }

    }

}
