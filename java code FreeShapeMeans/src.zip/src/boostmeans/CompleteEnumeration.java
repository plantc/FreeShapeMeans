/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boostmeans;

import java.util.Random;

/**
 *
 * 
 */
public class CompleteEnumeration {

    int[] ids;
    double[] certainty; //certainty of assignment to each of the clusters; objective function: maximize it
    double j; //objective function: sum of certainties
    double[][] data;
    int[] clusterCount;
    int reps;
    int k;
    int numTry;
    int seed;
    int numObj;
    int d;
    boolean verbose = true;
    Random r;

    public CompleteEnumeration(int[] ids, double[][] data, int k, int numTry, int seed) {
        this.ids = ids;
        certainty = new double[ids.length];
        this.data = data;
        numObj = data.length;
        d = data[0].length;
        this.k = k;
        this.reps = 1;
        this.numTry = numTry;
        r = new Random(seed);
        clusterCount = new int[k];

    }

    public CompleteEnumeration(int[] ids, double[][] data, int k, int reps, int numTry, int seed) {
        this.ids = ids;
        certainty = new double[ids.length];
        this.data = data;
        numObj = data.length;
        d = data[0].length;
        this.k = k;
        this.reps = reps;
        this.numTry = numTry;
        r = new Random(seed);
        clusterCount = new int[k];

    }

    public int[] getIds() {
        return ids;
    }

    public double[] getCertainty() {
        return certainty;
    }

    static int binomi(int n, int k) {
        if ((n == k) || (k == 0)) {
            return 1;
        } else {
            return binomi(n - 1, k) + binomi(n - 1, k - 1);
        }
    }

    private static String padLeft(String input, int padUpTo) {
        return String.format("%0" + padUpTo + "d", Integer.parseInt(input));
    }

    //first compute obj and then assign all points to the most probable cluster, returns: old value of obj. Updates ids
    public double roundwiseUpdate() {
        int[] idsNew = new int[ids.length];
        double res = 0.0;
//sort out the points of all current clusters as preparation for sampling
        for (int i = 0; i < clusterCount.length; i++) {
            clusterCount[i] = 0;
        }
        for (int i = 0; i < numObj; i++) {
            clusterCount[ids[i] - 1]++;
        }
        int maxClusterCount = -1;
        for (int i = 0; i < clusterCount.length; i++) {
            if (clusterCount[i] > maxClusterCount) {
                maxClusterCount = clusterCount[i];
            }
        }
        int[][] pointsInClusters = new int[k][maxClusterCount];
        int[] counter = new int[k];
        for (int i = 0; i < numObj; i++) {
            pointsInClusters[ids[i] - 1][counter[ids[i] - 1]] = i;
            counter[ids[i] - 1]++;
        }
        int maxNumSubsets = binomi(maxClusterCount, reps);
        // System.out.println(maxNumSubsets);
        Subset[] s = new Subset[k];
        //for every cluster enumerate all possible subsets of size reps and store them in s
        for (int i = 0; i < k; i++) {
            int numSubsets = binomi(clusterCount[i], reps);
            boolean[][] sub = new boolean[numSubsets][clusterCount[i]];
            int c = 0;
            for (int j = 1; j < Math.pow(2, clusterCount[i]); j++) {
                String b = Integer.toBinaryString(j);
                if (Integer.bitCount(j) == reps) {
                    String bp = padLeft(b, clusterCount[i]);
                    char[] bb = bp.toCharArray();
                    boolean[] bbb = new boolean[clusterCount[i]];
                    for (int l = 0; l < bb.length; l++) {
                        if (bb[l] == '1') {
                            bbb[l] = true;
                        }
                    }
                    sub[c] = bbb;
                    c++;
                }
            }
            s[i] = new Subset(sub, new double[sub.length]);
        }
//        for (int m = 0; m < numObj; m++) {
//            //consider all selections of representatives from all k clusters
//            int[] winner = new int[k]; 
//            int count = 0;
//            for (int i = 0; i < k; i++) {
//                for (int j = ) {
//
//                }
//            }
//  
        //compute the distance to all subsets of all clusters. This works only for 2 clusters
        for (int i = 0; i < numObj; i++) {
            if(i == 9)
                System.out.println("m");
                
            //reset dist
            for(int o = 0; o < s.length; o++)
                for(int p = 0; p < s[o].dist.length; p++)
                    s[o].dist[p] = 0.0;
            for (int j = 0; j < k; j++) {
                for (int l = 0; l < s[j].dist.length; l++) {
                    double minDist = Double.MAX_VALUE;
                    for (int m = 0; m < s[j].ss[l].length; m++) {
                        if (s[j].ss[l][m]) {
                            double aktDist = dist(data[i], data[pointsInClusters[j][m]]);
                            if (aktDist < minDist) {
                                minDist = aktDist;
                            }
                        }
                    }
                    s[j].dist[l] = minDist;

                }
            }
            int numSubsets = s[0].dist.length * s[1].dist.length;
            int winner0 = 0;
            int winner1 = 0;
            for (int l = 0; l < s[0].dist.length; l++) {
                for (int m = 0; m < s[1].dist.length; m++) {
                    if (s[0].dist[l] < s[1].dist[m]) {
                        winner0++;
                    } else {
                        winner1++;
                    }
                }
            }
            double p0 = (double) winner0 / (double) numSubsets;
            double p1 = (double) winner1 / (double) numSubsets;

            if (p0 > p1) {
                idsNew[i] = 1;
                if (certainty[i] > p0) {
                    System.err.println(i);
                }
                certainty[i] = p0;
                res += p0 / (double) numObj;
            }
            if (p1 > p0) {
                idsNew[i] = 2;
                if (certainty[i] > p1) {
                    System.err.println(i);
                }
                certainty[i] = p1;
                res += p1 / (double) numObj;
            }
            if (p1 == p0) {
                if (certainty[i] > p0) {
                    System.err.println(i);
                }
                certainty[i] = p0;
                res += p0 / (double) numObj;
                Random rr = new Random(1);
                if (rr.nextDouble() < 0.5) {
                    idsNew[i] = 1;
                } else {
                    idsNew[i] = 2;
                }
            }

            // System.out.println("m");
        }
        for (int i = 0; i < ids.length; i++) {
            ids[i] = idsNew[i];
        }
        return res;

    }

    public boolean immediateUpdate() {
        boolean clusterChanged = false;
        //sort out the points of all current clusters as preparation for sampling
        for (int i = 0; i < clusterCount.length; i++) {
            clusterCount[i] = 0;
        }
        for (int i = 0; i < numObj; i++) {
            clusterCount[ids[i] - 1]++;
        }
        int maxClusterCount = -1;
        for (int i = 0; i < clusterCount.length; i++) {
            if (clusterCount[i] > maxClusterCount) {
                maxClusterCount = clusterCount[i];
            }
        }
        int[][] pointsInClusters = new int[k][maxClusterCount];
        int[] counter = new int[k];
        for (int i = 0; i < numObj; i++) {
            pointsInClusters[ids[i] - 1][counter[ids[i] - 1]] = i;
            counter[ids[i] - 1]++;
        }
        int maxNumSubsets = binomi(maxClusterCount, reps);
        // System.out.println(maxNumSubsets);
        Subset[] s = new Subset[k];
        //for every cluster enumerate all possible subsets of size reps and store them in s
        for (int i = 0; i < k; i++) {
            int numSubsets = binomi(clusterCount[i], reps);
            boolean[][] sub = new boolean[numSubsets][clusterCount[i]];
            int c = 0;
            for (int j = 1; j < Math.pow(2, clusterCount[i]); j++) {
                String b = Integer.toBinaryString(j);
                if (Integer.bitCount(j) == reps) {
                    String bp = padLeft(b, clusterCount[i]);
                    char[] bb = bp.toCharArray();
                    boolean[] bbb = new boolean[clusterCount[i]];
                    for (int l = 0; l < bb.length; l++) {
                        if (bb[l] == '1') {
                            bbb[l] = true;
                        }
                    }
                    sub[c] = bbb;
                    c++;
                }
            }
            s[i] = new Subset(sub, new double[sub.length]);
        }
//        for (int m = 0; m < numObj; m++) {
//            //consider all selections of representatives from all k clusters
//            int[] winner = new int[k]; 
//            int count = 0;
//            for (int i = 0; i < k; i++) {
//                for (int j = ) {
//
//                }
//            }
//  
        //compute the distance to all subsets of all clusters. This works only for 2 clusters
        for (int i = 0; i < numObj; i++) {
            for (int j = 0; j < k; j++) {
                for (int l = 0; l < s[j].dist.length; l++) {
                    double minDist = Double.MAX_VALUE;
                    for (int m = 0; m < s[j].ss[l].length; m++) {
                        if (s[j].ss[l][m]) {
                            double aktDist = dist(data[i], data[pointsInClusters[j][m]]);
                            if (aktDist < minDist) {
                                minDist = aktDist;
                            }
                        }
                    }
                    s[j].dist[l] = minDist;

                }
            }
            int numSubsets = s[0].dist.length * s[1].dist.length;
            int winner0 = 0;
            int winner1 = 0;
            for (int l = 0; l < s[0].dist.length; l++) {
                for (int m = 0; m < s[1].dist.length; m++) {
                    if (s[0].dist[l] < s[1].dist[m]) {
                        winner0++;
                    } else {
                        winner1++;
                    }
                }
            }
            double p0 = (double) winner0 / (double) numSubsets;
            double p1 = (double) winner1 / (double) numSubsets;

            // System.out.println("m");
        }
        //compute the full probability distribution

        return clusterChanged;
    }

//    private double minDist(int o, int p){
//        double minDist = Double.MAX_VALUE;
//        for(int i = 0; i < rep.length; i++){
//            if(rep[i]){
//                double aktDist = dist(data[obj], i)
//            }
//        }
//    }
    //check if the difference between the best cluster and the second best cluster is large enough to be significant
    private boolean enoughInformation(int n, double dev, double alpha) {
        double h = - 1 / (2 * dev * dev) * Math.log(alpha / 2.0);
        int nReq = (int) Math.ceil(h);
        if (nReq < n) {
            return true;
        } else {
            return false;
        }
    }

    private int[] bestSecondBest(double[] d) {
        double max = -Double.MAX_VALUE;
        int[] res = new int[2];
        res[0] = -1;
        res[1] = -1;
        for (int j = 0; j < d.length; j++) {
            if (d[j] > max) {
                max = d[j];
                res[0] = j;
            }
        }
        double secondBest = -Double.MAX_VALUE;
        for (int j = 0; j < d.length; j++) {
            if (d[j] > secondBest && j != res[0]) {
                secondBest = d[j];
                res[1] = j;
            }
        }
        return res;
    }

    public double[] hoeffdingObj(double alpha, double maxT) {
        double[] ch = new double[numObj + 1]; //last entry for the number of points for which no decision can be made
        int nd = 0; //count the points which can not be decided at the significance level
        //sort out the points of all current clusters as preparation for sampling
        for (int i = 0; i < clusterCount.length; i++) {
            clusterCount[i] = 0;
        }
        for (int i = 0; i < numObj; i++) {
            clusterCount[ids[i] - 1]++;
        }
        int maxClusterCount = -1;
        for (int i = 0; i < clusterCount.length; i++) {
            if (clusterCount[i] > maxClusterCount) {
                maxClusterCount = clusterCount[i];
            }
        }
        int[][] pointsInClusters = new int[k][maxClusterCount];
        int[] counter = new int[k];
        for (int i = 0; i < numObj; i++) {
            pointsInClusters[ids[i] - 1][counter[ids[i] - 1]] = i;
            counter[ids[i] - 1]++;
        }
        int stepSize = 10;
        for (int i = 0; i < numObj; i++) {
            boolean done = false;
            int t = 0;
            int[] ass = new int[k];
            double[] assd = new double[k];
            double best;
            while (!done) {
                t += stepSize;
                int[] a = assignments(i, stepSize, pointsInClusters);
                for (int j = 0; j < k; j++) {
                    ass[j] += a[j];
                    assd[j] = ass[j] / (double) t;
                }
                int[] bb = bestSecondBest(assd);
                double eps = assd[bb[0]] - assd[bb[1]];
                best = assd[bb[0]];
                boolean certain = enoughInformation(t, eps, alpha);
                if (certain || t > maxT) {
                    ch[i] = best;
                    if (t > maxT) {
                        ch[i] = 1 / (double) k;
                        ch[ch.length - 1]++;
                    }
                    done = true;
                }
            }

        }
        return ch;
    }

    //29.11. for determination of convergence determine how many experiments must be performed - this is an outdated method. New one is hoeffdingObj
    public double[] hoeffdingCertainty(double alpha, int maxT) {
        double[] ch = new double[numObj + 1];
        int checkInterval = 10;
        int ns = 0;
        //sort out the points of all current clusters as preparation for sampling
        for (int i = 0; i < clusterCount.length; i++) {
            clusterCount[i] = 0;
        }
        for (int i = 0; i < numObj; i++) {
            clusterCount[ids[i] - 1]++;
        }
        int maxClusterCount = -1;
        for (int i = 0; i < clusterCount.length; i++) {
            if (clusterCount[i] > maxClusterCount) {
                maxClusterCount = clusterCount[i];
            }
        }
        int[][] pointsInClusters = new int[k][maxClusterCount];
        int[] counter = new int[k];
        for (int i = 0; i < numObj; i++) {
            pointsInClusters[ids[i] - 1][counter[ids[i] - 1]] = i;
            counter[ids[i] - 1]++;
        }
        //first perform 10 trials then check the difference between the maximum and the second best cluster. Based on this determine how many samples are needed with the hoeffding bound
        for (int i = 0; i < numObj; i++) {
            int[] a = assignments(i, checkInterval, pointsInClusters);
            double[] ac = new double[a.length];
            for (int j = 0; j < k; j++) {
                ac[j] = a[j] / (double) checkInterval;
            }
            double maxAc = -Double.MAX_VALUE;
            int maxIndex = -1;
            for (int j = 0; j < k; j++) {
                if (ac[j] > maxAc) {
                    maxAc = ac[j];
                    maxIndex = j;
                }
            }
            double secondBest = -Double.MAX_VALUE;
            for (int j = 0; j < k; j++) {
                if (ac[j] > secondBest && j != maxIndex) {
                    secondBest = ac[j];
                }
            }
            double eps = maxAc - secondBest;
            double h = - 1 / (2 * eps * eps) * Math.log(alpha / 2.0);
            int numSamples = (int) Math.ceil(h);
            if (numSamples > maxT) {
                numSamples = Math.min(numSamples, maxT);

                //System.out.println("object" + i + " cannot be estimated with sufficient accuracy.");
            }
            if (numSamples > checkInterval) {
                //get new samples
                int[] b = assignments(i, numSamples, pointsInClusters);
                double[] sum = new double[k];
                for (int l = 0; l < k; l++) {
                    sum[l] = (a[l] + b[l]) / (double) (numSamples + checkInterval);
                }

                //check if we are now certain enough
                double maxAcSecond = -Double.MAX_VALUE;
                int maxIndexSecond = -1;
                for (int j = 0; j < k; j++) {
                    if (ac[j] > maxAcSecond) {
                        maxAcSecond = sum[j];
                        maxIndexSecond = j;
                    }
                }
                double secondBestSecond = -Double.MAX_VALUE;
                for (int j = 0; j < k; j++) {
                    if (ac[j] > secondBestSecond && j != maxIndexSecond) {
                        secondBestSecond = sum[j];
                    }
                }
                double epsSecond = maxAcSecond - secondBestSecond;
                double hSecond = - 1 / (2 * epsSecond * epsSecond) * Math.log(alpha / 2.0);
                int numSamplesSecond = (int) Math.ceil(hSecond);
                if (numSamplesSecond > (numSamples + checkInterval)) {
                    ns++;
                }

                ch[i] = maxAcSecond;

            } else {
                ch[i] = maxAc;
            }
        }
        ch[ch.length - 1] = ns;
        return ch;
    }

    public double[] checkObj() {
        double alpha = 0.05;
        int maxT = 1000;
        double[] res = new double[2];
        double[] c = hoeffdingObj(alpha, maxT);
        double m = 0;
        for (int i = 0; i < numObj; i++) {
            m += c[i] / (double) numObj;
        }
        res[0] = m;
        res[1] = c[c.length - 1];
        return res;
    }

    //perform t trials to estimate the assignment certainty of object o
    public int[] assignments(int o, int t, int[][] pointsInClusters) {
        int[] winner = new int[k]; //store how often the corresponding cluster gets the corresponding point
        for (int j = 0; j < t; j++) {
            //sample rep random representatives for each cluster
            double[] minDist = new double[k];
            for (int l = 0; l < k; l++) {
                double[] dist = new double[reps];
                int[] index = new int[reps];
                double minL = Double.MAX_VALUE;
                for (int m = 0; m < reps; m++) {
                    int ii = r.nextInt(clusterCount[l]);
                    int index_rep = pointsInClusters[l][ii];
                    index[m] = index_rep;
                    dist[m] = dist(data[o], data[index_rep]);
                    if (dist[m] < minL) {
                        minL = dist[m];
                    }
                }
                minDist[l] = minL;
            }
            double min = Double.MAX_VALUE;
            int minIndex = -1;
            for (int m = 0; m < minDist.length; m++) {
                if (minDist[m] < min) {
                    min = minDist[m];
                    minIndex = m;
                }
            }
            winner[minIndex]++;
        }
        return winner;
    }

    public boolean iterate() {
        boolean clusterChanged = false;
        //sort out the points of all current clusters as preparation for sampling
        for (int i = 0; i < clusterCount.length; i++) {
            clusterCount[i] = 0;
        }
        for (int i = 0; i < numObj; i++) {
            clusterCount[ids[i] - 1]++;
        }
        int maxClusterCount = -1;
        for (int i = 0; i < clusterCount.length; i++) {
            if (clusterCount[i] > maxClusterCount) {
                maxClusterCount = clusterCount[i];
            }
        }
        int[][] pointsInClusters = new int[k][maxClusterCount];
        int[] counter = new int[k];
        for (int i = 0; i < numObj; i++) {
            pointsInClusters[ids[i] - 1][counter[ids[i] - 1]] = i;
            counter[ids[i] - 1]++;
        }
        //reassignment
        int[] idsNew = new int[numObj];
        double[] certaintyNew = new double[numObj];
        for (int i = 0; i < numObj; i++) {
            int[] winner = new int[k]; //store how often the corresponding cluster gets the corresponding point
            for (int j = 0; j < numTry; j++) {
                //sample rep random representatives for each cluster
                double[] minDist = new double[k];
                for (int l = 0; l < k; l++) {
                    double[] dist = new double[reps];
                    int[] index = new int[reps];
                    double minL = Double.MAX_VALUE;
                    for (int m = 0; m < reps; m++) {
                        int ii = r.nextInt(clusterCount[l]);
                        int index_rep = pointsInClusters[l][ii];
                        index[m] = index_rep;
                        dist[m] = dist(data[i], data[index_rep]);
                        if (dist[m] < minL) {
                            minL = dist[m];
                        }
                    }
                    minDist[l] = minL;
                }
                double min = Double.MAX_VALUE;
                int minIndex = -1;
                for (int m = 0; m < minDist.length; m++) {
                    if (minDist[m] < min) {
                        min = minDist[m];
                        minIndex = m;
                    }
                }
                winner[minIndex]++;
            }
            //make assignment of that point as consensus decision
            int max = -Integer.MAX_VALUE;
            int maxIndex = -1;
            for (int m = 0; m < winner.length; m++) {
                if (winner[m] > max) {
                    max = winner[m];
                    maxIndex = m;
                }
            }
            idsNew[i] = maxIndex + 1;
            certaintyNew[i] = (double) winner[maxIndex] / (double) numTry;
        }
        //update ids and certainties
        j = 0;
        for (int i = 0; i < numObj; i++) {
            if (ids[i] != idsNew[i]) {
                clusterChanged = true;
            }
            ids[i] = idsNew[i];
            certainty[i] = certaintyNew[i];
            j += certainty[i] / (double) numObj;
        }
        if (verbose) {
            System.out.println(j);
        }
        return clusterChanged;
    }

    private double dist(double[] a, double[] b) {
        double dd = 0.0;
        for (int k = 0; k < a.length; k++) {
            dd += (a[k] - b[k]) * (a[k] - b[k]);
        }
        return Math.sqrt(dd);
    }

}
