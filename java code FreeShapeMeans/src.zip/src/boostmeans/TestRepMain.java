/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boostmeans;

/**
 *
 
 */
public class TestRepMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        IO ea = new IO();
        String dir = "twoMoons5000.mat";
        //String dir = "threeGaussians3000.mat";
        // String dir = "random.mat";
        //String dir = "syn3.mat"; //kreis
        //String dir = "syn2.mat"; //ebene mit 2 clustern
        // String dir = "syn4.mat"; //kreis sparse
        //double[][] data = ea.readMatlabMatrix(dir, "x");
        double[][] data = ea.readMatlabMatrix(dir, "data");
        int[] labels = ea.readLabels(dir, "labels");
        //int[] labels = ea.readLabels(dir, "trueLabel");

        int k = 2;
        KMeans km = new KMeans(k, data);
        //int[] ll = km.run(0);
        int[] ll = km.randomInit(1);

        double[][] res = new double[100][3];

        for (int ii = 0; ii < res.length; ii++) {
            int nRep = ii + 100;
            int[] numRep = new int[k];
            for (int i = 0; i < numRep.length; i++) {
                numRep[i] = nRep;
            }
            FreeShapeMeans bm = new FreeShapeMeans(ll, data, k, numRep, 1, 1);
            boolean clusterChanged = false;
            int iter = 200;
            for (int i = 0; i < iter; i++) {
                bm.immediateUpdate();
            }

            FreeShapeMeans bmRefine = new FreeShapeMeans(bm.getIds(), data, k, numRep, 50, 1);
            int iterRefine = 100;
            for (int i = 0; i < iterRefine; i++) {
                bmRefine.immediateUpdate();

            }
            double[] dd = bmRefine.checkObj();
            res[ii][0] = dd[0]; //obj
            res[ii][1] = dd[1]; //uncertain obj
            res[ii][2] = dd[2]; //average num Trials
            System.out.println(dd[0]);
        }
        ea.writeDoubleToMatlab(res, "resTm", "objTm");
    }
}
