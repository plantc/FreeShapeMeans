/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boostmeans;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/**
 *
 * @author plantc59cs
 */
public class BMResult implements Serializable{
    int[] reps;
    int[] clId;
    double[] objectQuality;
    double[] clusterQuality;
    int[] clusterCount;
    double obj;
    int seed;

    public BMResult(int[] clId, double obj) {
        this.clId = clId;
        this.obj = obj;
    }
    
    public BMResult(int[] clId, double[] certainty, int[] reps, double[] clusterQuality, int[] clusterCount, double obj, int seed) {
        this.reps = reps;
        this.clId = clId;
        this.obj = obj;
        this.clusterQuality = clusterQuality;
        this.clusterCount = clusterCount;
        this.objectQuality = certainty;
        this.seed = seed;
    }
    
    public static void writeToFile(String filename, BMResult b){
         try {
             try (FileOutputStream fileOut = new FileOutputStream(filename + ".ser"); ObjectOutputStream out = new ObjectOutputStream(fileOut)) {
                 out.writeObject(b);
             }
         System.out.printf("Serialized data is saved in " + filename + ".ser");
      } catch (IOException i) {
      } 
    }
    
    public static BMResult readFromFile(String filename){
        BMResult res = null;
         try {
            try (FileInputStream fileIn = new FileInputStream(filename + ".ser"); ObjectInputStream in = new ObjectInputStream(fileIn)) {
                res = (BMResult) in.readObject();
            }
      } catch (IOException i) {
      } catch (ClassNotFoundException c) {
         System.out.println("Employee class not found");
      }
        return res;
    }

    public int[] getReps() {
        return reps;
    }

    public BMResult() {
        this.obj = 0.0;
    }

    
    public double[] getClusterQuality() {
        return clusterQuality;
    }

    public int[] getClusterCount() {
        return clusterCount;
    }

    public void setObj(double obj) {
        this.obj = obj;
    }

    public void setReps(int[] reps) {
        this.reps = reps;
    }

    public int getSeed() {
        return seed;
    }

    public double[] getObjectQuality() {
        return objectQuality;
    }
    
    
    
    
    public void idCheck(){
        int[] nPtsInClusters = new int[clusterCount.length];
        for(int i = 0; i < clId.length; i++)
            nPtsInClusters[clId[i]-1]++;
        for(int i = 0; i < nPtsInClusters.length; i++)
            System.out.println(i + " clusterCount: " + clusterCount[i] + " counted from ids: " + nPtsInClusters[i]);
    }
    
    
    // public BMResult(int[] clId, double[] certainty, int[] reps, double[] clusterQuality, int[] clusterCount, double obj, int seed) {
    public BMResult(BMResult res){
        this(res.getClId().clone(), res.getObjectQuality().clone(), res.getReps().clone(), res.getClusterQuality().clone(), res.getClusterCount().clone(), res.getObj(), res.getSeed());
    }
    

    public int[] getClId() {
        return clId;
    }

    public double getObj() {
        return obj;
    }
    
    
    
    
}
