/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boostmeans;

/**
 *
 * 
 */
public class DisplayResult {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        IO ea = new IO();
        //String dir = "twoMoons5000scatter015Outlier.mat"; //löuft nicht mit seed 1: 0.98.24, gut mit seed 5: 0.9829
        //String dir = "twoMoonsOneGaussianLessOverlap.mat";
        String dir = "dist3_4Outlier.mat";
        
        

        String dirL = "idIDEC.mat"; //löuft nicht mit seed 1: 0.98.24, gut mit seed 5: 0.9829
        double[][] data = ea.readMatlabMatrix(dir, "data");
        int[] labels = ea.readLabels(dir, "labels");
        int[] clusterID = ea.readLabels(dirL, "ids1");
        double[] c = new double[data.length];

        double[][] dataN = new double[data.length - 1][data[0].length];
        for (int i = 0; i < dataN.length; i++) {
            for (int j = 0; j < dataN[0].length; j++) {
                dataN[i][j] = data[i][j];
            }
        }

        int[] labelsN = new int[labels.length - 1];
        int[] clusterIDN = new int[clusterID.length - 1];
        for (int i = 0; i < labelsN.length; i++) {
            labelsN[i] = labels[i];
            clusterIDN[i] = clusterID[i];
        }

        c = new double[dataN.length];

        ea.displayClusters(dataN, labelsN, clusterIDN, c, "bla");
        //ea.displayClusters(data, labels, clusterID, c, "bla");

    }
}
