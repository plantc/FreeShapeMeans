/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boostmeans;

import Jama.Matrix;
import java.util.Random;

/**
 *
 * 
 */
public class BoostMeansAvg {

    int[] ids;
    double[] clusterQuality; //sum of certainties of the assigned clusters; contribution of the clusters to the objective function, is written in hoeffdingObj
    double[] objectQuality; //certainty of assignment to each of the clusters; objective function: maximize it
    double j; //objective function: sum of average minDist
    double[][] data;
    int[] clusterCount;
    int[][] pointsInClusters;
    int[] reps;
    int k;
    int numTry;
    int seed;
    int numObj;
    int d;
    boolean verbose = true;
    Random r;

    public BoostMeansAvg(int[] ids, double[][] data, int k, int numTry, int seed) {
        this.ids = ids;
        objectQuality = new double[ids.length];
        this.data = data;
        numObj = data.length;
        d = data[0].length;
        this.k = k;
        this.reps = new int[k];
        this.numTry = numTry;
        r = new Random(seed);
        clusterCount = new int[k];
        pointsInClusters = new int[k][k];
        clusterQuality = new double[k];
        updateClusterCounts();
    }

    public int[] getReps() {
        return reps;
    }

    public int[] getClusterCount() {
        return clusterCount;
    }

    public BoostMeansAvg(int[] ids, double[][] data, int k, int[] reps, int numTry, int seed) {
        this.ids = ids;
        objectQuality = new double[ids.length];
        this.data = data;
        numObj = data.length;
        d = data[0].length;
        this.k = k;
        this.reps = reps;
        this.numTry = numTry;
        r = new Random(seed);
        clusterCount = new int[k];
        pointsInClusters = new int[k][k];
        clusterQuality = new double[k];
        updateClusterCounts();
    }
    
    //only for quality check not for new assignment
    public BoostMeansAvg(int[] ids, double[][] data, int k, int[] reps, int seed) {
        this.ids = ids;
        objectQuality = new double[ids.length];
        this.data = data;
        numObj = data.length;
        d = data[0].length;
        this.k = k;
        this.reps = reps;
        r = new Random(seed);
        clusterCount = new int[k];
        pointsInClusters = new int[k][k];
        clusterQuality = new double[k];
        updateClusterCounts();

    }
       

    public int[] getIds() {
        return ids;
    }

    public double[] getCertainty() {
        return objectQuality;
    }

    public double[] getClusterQuality() {
        return clusterQuality;
    }
    
    
    

    public void immediateUpdate() {
        for (int i = 0; i < numObj; i++) {
            double[] winner = new double[k]; //store the sum of minimum distances
            //int[] count = new int[k]; //store how ofte a cluster had the min distance
            for (int j = 0; j < numTry; j++) {
                //sample rep random representatives for each cluster
                double[] minDist = new double[k];
                for (int l = 0; l < k; l++) {
                    double[] dist = new double[reps[l]];
                    int[] index = new int[reps[l]];
                    double minL = Double.MAX_VALUE;
                    for (int m = 0; m < reps[l]; m++) {
                        int ii = r.nextInt(clusterCount[l]);
                        int index_rep = pointsInClusters[l][ii];
                        index[m] = index_rep;
                        dist[m] = dist(data[i], data[index_rep]);
                        if (dist[m] < minL) {
                            minL = dist[m];
                        }
                    }
                    minDist[l] = minL;
                }
                for (int l = 0; l < k; l++) {
                    winner[l] += minDist[l];
                }
            }
            for (int l = 0; l < winner.length; l++) {
                winner[l] /= (double) numTry; //avg min distance
            }            //make assignment of that point as consensus decision
            double minAvgDist = Double.MAX_VALUE;
            int minIndex = -1;
            for (int m = 0; m < winner.length; m++) {
                if (winner[m] < minAvgDist) {
                    minAvgDist = winner[m];
                    minIndex = m;
                }
            }
            ids[i] = minIndex + 1;
            //idsNew[i] = maxIndex + 1;
            objectQuality[i] = winner[minIndex];
        }
        j = 0;
        for (int i = 0; i < numObj; i++) {
            j += objectQuality[i];
        }

        if (verbose) {
            //System.out.println("iu: + " + j/(double)numObj);
        }
        updateClusterCounts();
           
    }

    //update the data structures for sampling
    private void updateClusterCounts() {
        //sort out the points of all current clusters as preparation for sampling
        for (int i = 0; i < clusterCount.length; i++) {
            clusterCount[i] = 0;
        }
        for (int i = 0; i < numObj; i++) {
            clusterCount[ids[i] - 1]++;
        }
        int maxClusterCount = -1;
        for (int i = 0; i < clusterCount.length; i++) {
            if (clusterCount[i] > maxClusterCount) {
                maxClusterCount = clusterCount[i];
            }
        }
        pointsInClusters = new int[k][maxClusterCount];
        int[] counter = new int[k];
        for (int i = 0; i < numObj; i++) {
            pointsInClusters[ids[i] - 1][counter[ids[i] - 1]] = i;
            counter[ids[i] - 1]++;
        }
    }

    //check if the difference between the best cluster and the second best cluster is large enough to be significant
    private boolean enoughInformation(int n, double dev, double alpha) {
        double h = - 1 / (2 * dev * dev) * Math.log(alpha / 2.0);
        int nReq = (int) Math.ceil(h);
        if (nReq < n) {
            return true;
        } else {
            return false;
        }
    }

    private int[] bestSecondBest(double[] d) {
        double max = -Double.MAX_VALUE;
        int[] res = new int[2];
        res[0] = -1;
        res[1] = -1;
        for (int j = 0; j < d.length; j++) {
            if (d[j] > max) {
                max = d[j];
                res[0] = j;
            }
        }
        double secondBest = -Double.MAX_VALUE;
        for (int j = 0; j < d.length; j++) {
            if (d[j] > secondBest && j != res[0]) {
                secondBest = d[j];
                res[1] = j;
            }
        }
        return res;
    }
//
//    //for object o return the cluster-id and the certainty and pdf, assumes that clusterCount and objectsInClusters already written, also sums up the variance
//    public double[] getIdCertainty(double[] o, Random r, double var) {
//        double[] res = new double[4];
//        int stepSize = 10;
//        if (var < 0) {
//            var = 1.0; //dummy setting for computing the variance
//        }        //double var = 0.1; // good for 2 moons
//        //double var = 200.0;
//        boolean done = false;
//        int t = 0;
//        int[] ass = new int[k];
//        double[] assd = new double[k];
//        double best;
//        int maxT = 1000;
//        double alpha = 0.05;
//        while (!done) {
//            t += stepSize;
//            double[] a = assignmentsPDF(o, stepSize, pointsInClusters, var, r);
//            for (int j = 0; j < k; j++) {
//                ass[j] += a[j];
//                assd[j] = ass[j] / (double) t;
//            }
//
//            res[2] += a[a.length - 2]; //pdf
//            res[3] += a[a.length - 1]; //variance
//
//            int[] bb = bestSecondBest(assd);
//            double eps = assd[bb[0]] - assd[bb[1]];
//            best = assd[bb[0]];
//            boolean certain = enoughInformation(t, eps, alpha);
//            if (certain || t > maxT) {
//                res[1] = best;
//                res[0] = bb[0];
//                res[2] /= (double) t;
//                res[3] /= (double) t;
//                if (t > maxT) {
//                    res[1] = 1 / (double) k;
//                }
//                done = true;
//            }
//        }
//
//        return res;
//    }

    //returns ch[0]: certainty per object, ch[1]: number of trials per object
    public double[][] hoeffdingObj(double alpha, double maxT) {
        double[][] ch = new double[2][numObj + 1]; //last entry for the number of points for which no decision can be made
        int nd = 0; //count the points which can not be decided at the significance level
        //sort out the points of all current clusters as preparation for sampling
        for (int i = 0; i < clusterCount.length; i++) {
            clusterCount[i] = 0;
        }
        for (int i = 0; i < numObj; i++) {
            clusterCount[ids[i] - 1]++;
        }
        int maxClusterCount = -1;
        for (int i = 0; i < clusterCount.length; i++) {
            if (clusterCount[i] > maxClusterCount) {
                maxClusterCount = clusterCount[i];
            }
        }
        pointsInClusters = new int[k][maxClusterCount];
        int[] counter = new int[k];
        for (int i = 0; i < numObj; i++) {
            pointsInClusters[ids[i] - 1][counter[ids[i] - 1]] = i;
            counter[ids[i] - 1]++;
        }
        int stepSize = 10;
        for (int i = 0; i < numObj; i++) {
            boolean done = false;
            int t = 0;
            int[] ass = new int[k];
            double[] assd = new double[k];
            double best;
            while (!done) {
                t += stepSize;
                int[] a = assignments(i, stepSize, pointsInClusters);
                for (int j = 0; j < k; j++) {
                    ass[j] += a[j];
                    assd[j] = ass[j] / (double) t;
                }
                int[] bb = bestSecondBest(assd);
                double eps = assd[bb[0]] - assd[bb[1]];
                best = assd[bb[0]];
                boolean certain = enoughInformation(t, eps, alpha);
                if (certain || t > maxT) {
                    ch[0][i] = best;
                    ch[1][i] = t;
                    if (t > maxT) {
                        ch[0][i] = 1 / (double) k;
                        ch[0][ch[0].length - 1]++;
                        ch[1][ch[0].length - 1]++;
                        ch[1][i] = -1;
                    }
                    done = true;
                }
            }

        }
        return ch;
    }

    //29.11. for determination of convergence determine how many experiments must be performed - this is an outdated method. New one is hoeffdingObj
    public double[] hoeffdingCertainty(double alpha, int maxT) {
        double[] ch = new double[numObj + 1];
        int checkInterval = 10;
        int ns = 0;
        //sort out the points of all current clusters as preparation for sampling
        for (int i = 0; i < clusterCount.length; i++) {
            clusterCount[i] = 0;
        }
        for (int i = 0; i < numObj; i++) {
            clusterCount[ids[i] - 1]++;
        }
        int maxClusterCount = -1;
        for (int i = 0; i < clusterCount.length; i++) {
            if (clusterCount[i] > maxClusterCount) {
                maxClusterCount = clusterCount[i];
            }
        }
        int[][] pointsInClusters = new int[k][maxClusterCount];
        int[] counter = new int[k];
        for (int i = 0; i < numObj; i++) {
            pointsInClusters[ids[i] - 1][counter[ids[i] - 1]] = i;
            counter[ids[i] - 1]++;
        }
        //first perform 10 trials then check the difference between the maximum and the second best cluster. Based on this determine how many samples are needed with the hoeffding bound
        for (int i = 0; i < numObj; i++) {
            int[] a = assignments(i, checkInterval, pointsInClusters);
            double[] ac = new double[a.length];
            for (int j = 0; j < k; j++) {
                ac[j] = a[j] / (double) checkInterval;
            }
            double maxAc = -Double.MAX_VALUE;
            int maxIndex = -1;
            for (int j = 0; j < k; j++) {
                if (ac[j] > maxAc) {
                    maxAc = ac[j];
                    maxIndex = j;
                }
            }
            double secondBest = -Double.MAX_VALUE;
            for (int j = 0; j < k; j++) {
                if (ac[j] > secondBest && j != maxIndex) {
                    secondBest = ac[j];
                }
            }
            double eps = maxAc - secondBest;
            double h = - 1 / (2 * eps * eps) * Math.log(alpha / 2.0);
            int numSamples = (int) Math.ceil(h);
            if (numSamples > maxT) {
                numSamples = Math.min(numSamples, maxT);

                //System.out.println("object" + i + " cannot be estimated with sufficient accuracy.");
            }
            if (numSamples > checkInterval) {
                //get new samples
                int[] b = assignments(i, numSamples, pointsInClusters);
                double[] sum = new double[k];
                for (int l = 0; l < k; l++) {
                    sum[l] = (a[l] + b[l]) / (double) (numSamples + checkInterval);
                }

                //check if we are now certain enough
                double maxAcSecond = -Double.MAX_VALUE;
                int maxIndexSecond = -1;
                for (int j = 0; j < k; j++) {
                    if (ac[j] > maxAcSecond) {
                        maxAcSecond = sum[j];
                        maxIndexSecond = j;
                    }
                }
                double secondBestSecond = -Double.MAX_VALUE;
                for (int j = 0; j < k; j++) {
                    if (ac[j] > secondBestSecond && j != maxIndexSecond) {
                        secondBestSecond = sum[j];
                    }
                }
                double epsSecond = maxAcSecond - secondBestSecond;
                double hSecond = - 1 / (2 * epsSecond * epsSecond) * Math.log(alpha / 2.0);
                int numSamplesSecond = (int) Math.ceil(hSecond);
                if (numSamplesSecond > (numSamples + checkInterval)) {
                    ns++;
                }

                ch[i] = maxAcSecond;

            } else {
                ch[i] = maxAc;
            }
        }
        ch[ch.length - 1] = ns;
        return ch;
    }
    
    
     //parameter between 0 and 1. 0.1 = 10 per cent
    public void setRepPerCluster(double percentage) {
        for (int i = 0; i < k; i++) {
            reps[i] = (int) Math.round(clusterCount[i] * percentage);
        }
    }
    

    //this is without the hoeffding bound. hoeffding bound needs to be adjusted with the actual value range
    public double[] checkObj() {
        int numT = 100;
        double[] res = new double[1];
        for (int i = 0; i < numObj; i++) {
            double[] winner = new double[k]; //store the sum of minimum distances
            for (int j = 0; j < numT; j++) {
                //sample rep random representatives for each cluster
                double[] minDist = new double[k];
                for (int l = 0; l < k; l++) {
                    double[] dist = new double[reps[l]];
                    double minL = Double.MAX_VALUE;
                    for (int m = 0; m < reps[l]; m++) {
                        int ii = r.nextInt(clusterCount[l]);
                        int index_rep = pointsInClusters[l][ii];
                        dist[m] = dist(data[i], data[index_rep]);
                        if (dist[m] < minL) {
                            minL = dist[m];
                        }
                    }
                    minDist[l] = minL; //distance to closest out of m representatives
                }
                for (int l = 0; l < k; l++) {
                    winner[l] += minDist[l];
                }
                
            }
            
            for (int l = 0; l < winner.length; l++) {
                winner[l] /= (double) numT; //avg min distance
            }  
            
            //make assignment of that point as consensus decision
            double minAvgDist = Double.MAX_VALUE;
            int minIndex = -1;
            for (int m = 0; m < winner.length; m++) {
                if (winner[m] < minAvgDist) {
                    minAvgDist = winner[m];
                    minIndex = m;
                }
            }
            res[0] += winner[minIndex]/(double) numObj;
        }

        return res;

    }

    private double gaussPDF(double dist, double var) {
        double exU = -0.5 * dist * dist / var;
        double factor = 1.0 / Math.sqrt((2.0 * Math.PI) * Math.pow(var, d));
        return factor * Math.exp(exU);
    }

    private double gaussPDF(double[] coord, double[] mean, double var) {
        Matrix sigmaInv = new Matrix(coord.length, coord.length);
        for (int i = 0; i < sigmaInv.getColumnDimension(); i++) {
            sigmaInv.set(i, i, 1.0 / var);
        }
        double[] meanDiff = new double[coord.length];
        for (int i = 0; i < coord.length; i++) {
            meanDiff[i] = coord[i] - mean[i];
        }
        double[][] ex = rowVector(meanDiff).times(sigmaInv).times(colVector(meanDiff)).getArrayCopy();
        double exU = -0.5 * ex[0][0];
        double factor = 1.0 / Math.sqrt((2.0 * Math.PI) * Math.pow(var, coord.length));
        return factor * Math.exp(exU);
    }

    private Matrix rowVector(double[] d) {
        Matrix m = new Matrix(1, d.length);
        for (int i = 0; i < d.length; i++) {
            m.set(0, i, d[i]);
        }
        return m;
    }

    private Matrix colVector(double[] d) {
        Matrix m = new Matrix(d.length, 1);
        for (int i = 0; i < d.length; i++) {
            m.set(i, 0, d[i]);
        }
        return m;
    }

    //perform t trials to estimate the assignment certainty of object o
    public int[] assignments(int o, int t, int[][] pointsInClusters) {
        int[] winner = new int[k]; //store how often the corresponding cluster gets the corresponding point
        for (int j = 0; j < t; j++) {
            //sample rep random representatives for each cluster
            double[] minDist = new double[k];
            for (int l = 0; l < k; l++) {
                double[] dist = new double[reps[l]];
                int[] index = new int[reps[l]];
                double minL = Double.MAX_VALUE;
                for (int m = 0; m < reps[l]; m++) {
                    int ii = r.nextInt(clusterCount[l]);
                    int index_rep = pointsInClusters[l][ii];
                    index[m] = index_rep;
                    dist[m] = dist(data[o], data[index_rep]);
                    if (dist[m] < minL) {
                        minL = dist[m];
                    }
                }
                minDist[l] = minL;
            }
            double min = Double.MAX_VALUE;
            int minIndex = -1;
            for (int m = 0; m < minDist.length; m++) {
                if (minDist[m] < min) {
                    min = minDist[m];
                    minIndex = m;
                }
            }
            winner[minIndex]++;
        }
        return winner;
    }

    //perform t trials to estimate the assignment certainty of object o
    public int[] assignments(double[] o, int t, int[][] pointsInClusters) {
        int[] winner = new int[k]; //store how often the corresponding cluster gets the corresponding point
        for (int j = 0; j < t; j++) {
            //sample rep random representatives for each cluster
            double[] minDist = new double[k];
            for (int l = 0; l < k; l++) {
                double[] dist = new double[reps[l]];
                int[] index = new int[reps[l]];
                double minL = Double.MAX_VALUE;
                for (int m = 0; m < reps[l]; m++) {
                    int ii = r.nextInt(clusterCount[l]);
                    int index_rep = pointsInClusters[l][ii];
                    index[m] = index_rep;
                    dist[m] = dist(o, data[index_rep]);
                    if (dist[m] < minL) {
                        minL = dist[m];
                    }
                }
                minDist[l] = minL;
            }
            double min = Double.MAX_VALUE;
            int minIndex = -1;
            for (int m = 0; m < minDist.length; m++) {
                if (minDist[m] < min) {
                    min = minDist[m];
                    minIndex = m;
                }
            }
            winner[minIndex]++;
        }
        return winner;
    }

    //perform t trials to estimate the assignment certainty of object o, returns also the sum of pdf: assign points according to average min dist 
    public double[] assignmentPDF(double[] o, int t, double sigma, Random rr) {
        for (int i = 0; i < clusterCount.length; i++) {
            clusterCount[i] = 0;
        }
        for (int i = 0; i < numObj; i++) {
            clusterCount[ids[i] - 1]++;
        }
        int maxClusterCount = -1;
        for (int i = 0; i < clusterCount.length; i++) {
            if (clusterCount[i] > maxClusterCount) {
                maxClusterCount = clusterCount[i];
            }
        }
        pointsInClusters = new int[k][maxClusterCount];
        int[] counter = new int[k];
        for (int i = 0; i < numObj; i++) {
            pointsInClusters[ids[i] - 1][counter[ids[i] - 1]] = i;
            counter[ids[i] - 1]++;
        }

        double[] res = new double[2];

        double[] winner = new double[k]; //store the sum of minimum distances
        //int[] count = new int[k]; //store how ofte a cluster had the min distance
        for (int j = 0; j < numTry; j++) {
            //sample rep random representatives for each cluster
            double[] minDist = new double[k];
            for (int l = 0; l < k; l++) {
                double[] dist = new double[reps[l]];
                int[] index = new int[reps[l]];
                double minL = Double.MAX_VALUE;
                for (int m = 0; m < reps[l]; m++) {
                    int ii = rr.nextInt(clusterCount[l]);
                    int index_rep = pointsInClusters[l][ii];
                    index[m] = index_rep;
                    dist[m] = dist(o, data[index_rep]);
                    if (dist[m] < minL) {
                        minL = dist[m];
                    }
                }
                minDist[l] = minL;
            }
            for (int l = 0; l < k; l++) {
                winner[l] += minDist[l];

            }
        }
        for (int l = 0; l < winner.length; l++) {
            winner[l] /= (double) numTry; //avg min distance
        }            //make assignment of that point as consensus decision
        double minAvgDist = Double.MAX_VALUE;
        int minIndex = -1;
        for (int m = 0; m < winner.length; m++) {
            if (winner[m] < minAvgDist) {
                minAvgDist = winner[m];
                minIndex = m;
            }
        }

        res[0] = minIndex;
        res[1] = gaussPDF(minAvgDist, sigma);
        return res;
    }

    public boolean iterate() {
        boolean clusterChanged = false;
        //sort out the points of all current clusters as preparation for sampling
        for (int i = 0; i < clusterCount.length; i++) {
            clusterCount[i] = 0;
        }
        for (int i = 0; i < numObj; i++) {
            clusterCount[ids[i] - 1]++;
        }
        int maxClusterCount = -1;
        for (int i = 0; i < clusterCount.length; i++) {
            if (clusterCount[i] > maxClusterCount) {
                maxClusterCount = clusterCount[i];
            }
        }
        int[][] pointsInClusters = new int[k][maxClusterCount];
        int[] counter = new int[k];
        for (int i = 0; i < numObj; i++) {
            pointsInClusters[ids[i] - 1][counter[ids[i] - 1]] = i;
            counter[ids[i] - 1]++;
        }
        //reassignment
        int[] idsNew = new int[numObj];
        double[] certaintyNew = new double[numObj];
        for (int i = 0; i < numObj; i++) {
            int[] winner = new int[k]; //store how often the corresponding cluster gets the corresponding point
            for (int j = 0; j < numTry; j++) {
                //sample rep random representatives for each cluster
                double[] minDist = new double[k];
                for (int l = 0; l < k; l++) {
                    double[] dist = new double[reps[l]];
                    int[] index = new int[reps[l]];
                    double minL = Double.MAX_VALUE;
                    for (int m = 0; m < reps[l]; m++) {
                        int ii = r.nextInt(clusterCount[l]);
                        int index_rep = pointsInClusters[l][ii];
                        index[m] = index_rep;
                        dist[m] = dist(data[i], data[index_rep]);
                        if (dist[m] < minL) {
                            minL = dist[m];
                        }
                    }
                    minDist[l] = minL;
                }
                double min = Double.MAX_VALUE;
                int minIndex = -1;
                for (int m = 0; m < minDist.length; m++) {
                    if (minDist[m] < min) {
                        min = minDist[m];
                        minIndex = m;
                    }
                }
                winner[minIndex]++;
            }
            //make assignment of that point as consensus decision
            int max = -Integer.MAX_VALUE;
            int maxIndex = -1;
            for (int m = 0; m < winner.length; m++) {
                if (winner[m] > max) {
                    max = winner[m];
                    maxIndex = m;
                }
            }
            idsNew[i] = maxIndex + 1;
            certaintyNew[i] = (double) winner[maxIndex] / (double) numTry;
        }
        //update ids and certainties
        j = 0;
        for (int i = 0; i < numObj; i++) {
            if (ids[i] != idsNew[i]) {
                clusterChanged = true;
            }
            ids[i] = idsNew[i];
            objectQuality[i] = certaintyNew[i];
            j += objectQuality[i] / (double) numObj;
        }
        if (verbose) {
            System.out.println(j);
        }
        return clusterChanged;
    }

    private double dist(double[] a, double[] b) {
        double dd = 0.0;
        for (int k = 0; k < a.length; k++) {
            dd += (a[k] - b[k]) * (a[k] - b[k]);
        }
        return Math.sqrt(dd);
    }

}
