/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boostmeans;

import java.awt.image.BufferedImage;
import java.io.File;
import java.util.Random;
import javax.imageio.ImageIO;
import weka.core.Instance;
import weka.core.Instances;

/**
 *
 * 
 */
public class InitExperiments {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        IO ea = new IO();
        //String dir = "twoMoons5000scatter015.mat"; //perfekt mit seed 5
        //String dir = "twoMoonsOneGaussianOverlap.mat"; //läuft nicht
        //String dir = "twoMoonsOneGaussianLessOverlap.mat"; //löuft nicht mit seed 1: 0.98.24, gut mit seed 5: 0.9829
        //String dir = "twoMoonsOneGaussianLessOverlapNoise1.mat"; //löuft nicht mit seed 1: 0.98.24, gut mit seed 5: 0.9829
        // String dir = "dipTransformedData.mat"; //löuft nicht mit seed 1: 0.98.24, gut mit seed 5: 0.9829

//String dir = "twoOverlappingGaussians.mat"; //nicht gut mit seed 5, gut mit seed 1
        //String dir = "outlier2000.mat"; //perfekt mit seed 1
        //String dir = "twoMoonsOneGaussian.mat"; //perfekt mit seed 1; aber Endlosschleife :-)
        //String dir = "twoMoonsOneGaussianNoise10.mat"; //perfekt mit seed 1; aber Endlosschleife :-)
        //String dir = "threeGaussians3000.mat"; //perfekt mit seed 1; aber Endlosschleife :-)
        // String dir = "random.mat";
        //String dir = "syn3.mat"; //kreis
        //String dir = "syn2.mat"; //ebene mit 2 clustern
        // String dir = "syn4.mat"; //kreis sparse
//        //double[][] data = ea.readMatlabMatrix(dir, "x");
//        double[][] data = ea.readMatlabMatrix(dir, "data");
//       int[] labels = ea.readLabels(dir, "labels");
        //int[] labels = ea.readLabels(dir, "trueLabel");
        //ea.addUniformNoise(data, labels, 0.01, 0);
        //String dir = "banknote-authentication.arff"; 
           String dir = "mushroom.arff";
        //String dir = "pendigits.arff";
        Instances inst = ea.readArffFile(dir);

        //inst.setClassIndex(0);
        double[][] data = ea.getDataFromArff(inst);
        data = ea.scaleData(data);
        int[] labels = ea.getClassLabelFromArff(inst);
//          

        int numInit = 3;
        int k = 2;
        int numObj = data.length;

        int[][] ids = new int[numInit][numObj];
       

        for (int i = 0; i < numInit; i++) {
            BoilDown bd = new BoilDown(data, k, i, labels);
            bd.run();
            ids[i] = bd.bestResult.clId;
            System.out.println("i " + bd.bestResult.obj);

        }
      
        double[][] ll = new double[numObj][1];
        double[][] idss = new double[numInit][numObj];
        for (int i = 0; i < numObj; i++) {
            ll[i][0] = labels[i];
        }
       
        for (int i = 0; i < numInit; i++) {
            for (int j = 0; j < numObj; j++) {
                idss[i][j] = ids[i][j];
            }
        }
        ea.writeDoubleToMatlab(ll, "labels", "labels");
        ea.writeDoubleToMatlab(idss, "ids", "ids");
      
        ea.writeDoubleToMatlab(data, "data", "data");

//        ea.displayBorder(1000, data, bd.bestClusterer);
//     ea.displayCertainty(data, labels, bd.bestResult.clId, bd.bestResult.objectQuality);
    }

}
