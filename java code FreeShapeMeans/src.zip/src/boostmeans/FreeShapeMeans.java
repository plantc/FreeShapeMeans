/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boostmeans;

import Jama.Matrix;
import java.util.Arrays;
import java.util.Random;

/**
 *
 * 
 */
public class FreeShapeMeans {

    int[] ids;
    double[] clusterQuality; //sum of certainties of the assigned clusters; contribution of the clusters to the objective function, is written in hoeffdingObj
    double[] objectQuality; //certainty of assignment to each of the clusters; objective function: maximize it
    double j; //objective function: sum of certainties
    double[][] data;
    int[] clusterCount;
    int[][] pointsInClusters;
    int[] reps;
    int k;
    int numTry;
    int seed;
    int numObj;
    int d;
    boolean verbose = true;
    boolean L1 = false;
    boolean L2 = true;
    boolean matching = false;
    Random r;

    public FreeShapeMeans(int[] ids, double[][] data, int k, int numTry, int seed) {
        this.ids = ids;
        objectQuality = new double[ids.length];
        this.data = data;
        numObj = data.length;
        d = data[0].length;
        this.k = k;
        this.reps = new int[k];
        this.numTry = numTry;
        this.seed = seed;
        r = new Random(seed);
        clusterCount = new int[k];
        pointsInClusters = new int[k][k];
        clusterQuality = new double[k];
        updateClusterCounts();
    }

    public int[] getIds() {
        return this.ids;
    }

    public int[] getReps() {
        return reps;
    }

    public double[] getClusterQuality() {
        return clusterQuality;
    }

    public int[] getClusterCount() {
        return clusterCount;
    }

    public FreeShapeMeans(int[] ids, double[][] data, int k, int[] reps, int numTry, int seed) {
        this.ids = ids;
        objectQuality = new double[ids.length];
        this.data = data;
        numObj = data.length;
        d = data[0].length;
        this.k = k;
        this.reps = reps;
        this.numTry = numTry;
        r = new Random(seed);
        this.seed = seed;
        clusterCount = new int[k];
        pointsInClusters = new int[k][k];
        clusterQuality = new double[k];
        updateClusterCounts();

    }

    //only for quality check not for new assignment
    public FreeShapeMeans(int[] ids, double[][] data, int k, int[] reps, int seed) {
        this.ids = ids;
        objectQuality = new double[ids.length];
        this.data = data;
        numObj = data.length;
        d = data[0].length;
        this.k = k;
        this.reps = reps;
        this.seed = seed;
        r = new Random(seed);
        clusterCount = new int[k];
        pointsInClusters = new int[k][k];
        clusterQuality = new double[k];
        updateClusterCounts();

    }

    public double[] getCertainty() {
        return objectQuality;
    }

    //update the data structures for sampling
    private void updateClusterCounts() {
        //sort out the points of all current clusters as preparation for sampling
        for (int i = 0; i < clusterCount.length; i++) {
            clusterCount[i] = 0;
        }
        for (int i = 0; i < numObj; i++) {
            clusterCount[ids[i] - 1]++;
        }
        int maxClusterCount = -1;
        for (int i = 0; i < clusterCount.length; i++) {
            if (clusterCount[i] > maxClusterCount) {
                maxClusterCount = clusterCount[i];
            }
        }
        pointsInClusters = new int[k][maxClusterCount];
        int[] counter = new int[k];
        for (int i = 0; i < numObj; i++) {
            pointsInClusters[ids[i] - 1][counter[ids[i] - 1]] = i;
            counter[ids[i] - 1]++;
        }
    }

    public void immediateUpdate() {
        //boolean clusterChanged = false;
        for (int i = 0; i < numObj; i++) {
            int[] winner = new int[k]; //store how often the corresponding cluster gets the corresponding point
            for (int j = 0; j < numTry; j++) {
                //sample rep random representatives for each cluster
                double[] minDist = new double[k];
                for (int l = 0; l < k; l++) {
                    if (clusterCount[l] > 0) {
                        double[] dist = new double[reps[l]];
                        int[] index = new int[reps[l]];
                        double minL = Double.MAX_VALUE;
                        boolean[] used = new boolean[clusterCount[l]];
                        for (int m = 0; m < reps[l]; m++) {
                            int ii = r.nextInt(clusterCount[l]);
                            while (used[ii]) {
                                ii = r.nextInt(clusterCount[l]);
                            }
                            used[ii] = true;
                            int index_rep = pointsInClusters[l][ii];
                            index[m] = index_rep;
                            dist[m] = dist(data[i], data[index_rep]);
                            if (dist[m] < minL) {
                                minL = dist[m];
                            }
                        }
                        minDist[l] = minL;
                    } else {
                        minDist[l] = Double.MAX_VALUE;
                    }
                }
                double min = Double.MAX_VALUE;
                int minIndex = -1;
                for (int m = 0; m < minDist.length; m++) {
                    if (minDist[m] < min) {
                        min = minDist[m];
                        minIndex = m;
                    }
                }
                if (minIndex == -1) {
                    System.out.println("m");
                }
                winner[minIndex]++;
            }
            //make assignment of that point as consensus decision
            int max = -Integer.MAX_VALUE;
            int maxIndex = -1;
            for (int m = 0; m < winner.length; m++) {
                if (winner[m] > max) {
                    max = winner[m];
                    maxIndex = m;
                }
            }
            ids[i] = maxIndex + 1;
            //idsNew[i] = maxIndex + 1;
            objectQuality[i] = (double) winner[maxIndex] / (double) numTry;
        }
        j = 0;
        for (int i = 0; i < numObj; i++) {
            j += objectQuality[i] / (double) numObj;
        }
//        if (verbose) 
//            System.out.println(j);

        updateClusterCounts();

        //return clusterChanged;
    }
    //check if the difference between the best cluster and the second best cluster is large enough to be significant

    private boolean enoughInformation(int n, double dev, double alpha) {
        dev = dev / 2.0;
        double h = - 1 / (2 * dev * dev) * Math.log(alpha / 2.0);
        int nReq = (int) Math.ceil(h);
        if (nReq < n) {
            return true;
        } else {
            return false;
        }
    }

    private int[] bestSecondBest(double[] d) {
        double max = -Double.MAX_VALUE;
        int[] res = new int[2];
        res[0] = -1;
        res[1] = -1;
        for (int j = 0; j < d.length; j++) {
            if (d[j] > max) {
                max = d[j];
                res[0] = j;
            }
        }
        double secondBest = -Double.MAX_VALUE;
        for (int j = 0; j < d.length; j++) {
            if (d[j] > secondBest && j != res[0]) {
                secondBest = d[j];
                res[1] = j;
            }
        }
        return res;
    }

    //for object o return the cluster-id and the certainty and pdf, assumes that clusterCount and objectsInClusters already written, also sums up the variance
    public double[] getIdCertainty(double[] o, Random r, double var) {
        double[] res = new double[4];
        int stepSize = 10;
        if (var < 0) {
            var = 1.0; //dummy setting for computing the variance
        }        //double var = 0.1; // good for 2 moons
        //double var = 200.0;
        boolean done = false;
        int t = 0;
        int[] ass = new int[k];
        double[] assd = new double[k];
        double best;
        int maxT = 1000;
        double alpha = 0.05;
        while (!done) {
            t += stepSize;
            double[] a = assignmentsPDF(o, stepSize, pointsInClusters, var, r);
            for (int j = 0; j < k; j++) {
                ass[j] += a[j];
                assd[j] = ass[j] / (double) t;
            }

            res[2] += a[a.length - 2]; //pdf
            res[3] += a[a.length - 1]; //variance

            int[] bb = bestSecondBest(assd);
            double eps = assd[bb[0]] - assd[bb[1]];
            best = assd[bb[0]];
            boolean certain = enoughInformation(t, eps, alpha);
            if (certain || t > maxT) {
                res[1] = best;
                res[0] = bb[0];
                res[2] /= (double) t;
                res[3] /= (double) t;
                if (t > maxT) {
                    res[1] = 1 / (double) k;
                }
                done = true;
            }
        }

        return res;
    }

    // for every object: perfom enough trials to be certain enough to assign it to its cluster: or maximal number of trials. writes ids, objectQuality
    public void hoeffdingAssign(double alpha, double maxT) {
        int stepSize = 10;
        int[] clCounts = new int[k];
        for (int i = 0; i < numObj; i++) {
            boolean done = false;
            int t = 0;
            int[] ass = new int[k];
            double[] assd = new double[k];
            double best;
            while (!done) {
                t += stepSize;
                int[] a = assignments(i, stepSize, pointsInClusters, r);
                for (int j = 0; j < k; j++) {
                    ass[j] += a[j];
                    assd[j] = ass[j] / (double) t;
                }
                int[] bb = bestSecondBest(assd);
                double eps = assd[bb[0]] - assd[bb[1]];
                best = assd[bb[0]];
                boolean certain = enoughInformation(t, eps, alpha);
                if (certain || t > maxT) {
                    ids[i] = bb[0] + 1;
                    objectQuality[i] = best;
                    clCounts[bb[0]]++;
                    if (t > maxT) {
                        objectQuality[i] = 1 / (double) k;
                    }
                    clusterQuality[bb[0]] += objectQuality[i];
                    done = true;
                }
            }

        }
        for (int i = 0; i < k; i++) {
            clusterQuality[i] /= (int) clCounts[i];
        }

        j = 0;
        for (int i = 0; i < numObj; i++) {
            j += objectQuality[i] / (double) numObj;
        }
//        if (verbose) 
//            System.out.println(j);

        updateClusterCounts();

        //return ch;   
    }

    //returns ch[0]: certainty per object, ch[1]: number of trials per object
    public double[][] hoeffdingObj(double alpha, double maxT) {
        Random rr = new Random(1);
        double[][] ch = new double[2][numObj + 1]; //last entry for the number of points for which no decision can be made
        int stepSize = 10;
        int[] clCounts = new int[k];
        for (int i = 0; i < numObj; i++) {
            boolean done = false;
            int t = 0;
            int[] ass = new int[k];
            double[] assd = new double[k];
            double best;
            while (!done) {
                t += stepSize;
                int[] a = assignments(i, stepSize, pointsInClusters, rr);
                for (int j = 0; j < k; j++) {
                    ass[j] += a[j];
                    assd[j] = ass[j] / (double) t;
                }
                int[] bb = bestSecondBest(assd);
                double eps = assd[bb[0]] - assd[bb[1]];
                best = assd[bb[0]];
                boolean certain = enoughInformation(t, eps, alpha);
                if (certain || t > maxT) {
                    double q = best;
                    ch[0][i] = best;
                    ch[1][i] = t;
                    clCounts[bb[0]]++;
                    if (t > maxT) {
                        q = 1 / (double) k;
                        ch[0][i] = 1 / (double) k;
                        ch[0][ch[0].length - 1]++;
                        ch[1][ch[0].length - 1]++;
                        ch[1][i] = -1;
                    }
                    clusterQuality[bb[0]] += q;
                    done = true;
                }
            }

        }
        for (int i = 0; i < k; i++) {
            clusterQuality[i] /= (int) clCounts[i];
        }
        return ch;
    }

    //returns ch[0]: certainty per object, ch[1]: number of trials per object; consider the current cluster assignment
    public double[][] hoeffdingObjFixedCluster(double alpha, double maxT) {
        Random rr = new Random(1);
        double[][] ch = new double[2][numObj + 1]; //last entry for the number of points for which no decision can be made
        int stepSize = 10;
        int[] clCounts = new int[k];
        for (int i = 0; i < numObj; i++) {
            boolean done = false;
            int t = 0;
            int[] ass = new int[k];
            double[] assd = new double[k];
            double best;
            while (!done) {
                t += stepSize;
                int[] a = assignments(i, stepSize, pointsInClusters, rr);
                for (int j = 0; j < k; j++) {
                    ass[j] += a[j];
                    assd[j] = ass[j] / (double) t;
                }
                int[] bb = bestSecondBest(assd);
                double eps = assd[bb[0]] - assd[bb[1]];
                best = assd[ids[i] - 1];
                boolean certain = enoughInformation(t, eps, alpha);
                if (certain || t > maxT) {
                    double q = best;
                    ch[0][i] = best;
                    ch[1][i] = t;
                    clCounts[bb[0]]++;
                    if (t > maxT) {
                        q = 1 / (double) k;
                        ch[0][i] = 1 / (double) k;
                        ch[0][ch[0].length - 1]++;
                        ch[1][ch[0].length - 1]++;
                        ch[1][i] = -1;
                    }
                    clusterQuality[bb[0]] += q;
                    done = true;
                }
            }

        }
        for (int i = 0; i < k; i++) {
            clusterQuality[i] /= (int) clCounts[i];
        }
        return ch;
    }

//    //29.11. for determination of convergence determine how many experiments must be performed - this is an outdated method. New one is hoeffdingObj
//    public double[] hoeffdingCertainty(double alpha, int maxT) {
//        double[] ch = new double[numObj + 1];
//        int checkInterval = 10;
//        int ns = 0;
//        //sort out the points of all current clusters as preparation for sampling
//        for (int i = 0; i < clusterCount.length; i++) {
//            clusterCount[i] = 0;
//        }
//        for (int i = 0; i < numObj; i++) {
//            clusterCount[ids[i] - 1]++;
//        }
//        int maxClusterCount = -1;
//        for (int i = 0; i < clusterCount.length; i++) {
//            if (clusterCount[i] > maxClusterCount) {
//                maxClusterCount = clusterCount[i];
//            }
//        }
//        int[][] pointsInClusters = new int[k][maxClusterCount];
//        int[] counter = new int[k];
//        for (int i = 0; i < numObj; i++) {
//            pointsInClusters[ids[i] - 1][counter[ids[i] - 1]] = i;
//            counter[ids[i] - 1]++;
//        }
//        //first perform 10 trials then check the difference between the maximum and the second best cluster. Based on this determine how many samples are needed with the hoeffding bound
//        for (int i = 0; i < numObj; i++) {
//            int[] a = assignments(i, checkInterval, pointsInClusters);
//            double[] ac = new double[a.length];
//            for (int j = 0; j < k; j++) {
//                ac[j] = a[j] / (double) checkInterval;
//            }
//            double maxAc = -Double.MAX_VALUE;
//            int maxIndex = -1;
//            for (int j = 0; j < k; j++) {
//                if (ac[j] > maxAc) {
//                    maxAc = ac[j];
//                    maxIndex = j;
//                }
//            }
//            double secondBest = -Double.MAX_VALUE;
//            for (int j = 0; j < k; j++) {
//                if (ac[j] > secondBest && j != maxIndex) {
//                    secondBest = ac[j];
//                }
//            }
//            double eps = maxAc - secondBest;
//            double h = - 1 / (2 * eps * eps) * Math.log(alpha / 2.0);
//            int numSamples = (int) Math.ceil(h);
//            if (numSamples > maxT) {
//                numSamples = Math.min(numSamples, maxT);
//
//                //System.out.println("object" + i + " cannot be estimated with sufficient accuracy.");
//            }
//            if (numSamples > checkInterval) {
//                //get new samples
//                int[] b = assignments(i, numSamples, pointsInClusters);
//                double[] sum = new double[k];
//                for (int l = 0; l < k; l++) {
//                    sum[l] = (a[l] + b[l]) / (double) (numSamples + checkInterval);
//                }
//
//                //check if we are now certain enough
//                double maxAcSecond = -Double.MAX_VALUE;
//                int maxIndexSecond = -1;
//                for (int j = 0; j < k; j++) {
//                    if (ac[j] > maxAcSecond) {
//                        maxAcSecond = sum[j];
//                        maxIndexSecond = j;
//                    }
//                }
//                double secondBestSecond = -Double.MAX_VALUE;
//                for (int j = 0; j < k; j++) {
//                    if (ac[j] > secondBestSecond && j != maxIndexSecond) {
//                        secondBestSecond = sum[j];
//                    }
//                }
//                double epsSecond = maxAcSecond - secondBestSecond;
//                double hSecond = - 1 / (2 * epsSecond * epsSecond) * Math.log(alpha / 2.0);
//                int numSamplesSecond = (int) Math.ceil(hSecond);
//                if (numSamplesSecond > (numSamples + checkInterval)) {
//                    ns++;
//                }
//
//                ch[i] = maxAcSecond;
//
//            } else {
//                ch[i] = maxAc;
//            }
//        }
//        ch[ch.length - 1] = ns;
//        return ch;
//    }
    private void resetClusterQuality() {
        for (int i = 0; i < k; i++) {
            clusterQuality[i] = 0;
        }
    }

    //returns: obj, number of objects for which alpha does not hold, average number of trials for object
    public double[] checkObj() {
        resetClusterQuality();
        double alpha = 0.05;
        int maxT = 1000;
        double[] res = new double[3];
        double[][] c = hoeffdingObjFixedCluster(alpha, maxT);
        double m = 0;
        double avgT = 0;
        int count = 0;
        for (int i = 0; i < numObj; i++) {
            if (c[1][i] >= 0) {
                m += c[0][i] / (double) numObj;
            } else {
                m += 1 / (double) k / (double) numObj;
            }
            if (c[1][i] >= 0) {
                avgT += c[1][i];
                count++;
            }

        }
        res[0] = m; //average certainty
        //res[0] = lbObj(c[0], alpha);
        res[1] = c[0][c[0].length - 1]; //
        res[2] = avgT / (double) count; //average number of trials
        return res;
    }

    private double lbObj(double[] c, double alpha) {
        double[] cc = new double[c.length - 1];
        for (int i = 0; i < cc.length; i++) {
            cc[i] = c[i];
        }
        Arrays.sort(cc);
        int bestFive = (int) Math.round(numObj * 0.05);
        int count = numObj - bestFive;
        double res = 0.0;
        for (int i = 0; i < count; i++) {
            if (cc[i] > 0) {
                res += cc[i] / count;
            } else {
                res += 1 / (double) k / (double) count;
            }
        }
        return res;
    }

    //parameter between 0 and 1. 0.1 = 10 per cent
    public void setRepPerCluster(double percentage) {
        for (int i = 0; i < k; i++) {
            reps[i] = (int) Math.round(clusterCount[i] * percentage);
            if (reps[i] == 0) {
                reps[i]++;
            }
            //reps[i] = 1;
        }
    }

    private void reduceReps() {
        for (int i = 0; i < k; i++) {

        }
    }

    //try to increase the number of reps for every cluster if this increases the obj; input: the base objective Function which 
    public void checkRepPerCluster() {
        for (int i = 0; i < k; i++) {
            reps[i] = 1;
        }
        double[] b = checkObj();
        double baseline = b[0]; //baseline: all clusters represented by only one rep
        System.out.println("cluster quality: " + clusterQuality[0] + " " + clusterQuality[1]);
        int[] optReps = new int[k];

        for (int i = 0; i < k; i++) {
            boolean improvement = true;
            double currObj = baseline;
            int maxNumRep = (int) Math.round(clusterCount[i] / (double) 10);
            while (improvement && reps[i] < maxNumRep) {
                reps[i]++;
                double[] newObj = checkObj();
                System.out.println(i + " " + newObj[0]);
                System.out.println("cluster quality: " + clusterQuality[0] + " " + clusterQuality[1]);
                if (newObj[0] - currObj <= 0) {
                    optReps[i] = reps[i] - 1;
                    for (int j = 0; j < k; j++) {
                        reps[j] = 1;
                    }
                    improvement = false;
                } else {
                    currObj = newObj[0];
                }
            }
        }
        for (int i = 0; i < k; i++) {
            reps[i] = optReps[i];
            System.out.println(i + " " + reps[i]);
        }
    }

    private double gaussPDF(double[] coord, double[] mean, double var) {
        Matrix sigmaInv = new Matrix(coord.length, coord.length);
        for (int i = 0; i < sigmaInv.getColumnDimension(); i++) {
            sigmaInv.set(i, i, 1.0 / var);
        }
        double[] meanDiff = new double[coord.length];
        for (int i = 0; i < coord.length; i++) {
            meanDiff[i] = coord[i] - mean[i];
        }
        double[][] ex = rowVector(meanDiff).times(sigmaInv).times(colVector(meanDiff)).getArrayCopy();
        double exU = -0.5 * ex[0][0];
        double factor = 1.0 / Math.sqrt((2.0 * Math.PI) * Math.pow(var, coord.length));
        return factor * Math.exp(exU);
    }

    private Matrix rowVector(double[] d) {
        Matrix m = new Matrix(1, d.length);
        for (int i = 0; i < d.length; i++) {
            m.set(0, i, d[i]);
        }
        return m;
    }

    private Matrix colVector(double[] d) {
        Matrix m = new Matrix(d.length, 1);
        for (int i = 0; i < d.length; i++) {
            m.set(i, 0, d[i]);
        }
        return m;
    }

    //perform t trials to estimate the assignment certainty of object o
    public int[] assignments(int o, int t, int[][] pointsInClusters) {
        int[] winner = new int[k]; //store how often the corresponding cluster gets the corresponding point
        for (int j = 0; j < t; j++) {
            //sample rep random representatives for each cluster
            double[] minDist = new double[k];
            for (int l = 0; l < k; l++) {
                double[] dist = new double[reps[l]];
                int[] index = new int[reps[l]];
                double minL = Double.MAX_VALUE;
                boolean[] used = new boolean[clusterCount[l]];
                for (int m = 0; m < reps[l]; m++) {
                    int ii = r.nextInt(clusterCount[l]);
                    while (used[ii]) {
                        ii = r.nextInt(clusterCount[l]);
                    }
                    used[ii] = true;
                    int index_rep = pointsInClusters[l][ii];
                    index[m] = index_rep;
                    dist[m] = dist(data[o], data[index_rep]);
                    if (dist[m] < minL) {
                        minL = dist[m];
                    }
                }
                minDist[l] = minL;
            }
            double min = Double.MAX_VALUE;
            int minIndex = -1;
            for (int m = 0; m < minDist.length; m++) {
                if (minDist[m] < min) {
                    min = minDist[m];
                    minIndex = m;
                }
            }
            winner[minIndex]++;
        }
        return winner;
    }

    //perform t trials to estimate the assignment certainty of object o
    public int[] assignments(int o, int t, int[][] pointsInClusters, Random rr) {
        int[] winner = new int[k]; //store how often the corresponding cluster gets the corresponding point
        for (int j = 0; j < t; j++) {
            //sample rep random representatives for each cluster
            double[] minDist = new double[k];
            for (int l = 0; l < k; l++) {
                double[] dist = new double[reps[l]];
                int[] index = new int[reps[l]];
                double minL = Double.MAX_VALUE;
                boolean[] used = new boolean[clusterCount[l]];
                if (clusterCount[l] > 0) {
                    for (int m = 0; m < reps[l]; m++) {
                        int ii = rr.nextInt(clusterCount[l]);
                        while (used[ii]) {
                            ii = rr.nextInt(clusterCount[l]);
                        }
                        used[ii] = true;
                        int index_rep = pointsInClusters[l][ii];
                        index[m] = index_rep;
                        dist[m] = dist(data[o], data[index_rep]);
                        if (dist[m] < minL) {
                            minL = dist[m];
                        }
                        minDist[l] = minL;
                    }
                } else {
                    minDist[l] = Double.MAX_VALUE;
                }

            }
            double min = Double.MAX_VALUE;
            int minIndex = -1;
            for (int m = 0; m < minDist.length; m++) {
                if (minDist[m] < min) {
                    min = minDist[m];
                    minIndex = m;
                }
            }
            winner[minIndex]++;
        }
        return winner;
    }

    //perform t trials to estimate the assignment certainty of object o, returns also the sum of pdf 
    public double[] assignmentsPDF(double[] o, int t, int[][] pointsInClusters, double sigma, Random rr) {
        double[] winner = new double[k + 2]; //store how often the corresponding cluster gets the corresponding point, [k]: pdf, [k+1]: squared distance
        for (int j = 0; j < t; j++) {
            //sample rep random representatives for each cluster
            double[] minDist = new double[k];
            int[] minRep = new int[k]; //index of the best representative for each cluster
            for (int l = 0; l < k; l++) {
                double[] dist = new double[reps[l]];
                int[] index = new int[reps[l]];
                double minL = Double.MAX_VALUE;
                int minRepL = -1;
                for (int m = 0; m < reps[l]; m++) {
                    int ii = rr.nextInt(clusterCount[l]);
                    int index_rep = pointsInClusters[l][ii];
                    index[m] = index_rep;
                    dist[m] = dist(o, data[index_rep]);
                    if (dist[m] < minL) {
                        minL = dist[m];
                        minRepL = index_rep;
                    }
                }
                minDist[l] = minL;
                minRep[l] = minRepL;
            }
            double min = Double.MAX_VALUE;
            int minIndex = -1;
            for (int m = 0; m < minDist.length; m++) {
                if (minDist[m] < min) {
                    min = minDist[m];
                    minIndex = m;
                }
            }
            winner[minIndex]++;
            winner[k] += gaussPDF(o, data[minRep[minIndex]], sigma);
            winner[k + 1] += min * min;
        }
        return winner;
    }

    public boolean iterate() {
        boolean clusterChanged = false;
        //sort out the points of all current clusters as preparation for sampling
        for (int i = 0; i < clusterCount.length; i++) {
            clusterCount[i] = 0;
        }
        for (int i = 0; i < numObj; i++) {
            clusterCount[ids[i] - 1]++;
        }
        int maxClusterCount = -1;
        for (int i = 0; i < clusterCount.length; i++) {
            if (clusterCount[i] > maxClusterCount) {
                maxClusterCount = clusterCount[i];
            }
        }
        int[][] pointsInClusters = new int[k][maxClusterCount];
        int[] counter = new int[k];
        for (int i = 0; i < numObj; i++) {
            pointsInClusters[ids[i] - 1][counter[ids[i] - 1]] = i;
            counter[ids[i] - 1]++;
        }
        //reassignment
        int[] idsNew = new int[numObj];
        double[] certaintyNew = new double[numObj];
        for (int i = 0; i < numObj; i++) {
            int[] winner = new int[k]; //store how often the corresponding cluster gets the corresponding point
            for (int j = 0; j < numTry; j++) {
                //sample rep random representatives for each cluster
                double[] minDist = new double[k];
                for (int l = 0; l < k; l++) {
                    double[] dist = new double[reps[l]];
                    int[] index = new int[reps[l]];
                    double minL = Double.MAX_VALUE;
                    for (int m = 0; m < reps[l]; m++) {
                        int ii = r.nextInt(clusterCount[l]);
                        int index_rep = pointsInClusters[l][ii];
                        index[m] = index_rep;
                        dist[m] = dist(data[i], data[index_rep]);
                        if (dist[m] < minL) {
                            minL = dist[m];
                        }
                    }
                    minDist[l] = minL;
                }
                double min = Double.MAX_VALUE;
                int minIndex = -1;
                for (int m = 0; m < minDist.length; m++) {
                    if (minDist[m] < min) {
                        min = minDist[m];
                        minIndex = m;
                    }
                }
                winner[minIndex]++;
            }
            //make assignment of that point as consensus decision
            int max = -Integer.MAX_VALUE;
            int maxIndex = -1;
            for (int m = 0; m < winner.length; m++) {
                if (winner[m] > max) {
                    max = winner[m];
                    maxIndex = m;
                }
            }
            idsNew[i] = maxIndex + 1;
            certaintyNew[i] = (double) winner[maxIndex] / (double) numTry;
        }
        //update ids and certainties
        j = 0;
        for (int i = 0; i < numObj; i++) {
            if (ids[i] != idsNew[i]) {
                clusterChanged = true;
            }
            ids[i] = idsNew[i];
            objectQuality[i] = certaintyNew[i];
            j += objectQuality[i] / (double) numObj;
        }
        if (verbose) {
            System.out.println(j);
        }
        return clusterChanged;
    }

    private double dist(double[] a, double[] b) {
        double d = 0;
        if (L2) {
            double dd = 0.0;
            for (int k = 0; k < a.length; k++) {
                dd += (a[k] - b[k]) * (a[k] - b[k]);
            }
            d = dd;
        }
        if (L1) {
            double dd = 0.0;
            for (int k = 0; k < a.length; k++) {
                dd += Math.abs(a[k] - b[k]);
            }
            d = dd;
        }
        if (matching) {
            double dd = 0.0;
            for (int k = 0; k < a.length; k++) {
                if (a[k] != b[k]) {
                    dd++;
                }
            }
            d = dd;

        }
        return d;

    }
}
