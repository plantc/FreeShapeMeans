/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boostmeans;

/**
 *
 * 
 */
public class AvgMeansMain { 

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        IO ea = new IO();
        // String dir = "twoMoons5000.mat";
        String dir = "twoMoonsOneGaussian.mat";
        //String dir = "outlier2000.mat";
        //String dir = "threeGaussians3000.mat";
        // String dir = "random.mat";
        //String dir = "syn3.mat"; //kreis
        //String dir = "syn2.mat"; //ebene mit 2 clustern
        // String dir = "syn4.mat"; //kreis sparse
        //double[][] data = ea.readMatlabMatrix(dir, "x");
        double[][] data = ea.readMatlabMatrix(dir, "data");
        int[] labels = ea.readLabels(dir, "labels");

        // TODO code application logic here
        int k = 3;
        int seed = 12;

        BMResult ii = BMResult.readFromFile("InitAvg");

        ea.displayClusters(data, labels, ii.clId, ii.objectQuality, "init");
        //ea.displayCertainty(data, labels, bmRefine.getIds(), bmRefine.getCertainty());

        int[] numRep = new int[k];

        int nRep = 20;
        for (int i = 0; i < numRep.length; i++) {
            numRep[i] = ii.reps[i];
        }

        numRep[2] = 1;

        BoostMeansAvg bmRefine = new BoostMeansAvg(ii.clId, data, k, numRep, 10, 1);

        // BoostMeansAvg bmRefine = new BoostMeansAvg(bm.getIds(), data, k, numRep, 100, 1);
        int iterRefine = 100;
        for (int i = 0; i <= iterRefine; i++) {
            if (i % 10 == 0) {
                double[] m = bmRefine.checkObj();
                // bmRefine.checkRepPerCluster();
                // System.out.println(bmRefine.reps[0] + " " + bmRefine.reps[1]);
                if (m.length > 1) {
                    System.out.println(i + " " + m[0] + " " + m[1] + " " + m[2]);
                } else {
                    System.out.println(i + " " + m[0]);
                }
                //  System.out.println(bmRefine.j);
            }
            bmRefine.immediateUpdate();

        }
        // ea.displayBorder(1000, data, bmRefine);

//        System.out.println("clusterChanged " + clusterChanged);
        ea.displayClusters(data, labels, bmRefine.getIds(), bmRefine.getCertainty(), "result");
        //ea.displayCertainty(data, labels, bmRefine.getIds(), bmRefine.getCertainty());
        ea.saveforNMI(bmRefine.getIds(), labels);

    }

}
