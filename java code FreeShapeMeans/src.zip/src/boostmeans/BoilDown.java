/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boostmeans;

import java.util.Random;

/**
 *
 *
 */
public class BoilDown {

    double[][] data;
    int labels[];
    BMResult bestResult;
    FreeShapeMeans bestClusterer;
    int numTry;
    int k;
    int d;
    int numObj;
    int seed;
    Random r;
    static int checkIntervall = 10; //number of steps before check of objective function
    static int backTrackingCounter = 3; //number of steps in backtracking
    static int maxIterations = 1000; //maximmal number of iterations in the algorithm
    static int maxNumRep = 100;
    static double imprSig = 0.001; //check for significant improvement of objective function
    double repPercentage = 0.01; //how many reps in the initialization phase
    static boolean verbose = true;

    public BoilDown(double[][] data, int k, int seed, int[] labels) {
        this.data = data;
        this.labels = labels;
        numObj = data.length;
        d = data[0].length;
        this.k = k;
        this.seed = seed;
        r = new Random(seed);
        bestResult = new BMResult();

    }

    public BoilDown(double[][] data, int k, int seed, int[] labels, BMResult bestResult) {
        this.data = data;
        this.labels = labels;
        numObj = data.length;
        d = data[0].length;
        this.bestResult = bestResult;
        this.k = k;
        this.seed = seed;
        r = new Random(seed);
    }

    public int[] randomInit() {
        KMeans km = new KMeans(k, data);
        return km.randomInit(seed);

    }

    public void runSimple() {
        int[] ii = randomInit();
        bestResult.clId = ii;
        bestResult.reps = new int[k];
        bestResult.reps[0] = 1;
        bestResult.reps[1] = 1;
        initalizationPhase();
        refinementPhaseNew();
    }

    public void run() {

        initalizationPhase();

        //refinementPhaseSimple();
       refinementPhaseNew();
        //refine();
        if (verbose) {
            printClusterSummary();
        }
    }

    private void displayCertainty() {
        IO ea = new IO();
        ea.displayCertainty(data, labels, bestResult.getClId(), bestResult.getObjectQuality());

    }

    public void refine() {
        printClusterSummary();
        displayClusters("starting refinement");
        reduceComplexityGlobal();
        int[] aRep = new int[k];
        for (int i = 0; i < k; i++) {
            aRep[i] = setComplexityBottomUp(i);
            if (aRep[i] == -1) {
                aRep[i] = bestResult.getReps()[i];
            }
        }
        iterateDown(aRep, 3, false);
        aRep = new int[k];
        for (int i = 0; i < k; i++) {
            aRep[i] = setComplexityBottomUp(i);
            if (aRep[i] == -1) {
                aRep[i] = bestResult.getReps()[i];
            }
        }
        reduceComplexityGlobal();
        iterateDown(aRep, 5, false);
        aRep = new int[k];
        for (int i = 0; i < k; i++) {
            aRep[i] = setComplexityBottomUp(i);
            if (aRep[i] == -1) {
                aRep[i] = bestResult.getReps()[i];
            }
        }
        displayCertainty();

//         displayClusters("init");
//        printClusterSummary();
//        
//         iterateDown(bestResult.reps, 3);
//        
//        int[] aRep = new int[k];
//        for (int i = 0; i < k; i++) {
//            aRep[i] = setComplexityBottomUp(i);
//            if (aRep[i] == -1) {
//                aRep[i] = bestResult.getReps()[i];
//            }
//        }
//        
//       
//     
////        aRep = new int[k];
////        for (int i = 0; i < k; i++) {
////            aRep[i] = setComplexityBottomUp(i);
////            if (aRep[i] == -1) {
////                aRep[i] = bestResult.getReps()[i];
////            }
////        }
//        iterateDown(aRep, 5);
        // refinementPhase();
    }

    //returns true if result was best
    private BMResult improvementFixedIter(int[] nReps, int[] currIds, int nTry, int iter) {
        FreeShapeMeans bm = new FreeShapeMeans(currIds, data, k, nReps, nTry, r.nextInt());
        // this.bestClusterer = bm;
        for (int i = 0; i < iter; i++) {
            bm.immediateUpdate();
        }

        BMResult res = new BMResult(bm.getIds(), bm.getCertainty(), bm.getReps(), bm.getClusterQuality(), bm.getClusterCount(), bm.checkObj()[0], bm.seed);
        //test
//        System.out.println("a " + bm.checkObj()[0]);
//        System.out.println("b " + bm.checkObj()[0]);
//        System.out.println("c " + bm.checkObj()[0]);
        return res;
    }

    private BMResult improvementFixedIter(int[] nReps, int[] currIds, int iter) {
        FreeShapeMeans bm = new FreeShapeMeans(currIds, data, k, nReps, r.nextInt());
        this.bestClusterer = bm;
        for (int i = 0; i < iter; i++) {
            bm.hoeffdingAssign(0.05, 100);
        }

        BMResult res = new BMResult(bm.getIds(), bm.getCertainty(), bm.getReps(), bm.getClusterQuality(), bm.getClusterCount(), bm.checkObj()[0], bm.seed);
        //test
//        System.out.println("a " + bm.checkObj()[0]);
//        System.out.println("b " + bm.checkObj()[0]);
//        System.out.println("c " + bm.checkObj()[0]);
        return res;
    }

    private BMResult improvementFixedIter(int[] currIds, int nTry, int iter) {
        FreeShapeMeans bm = new FreeShapeMeans(currIds, data, k, nTry, r.nextInt());
        this.bestClusterer = bm;
        for (int i = 0; i < iter; i++) {
            bm.setRepPerCluster(repPercentage);
            bm.immediateUpdate();
        }
        BMResult res = new BMResult(bm.getIds(), bm.getCertainty(), bm.getReps(), bm.getClusterQuality(), bm.getClusterCount(), bm.checkObj()[0], bm.seed);
        return res;
    }

    private BMResult improvementFixedIterInit(int[] currIds, int iter) {
        FreeShapeMeans bm = new FreeShapeMeans(currIds, data, k, 1, r.nextInt());
        for (int i = 0; i < iter; i++) {
            bm.setRepPerCluster(repPercentage);
            bm.immediateUpdate();
        }
        BMResult res = new BMResult(bm.getIds(), bm.getCertainty(), bm.getReps(), bm.getClusterQuality(), bm.getClusterCount(), bm.checkObj()[0], bm.seed);
        return res;
    }

    private BMResult improvementFixedIterInitAvg(int[] currIds, int iter) {
        BoostMeansAvg bm = new BoostMeansAvg(currIds, data, k, 1, r.nextInt());
        for (int i = 0; i < iter; i++) {
            bm.setRepPerCluster(repPercentage);
            bm.immediateUpdate();
        }
        BMResult res = new BMResult(bm.getIds(), bm.getCertainty(), bm.getReps(), bm.getClusterQuality(), bm.getClusterCount(), bm.checkObj()[0], bm.seed);
        return res;
    }

    private double checkObj(int[] nReps, int[] currIds) {
        FreeShapeMeans bm = new FreeShapeMeans(currIds, data, k, nReps, r.nextInt());
        return bm.checkObj()[0];
    }

    private double checkObj(int[] nReps, int[] currIds, int seed) {
        FreeShapeMeans bm = new FreeShapeMeans(currIds, data, k, nReps, seed);
        return bm.checkObj()[0];
    }

    //retruns the number of reps which gives almost the same result for the cluster
    public int complexity(int cl) {
        int[] currReps = new int[k];
        for (int i = 0; i < k; i++) {
            currReps[i] = bestResult.getReps()[i];
        }
        int clRep = bestResult.getReps()[cl];
        boolean accurateEnough = true;
        while (accurateEnough && clRep > 1) {
            currReps[cl] = clRep;
            double obj = checkObj(currReps, bestResult.getClId(), bestResult.seed);
            if (obj >= (bestResult.getObj() - imprSig)) {
                clRep--;
            } else {
                accurateEnough = false;
            }
        }
        return clRep;
    }

    //adjust cluster wise complexity
    public int setComplexityBottomUp(int cl) {
        System.out.println("so far best cost: " + bestResult.getObj());
        if (verbose) {
            System.out.println("adjusting complexity of cluster " + (cl + 1));
        }
        int[] currReps = new int[k];
        for (int i = 0; i < k; i++) {
            currReps[i] = bestResult.getReps()[i];
        }
        int numRep = 1;
        currReps[cl] = 1;
        boolean improvement = true;
        //baseline cost: costs with one rep
        double bestObj = checkObj(currReps, bestResult.getClId());
        if (verbose) {
            System.out.println("1: " + bestObj);
        }
        int count = 0;
        int bestNumRep = 1;
        while (improvement) {
            numRep++;
            currReps[cl] = numRep;
            double obj = checkObj(currReps, bestResult.getClId());
            if (verbose) {
                System.out.println(numRep + " " + obj);
            }
            if (obj > (bestObj + imprSig)) {
                bestObj = obj;
                count = 0;
                bestNumRep = numRep;
            } else {
                count++;
                if (count == backTrackingCounter) {
                    improvement = false;
                }
            }
        }

        if (bestObj < bestResult.getObj()) {
            bestNumRep = -1;
        }
        if (verbose) {
            System.out.println("bestComplexity: " + bestNumRep);
        }
        return bestNumRep;
    }

    public void reduceComplexityGlobal() {
        boolean improvement = true;
        int[] currReps = new int[k];
        int minReps = Integer.MAX_VALUE;
        for (int i = 0; i < k; i++) {
            currReps[i] = bestResult.getReps()[i];
            if (currReps[i] < minReps) {
                minReps = currReps[i];
            }
        }
        int count = 0;
        while (improvement && minReps > 1) {
            for (int i = 0; i < k; i++) {
                currReps[i]--;
            }
            minReps--;
            double obj = checkObj(currReps, bestResult.getClId());
//            if(verbose)
//                System.out.println(obj);
            if (obj >= (bestResult.getObj() - imprSig)) {
                bestResult.setObj(obj);
                bestResult.setReps(currReps);
                count = 0;
            } else {
                count++;
                if (count == backTrackingCounter) {
                    improvement = false;
                }
            }
        }
        if (verbose) {
            System.out.println("After reduceComplexityGlobal:");
            printClusterSummary();
        }

    }

//    //try to reach a new local Optimum of the objective function with this configuration. For all clusters the same number of represenatives. If yes, writes global variables, if no, returns false
//    private boolean localOptimum(int[] nReps, int nTry) {
//        FreeShapeMeans bm = new FreeShapeMeans(ids, data, k, nReps, nTry);
//        int iter = 0;
//        int backtrack = 0;
//        boolean improvement = true;
//        boolean optimumFound = false;
//        while (improvement) {
//            if (iter % checkIntervall == 0) {
//                double[] m = bm.checkObj();
//                if (verbose) {
//                    System.out.println(iter + " " + m[0] + " " + m[1] + " " + m[2]);
//                }
//                if (m[0] > bestObj) {
//                    //copy ids, certainty and bestObj
//                    bestObj = m[0];
//                    for (int i = 0; i < numObj; i++) {
//                        ids[i] = bm.ids[i];
//                    }
//                    for (int i = 0; i < numObj; i++) {
//                        certainty[i] = bm.certainty[i];
//                    }
//                    numTry = nTry;
//                    for (int i = 0; i < k; i++) {
//                        numRep[i] = nReps[i];
//                    }
//                    backtrack = 0;
//                    optimumFound = true;
//                } else {
//                    backtrack++;
//                    if (backtrack > backTrackingCounter) {
//                        improvement = false;
//                    }
//                }
//            }
//            bm.immediateUpdate();
//            iter++;
//            if (iter > maxIterations) {
//                improvement = false;
//            }
//        }
//        return optimumFound;
//    }
    //try to decrease the number of reps for each cluster; without new assignment? and then with new assignment; increase the number of trials
//    private void refinementPhase() {
//        //rivate BMResult improvementFixedIter(int[] nReps, int[] currIds, int nTry, int iter) {
//        int aktNumTry = 5;
//        boolean improvement = true;
//        int count = 0;
//        int[] currIds = new int[numObj];
//        System.arraycopy(bestResult.getClId(), 0, currIds, 0, numObj);
//        while (improvement) {
//            reduceComplexityGlobal();
//            BMResult b = improvementFixedIter(bestResult.getReps(), currIds, aktNumTry, checkIntervall);
//            if (verbose) {
//                System.out.println(b.obj);
//            }
//            if (b.obj > bestResult.getObj()) {
//                System.arraycopy(b.getClId(), 0, currIds, 0, numObj);
//                bestResult = new BMResult(b);
//                count = 0;
//            } else {
//                count++;
//                if (count == backTrackingCounter) {
//                    improvement = false;
//                } else {
//                    System.arraycopy(b.getClId(), 0, currIds, 0, numObj);
//                }
//
//            }
//        }
//        if (verbose) {
//            printClusterSummary();
//            displayClusters("refinement phase");
//        }
//
//    }
    private void displayClusters(String title) {
        IO ea = new IO();
        ea.displayClusters(data, labels, bestResult.getClId(), bestResult.getObjectQuality(), title);
    }

    public boolean checkComplexity(int currentNumTry, int nextNumTry, double reduction) {
        boolean modifiedComplexity = false;
        boolean[] improvement = new boolean[k];
        for (int i = 0; i < k; i++) {
            improvement[i] = true;
        }
        boolean globalImprovement = true;
        while (globalImprovement) {
            for (int i = 0; i < k; i++) {
                if (improvement[i]) {
                    if (verbose) {
                        System.out.println("Trying to reduce the complexity of cluster " + i);
                    }
                    int[] nReps = new int[k];
                    for (int j = 0; j < k; j++) {
                        nReps[j] = bestResult.getReps()[j];
                    }
                    nReps[i] = (int) Math.round(nReps[i] * reduction);
                    if (nReps[i] >= 1) {
                        BMResult b1 = iterateDown(bestResult, nReps, currentNumTry);
                        BMResult b3 = iterateDown(b1, nReps, nextNumTry);
                        if (b3.getObj() >= bestResult.getObj()) {
                            bestResult = new BMResult(b3);
                            if (verbose) {
                                System.out.println("new best obj: " + bestResult.getObj());
                                printClusterSummary();
                                displayClusters("improvement");
                            }
                            improvement[i] = true;
                            modifiedComplexity = true;
                            if (nReps[i] == 1) {
                                improvement[i] = false;
                            }
                        } else {
                            improvement[i] = false;
                        }
                    } else {
                        improvement[i] = false;
                    }
                }
            }
            globalImprovement = false;
            for (int i = 0; i < k; i++) {
                if (improvement[i]) {
                    globalImprovement = true;
                }
            }
        }
        return modifiedComplexity;
    }

    public void refinementPhaseSimple() {
        if (verbose) {
            printClusterSummary();
            displayClusters("init");
        }
        boolean simplified = checkComplexity(1, 3, 0.5);
        iterateDown(bestResult.getReps(), 5, false);
        //int[] reps = new int[k];
        simplified = checkComplexity(7, 10, 0.5);
        //simplified = checkComplexity(5, 7, 0.5);
//        iterateDown(bestResult.getReps(), 12, false);
        iterateDown(bestResult.getReps(), 0, true);
    }

    public void refinementPhaseNew() {
//        if (verbose) {
//            printClusterSummary();
//            displayClusters("init");
//        }
//        //boolean simplified = checkComplexity(1, 3, 0.5);
        iterateDown(3);
        iterateDown(5);
        //int[] reps = new int[k];
        // boolean simplified = checkComplexity(5, 7, 0.5);
//        iterateDown(bestResult.getReps(), 12, false);
        iterateDown(bestResult.getReps(), 0, true);
    }

    private void initalizationPhase() {
        repPercentage = 0.01;
        boolean improvement = true;
        int[] currIds = randomInit();

        int count = 0;

        while (improvement) {
            BMResult b = improvementFixedIterInit(currIds, checkIntervall);

             //BMResult b = improvementFixedIter(nRep, currIds, 1, checkIntervall);
            if (verbose) {
                System.out.println(b.obj);

            }
            if (b.obj > bestResult.getObj()) {
                bestResult = new BMResult(b);
//                if (verbose) {
//                    displayClusters("initialization phase");
//                }
            

            count = 0;
        }else {
                count++;
                if (count > backTrackingCounter) {
                    improvement = false;
                }
            }
        currIds = new int[numObj];
        for (int i = 0; i < numObj; i++) {
            currIds[i] = b.getClId()[i];
        }
    }

    if (verbose

    
        ) {
            printClusterSummary();
        BMResult.writeToFile("init", bestResult);
        displayClusters("initialization phase");
    }
    //reduceComplexityGlobal();
}

private BMResult iterateDown(BMResult start, int[] nReps, int nTry) {
        BMResult res = new BMResult();
        res.setObj(0.0);
        boolean improvement = true;
        int[] currIds = new int[numObj];
        for (int i = 0; i < numObj; i++) {
            currIds[i] = start.getClId()[i];
        }
        int count = 0;
        while (improvement) {
            BMResult b = improvementFixedIter(nReps, currIds, nTry, checkIntervall);
            if (verbose) {
                System.out.println(b.obj);
            }
            if (b.obj > res.getObj()) {
                res = new BMResult(b);
                count = 0;
            } else {
                count++;
                if (count == backTrackingCounter) {
                    improvement = false;
                }
            }
            for (int i = 0; i < numObj; i++) {
                currIds[i] = b.getClId()[i];
            }
        }
//        if (verbose) {
//            printClusterSummary();
//            //BMResult.writeToFile("init", bestResult);
//            displayClusters("iterated down with numTry " + nTry);
//        }
        //reduceComplexityGlobal();
        return res;
    }

    private void iterateDown(int[] nReps, int nTry, boolean polish) {
        if (verbose) {
            System.out.println("Iterate down " + nTry);
        }
        boolean improvement = true;
        int[] currIds = new int[numObj];
        for (int i = 0; i < numObj; i++) {
            currIds[i] = bestResult.getClId()[i];
        }
        int count = 0;
        while (improvement) {
            BMResult b = new BMResult();
            if (!polish) {
                b = improvementFixedIter(nReps, currIds, nTry, checkIntervall);

            } else {

                b = improvementFixedIter(nReps, currIds, checkIntervall);
            }

            if (verbose) {
                System.out.println(b.obj);
            }
            if (b.obj > bestResult.getObj()) {
                bestResult = new BMResult(b);
                count = 0;
            } else {
                count++;
                if (count == backTrackingCounter) {
                    improvement = false;
                }
            }
            for (int i = 0; i < numObj; i++) {
                currIds[i] = b.getClId()[i];
            }
        }
        if (verbose) {
            printClusterSummary();
            //BMResult.writeToFile("init", bestResult);
            displayClusters("iterated down with numTry " + nTry);
        }
        //reduceComplexityGlobal();

    }

    private void iterateDown(int nTry) {
        boolean improvement = true;
        int[] currIds = new int[numObj];
        for (int i = 0; i < numObj; i++) {
            currIds[i] = bestResult.getClId()[i];
        }
        int count = 0;
        while (improvement) {
            BMResult b = improvementFixedIter(currIds, nTry, checkIntervall);
            if (verbose) {
                System.out.println(b.obj);
            }
            if (b.obj > bestResult.getObj()) {
                bestResult = new BMResult(b);
                System.arraycopy(b.getClId(), 0, currIds, 0, numObj);
                count = 0;
            } else {
                count++;
                if (count == backTrackingCounter) {
                    improvement = false;
                } else {
                    System.arraycopy(b.getClId(), 0, currIds, 0, numObj);
                }
            }
        }
        if (verbose) {
            printClusterSummary();
            //BMResult.writeToFile("init", bestResult);
            displayClusters("iterated down with numTry " + nTry);
        }
        //reduceComplexityGlobal();

    }

    private void printClusterSummary() {
        System.out.println("---Best result---");
        System.out.println("Obj: " + bestResult.getObj());
        for (int i = 0; i < k; i++) {
            System.out.println("cluster " + (i + 1) + " " + bestResult.getClusterCount()[i] + " objects " + bestResult.getReps()[i] + " reps. Quality: " + bestResult.getClusterQuality()[i]);
        }

    }

//    //use for all clusters the same number of reps and nTry = 1
//    private void intitializationPhaseSelectNumRep() {
//        //select initial best number of reps
//        int nRep = 1;
//        int nTry = 1;
//        int[] reps = new int[k];
//        for (int i = 0; i < reps.length; i++) {
//            reps[i] = nRep;
//        }
//        int[] currIds = new int[numObj];
//        for (int i = 0; i < ids.length; i++) {
//            currIds[i] = ids[i];
//        }
//        boolean improvement = true;
//        int checkIter = 10;
//        int count = 0;
//        while (improvement) {
//            BMResult b = improvementFixedIter(reps, currIds, nTry, checkIter);
//            if (verbose) {
//                System.out.println(nRep + " " + b.obj);
//            }
//            if (b.obj > (bestObj + imprSig)) {
//                bestObj = b.obj;
//                for (int i = 0; i < numObj; i++) {
//                    ids[i] = b.clId[i];
//                }
//                for (int i = 0; i < k; i++) {
//                    numRep[i] = nRep;
//                }
//                count = 0;
//            } else {
//                count++;
//                if (count == backTrackingCounter) {
//                    improvement = false;
//                }
//            }
//            nRep++;
//            for (int i = 0; i < k; i++) {
//                reps[i] = nRep;
//            }
//        }
//        if (verbose) {
//            System.out.println("bestnumRep: " + numRep[0]);
//            displayClusters("initialization phase");
//        }
//    }
}
