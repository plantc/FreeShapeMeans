/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boostmeans;

/**
 *
 * @
 */
public class Subset {
    boolean[][] ss;
    double[] dist;

    public Subset(boolean[][] s, double[] dist) {
        this.ss = s;
        this.dist = dist;
    }
    
    
    
    
}
