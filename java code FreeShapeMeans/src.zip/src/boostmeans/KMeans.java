/*
 * Kmeans.java
 *
 * Created on February 17, 2005, 3:47 PM
 */
package boostmeans;

/**
 *
 * @author  Administrator
 */
import Jama.Matrix;
import java.util.*;
//import compr.*;
//import eval.Cluster;
//import visu.VisuKMeans;
//import visu.VisuVoronoi;

public class KMeans {
    int k;
    double[][] data;
    int dim;
    double[][] means;
    int iteration;
    int[] ids;
    double currentSquaredError;
    double lastSquaredError;
    //boolean verbose = true;
    boolean verbose = false;

    /** Creates a new instance of Kmeans */
    public KMeans(int k, double[][] data) {
        this.k = k;
        this.data = data;
        this.dim = data[0].length;
        this.means = new double[k][dim];
        this.iteration = 0;
        ids = new int[data.length];
    }

    public double[][] getMeans() {
        return means;
    }

    public int[] runOneStep(int randomSeed) {
        //Random r = new Random(5);
        Random r = new Random(randomSeed);
        for (int i = 0; i < k; i++) {
            int nextMean = r.nextInt(data.length);

            for (int j = 0; j < dim; j++) {
                means[i][j] = data[nextMean][j];
            }
        }
        boolean b = assignPoints();
        updateMeans();
        //TEST
//        for (int i = 0; i < data.length; i++) {
//            ids[i] = data[i].clusterID;
//        }
        return ids;
    }
    
    public int[] randomInit(int randomSeed){
        int[] l = new int[data.length];
        Random r = new Random(randomSeed);
        for(int i = 0; i < l.length; i++)
            l[i] = r.nextInt(k) + 1;
        return l;
    }

    public int[] run(int randomSeed) {
        if (verbose) {
            System.out.println("k-means: k: " + k + " numObj: " + data.length);
        }
        //init
        //Random r = new Random(5);
        Random r = new Random(randomSeed);
        for (int i = 0; i < k; i++) {
            int nextMean = r.nextInt(data.length);

            for (int j = 0; j < dim; j++) {
                means[i][j] = data[nextMean][j];
            }
        }
        boolean b = assignPoints();
        //updateMeans();
        //mdlUpdateMeans();
        iteration++;
        boolean done = false;
        while (!done && iteration < 1000) {
            lastSquaredError = currentSquaredError;
            currentSquaredError = 0.0;
            updateMeans();
            boolean clusterChanged = assignPoints();
            iteration++;
            if (verbose) {
                System.out.println(iteration + " " + currentSquaredError + " change: " + (lastSquaredError - currentSquaredError));
            }
            if (!clusterChanged || lastSquaredError == currentSquaredError) {
                done = true;
            }
        }
        //mdlAssignPoints();

        if (verbose) {
            System.out.println(iteration + " iterations");
//            VisuKMeans visu = new VisuKMeans(db.store, means, k);
//            visu.setSize(600,600);
//            visu.setLocation(500,500);
//            visu.setVisible(true);
        //Draw clusters with visuVoronoi
//            Cluster[] cl = new Cluster[k];
//            for(int i = 0; i < k; i++){
//                cl[i] = new Cluster();
//                cl[i].ID = i+1;
//                cl[i].mean = new double[dim];
//                for(int j = 0; j < dim; j++)
//                    cl[i].mean[j] = means[i][j];
//            }
//            VisuVoronoi visu = new VisuVoronoi(db.store, cl);
//            visu.setSize(600,600);
//            visu.setLocation(500,500);
//            visu.setVisible(true);
        }

        //TEST
//        for (int i = 0; i < data.length; i++) {
//            ids[i] = data[i].clusterID;
//        }
        return ids;
    }
    
    public double getVar(){
        return currentSquaredError/(data.length-1);
    }
    
    
    public double getPDF(double[] o, int id, double var){
        return gaussPDF(o, means[id-1], var);
        
    }
    
    
    private double gaussPDF(double[] coord, double[] mean, double var) {
        Matrix sigmaInv = new Matrix(coord.length, coord.length);
        for (int i = 0; i < sigmaInv.getColumnDimension(); i++) {
            sigmaInv.set(i, i, 1.0 / var);
        }
        double[] meanDiff = new double[coord.length];
        for (int i = 0; i < coord.length; i++) {
            meanDiff[i] = coord[i] - mean[i];
        }
        double[][] ex = rowVector(meanDiff).times(sigmaInv).times(colVector(meanDiff)).getArrayCopy();
        double exU = -0.5 * ex[0][0];
        double factor = 1.0 / Math.sqrt((2.0 * Math.PI) * Math.pow(var, coord.length));
        return factor * Math.exp(exU);
    }
    
    
    private Matrix rowVector(double[] d) {
        Matrix m = new Matrix(1, d.length);
        for (int i = 0; i < d.length; i++) {
            m.set(0, i, d[i]);
        }
        return m;
    }

    private Matrix colVector(double[] d) {
        Matrix m = new Matrix(d.length, 1);
        for (int i = 0; i < d.length; i++) {
            m.set(i, 0, d[i]);
        }
        return m;
    }
    
    
    private void printClusterAss() {
        for (int i = 0; i < data.length; i++) {
            System.out.println("DO " + i + " clusterID " + ids[i]);
        }
    }

    private void printClusterMembers() {
        int[] clMembers = new int[k];
        for (int i = 0; i < data.length; i++) {
            clMembers[ids[i] - 1]++;
        }
        for (int i = 0; i < clMembers.length; i++) {
            System.out.println("Cluster " + (i + 1) + " " + clMembers[i] + " objects");
        }

    }

    private void printMeans() {
        System.out.println("printing means");
        for (int i = 0; i < k; i++) {
            System.out.println("M ");
            for (int j = 0; j < dim; j++) {
                System.out.print(means[i][j] + " ");
            }
            System.out.println();
        }
    }

    public int[] getIds() {
        return ids;
    }

    
    
    private boolean assignPoints() {
        boolean clusterChanged = false;
        for (int i = 0; i < data.length; i++) {
            int aktClustID = findNextCluster(i);
            if (ids[i] != aktClustID) {
                clusterChanged = true;
            }
            ids[i] = aktClustID;
        }
        return clusterChanged;
    }

    
    public int getClusterId(double[] o){
       double minDist = Double.MAX_VALUE;
        int minIndex = Integer.MAX_VALUE;
        for (int i = 0; i < means.length; i++) {
            double[] aktMean = new double[dim];
            for (int j = 0; j < aktMean.length; j++) {
                aktMean[j] = means[i][j];
            }
            //double aktDist = mdlDistance(d, aktMean);
            double aktDist = distance(o, aktMean);
            if (aktDist < minDist) {
                minDist = aktDist;
                minIndex = i + 1;
            }
        }
        return minIndex;  
    }
    
    private int findNextCluster(int  index_d) {
        double minDist = Double.MAX_VALUE;
        int minIndex = Integer.MAX_VALUE;
        for (int i = 0; i < means.length; i++) {
            double[] aktMean = new double[dim];
            for (int j = 0; j < aktMean.length; j++) {
                aktMean[j] = means[i][j];
            }
            //double aktDist = mdlDistance(d, aktMean);
            double aktDist = distance(data[index_d], aktMean);
            if (aktDist < minDist) {
                minDist = aktDist;
                minIndex = i + 1;
            }
        }
        currentSquaredError += minDist * minDist;
        return minIndex;
    }

    private double distance(double[] d, double[] mean) {
        double sum = 0.0;
        for (int i = 0; i < d.length; i++) {
            double dist = ((d[i] - mean[i]) * (d[i] - mean[i]));
            sum = sum + dist;
        }
        return Math.sqrt(sum);
    }

    private void updateMeans() {
        for (int i = 0; i < k; i++) {
            int counter = 0;
            for (int j = 0; j < data.length; j++) {
                if (ids[j] == i + 1) {
                    //for(int l = 0; l < dim; l++)
                    //means[i][l]+= db.store[j].coord[l];
                    counter++;
                }
            }
            if (counter > 0) {
                for (int j = 0; j < dim; j++) {
                    means[i][j] = 0.0;
                }
                for (int j = 0; j < data.length; j++) {
                    if (ids[j] == i + 1) {
                        for (int l = 0; l < dim; l++) {
                            means[i][l] += data[j][l];
                        }
                    //counter++;
                    }
                }
                for (int l = 0; l < dim; l++) {
                    means[i][l] = means[i][l] / (double) counter;
                }
            }
        }
    //this.means = means;
    }
}
