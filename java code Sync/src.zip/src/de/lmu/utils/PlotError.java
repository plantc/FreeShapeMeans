package de.lmu.utils;

import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;

import javax.swing.*;

import de.lmu.database.*;


/**
 * Plot Error
 * 
 * @author Junming Shao
 * @param None
 * Created on 26. Mar. 2009, 
 */

public class PlotError extends javax.swing.JFrame{
	double[] err;
	int[] k;
 
    public PlotError(double[] err, int[] k){
    	this.err = err;
    	this.k = k;
    	System.out.println("Plot ERROR-KCluter Relationship.");
        DrawPanel pl = new DrawPanel();
        pl.setBackground(Color.WHITE);
        getContentPane().add(pl, BorderLayout.CENTER);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
   //Test
    /*
    public  static void main(String[] args){
    	double[] error = new double[5];
    	int[] k = new int[5];
    	
    	for(int i=0;i<error.length;i++){
    		error[i] = 2*Math.pow(i+1, 2)+5;
    		k[i] = i;
    	}
    	
    	PlotError plot = new PlotError(error,k);
    	plot.setTitle("Error-KCluter Curve");
        plot.setSize(800, 600);
        plot.setLocation(200, 200);
        plot.setVisible(true);	 
    }*/

    public PlotError() {
		// TODO Auto-generated constructor stub
	}

	public class DrawPanel extends JPanel{

        public void paintComponent(Graphics g) {
        	
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setStroke(new BasicStroke(2.0f));
            
            Line2D.Float x = new Line2D.Float(50.0f, 520.0f, 750.0f, 520.0f);
            Line2D.Float y = new Line2D.Float(50.0f, 20.0f, 50.0f, 520.0f);
            
            g2.draw(x);
            g2.draw(y);     
            
            g.setFont(new Font("Serif",Font.BOLD,14));  
            // x-axis
            float intervalx = (700f-50f)/k.length;
            double maxM = -Double.MAX_VALUE;
            for(int i=0;i<k.length;i++){
            	Line2D.Float ax = new Line2D.Float(50.0f+intervalx*(i+1), 517.0f, 50.0f+intervalx*(i+1), 523.0f);
            	g2.draw(ax);
            	g.drawString(""+(i+1), (int)(50+intervalx*(i+1)), 540); 
            	if(err[i]>maxM){
            		maxM = err[i];
            	}
            }            
            g.drawString("Number of Clusters", 350, 555); 
            
            
            // y-axis
            
            float intervaly = (480f-20f)/k.length;     
            
            for(int i=0;i<k.length;i++){
            	Line2D.Float ay = new Line2D.Float(47.0f, 520.0f-intervaly*(i+1), 53.0f, 520.0f-intervaly*(i+1));
            	g2.draw(ay);

            }             
            float iny = (float) (maxM/k.length);
            g2.rotate(Math.PI/2, 20, 200);
            g.drawString("Average Error with scale "+ iny, 20, 200);
            g2.rotate(-Math.PI/2, 20, 200);
            
            
            Line2D.Float arrowx1 = new Line2D.Float(740f, 515.0f, 750f, 520.0f);
            Line2D.Float arrowx2 = new Line2D.Float(740f, 525.0f, 750f, 520.0f);
            g2.draw(arrowx1);
            g2.draw(arrowx2);
            Line2D.Float arrowy1 = new Line2D.Float(45f, 32.0f, 50.0f, 20.0f);
            Line2D.Float arrowy2 = new Line2D.Float(55f, 32.0f, 50.0f, 20.0f);
            g2.draw(arrowy1);
            g2.draw(arrowy2);            
            //The ERROR-K Curve
            
            for(int i=0;i<k.length-1;i++){
            	Line2D.Float ay = new Line2D.Float(50+intervalx*(i+1), (float) (520.0f-(err[i]/iny)*intervaly), 50+intervalx*(i+2), (float) (520.0f-(err[i+1]/iny)*intervaly));
            	g2.setColor(Color.RED);
            	g2.draw(ay);
            	
            }              
        }
    }
}