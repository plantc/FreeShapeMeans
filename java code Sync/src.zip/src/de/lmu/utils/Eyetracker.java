package de.lmu.utils;

import java.io.*;
import java.util.Map;
import java.util.Iterator;
import java.util.ArrayList;

import weka.core.Instances;

import com.jmatio.io.MatFileReader;
import com.jmatio.types.*;


/**
 * Read the matrix data (.mat) from matlab
 * 
 * @author Junming Shao
 * @param None
 * Created on 17. Mar. 2009, 
 */


public class Eyetracker {
   
    /** Creates a new instance of ReadMat
     * @param none
     */
    public Eyetracker() {

    }
    
      
    
    /**
     * Load the database from a given filename
     * @param Filename
     * @return none
     */
    public void readData(String infn, String outfn1, String outfn2){
    	
    	//Calculate the number of rows
    	int row = 0; int ntar = 0 ;
    	double[] idx_targ_time = new double[20];
        try {
        	File mFile = new File(infn);
        	FileReader fr = new FileReader(mFile);
        	BufferedReader br = new BufferedReader(fr);
        	String line;
        	
        	while((line=br.readLine())!=null){
        		line = line.trim();        		
        		String[] str = line.split("\\s+");
        		//System.out.println(line);
        		if(Integer.parseInt(str[0])==10){
        			row = row + 1;	
        		}
        		if(Integer.parseInt(str[0])==12 && ntar<20){        			
        			idx_targ_time[ntar] = Double.parseDouble(str[1]);
        			ntar = ntar + 1;
        		}
        	}
        } catch (IOException ex) {
            ex.printStackTrace();
        } 
        System.out.println("Number of Objects:" +row + " ; number of target:  " + ntar);

        
    	double[][] data = new double[row][11];
    	int n = 0;
        try {
        	File mFile = new File(infn);
        	FileReader fr = new FileReader(mFile);
        	BufferedReader br = new BufferedReader(fr);
        	String line;
        	
        	while((line=br.readLine())!=null){
        		line = line.trim();        		
        		String[] str = line.split("\\s+");
        		if(Integer.parseInt(str[0])==10){
            		for(int i=0;i<11;i++){
            			data[n][i]= Double.parseDouble(str[i]);
            		}
            		n = n + 1;
        		}
        	}
        } catch (IOException ex) {
            ex.printStackTrace();
        } 
        
	    try{
			FileOutputStream fout = new FileOutputStream(new File(outfn1)); 
			for(int i=0;i<row;i++){   
				for(int d =0;d<11;d++){
					fout.write(((Double)(data[i][d])+"\t").getBytes());    				
				}
				fout.write(("\r\n").getBytes()); 
			}   
	    } catch (IOException ex) {
	        ex.printStackTrace();
	    }    
	    
	    try{
			FileOutputStream fout = new FileOutputStream(new File(outfn2)); 
			for(int i=0;i<ntar;i++){   
				fout.write(((Double)(idx_targ_time[i])+"\t").getBytes());    				
				fout.write(("\r\n").getBytes()); 
			}   
	    } catch (IOException ex) {
	        ex.printStackTrace();
	    }   
	    
    }
        
    /**
     * Load the database from a given filename
     * @param Filename
     * @return none
     */
    public void readfmriLogData(String infn, String outfn1){
    	
    	//Calculate the number of rows
    	int row = 0; int ntar = 0 ;
    	double[] idx_targ_time = new double[21];
    	double[] idx_mask_time = new double[21];
    	double end_time = 0.0;
    	int n = 0;
    	
        try {
        	File mFile = new File(infn);
        	FileReader fr = new FileReader(mFile);
        	BufferedReader br = new BufferedReader(fr);
        	String line;
        	
        	while((line=br.readLine())!=null){
        		line = line.trim();  
        		n = n + 1;
        		String[] str = line.split("\\s+");
        		int t = 0;
        		for(int d =0;d<str.length;d++){
        			if(str.length>5){
	        			if(n<10&& str[1].equalsIgnoreCase("0")){
	        				idx_targ_time[0] = Double.parseDouble(str[4]);
	        			}     
        			}
        			if(str[d].equalsIgnoreCase("Target")){
        				ntar = ntar + 1;
        				idx_targ_time[ntar] = Double.parseDouble(str[d+1]);       				
        			}
        			if(str[d].equalsIgnoreCase("Mask")){
        				idx_mask_time[ntar] = Double.parseDouble(str[d+1]);
        			}      
        			if(str[d].equalsIgnoreCase("Fixation")){
        				idx_mask_time[0] = Double.parseDouble(str[d+1]);
        			}         			
        		}
        	}
        } catch (IOException ex) {
            ex.printStackTrace();
        } 
        System.out.println("Number of Objects:" +row + " ; number of target:  " + ntar);

        
	    try{
			FileOutputStream fout = new FileOutputStream(new File(outfn1)); 
			for(int i=0;i<=ntar;i++){   
				fout.write(((Double)(idx_targ_time[i])+"\t").getBytes());  
				fout.write(((Double)(idx_mask_time[i])+"\t").getBytes());
				fout.write(("\r\n").getBytes()); 
			}   
	    } catch (IOException ex) {
	        ex.printStackTrace();
	    }    	   
	    
    }    
    
    /**
     * Load the database from a given filename
     * @param Filename
     * @return none
     */
    public void readeyeTrackerData(String infn1, String infn2, String outfn1){
    	   	
    	int row = 0; 
    	double[][] idx_tarMask_time = new double[21][2];
        try {
        	File mFile = new File(infn1);
        	FileReader fr = new FileReader(mFile);
        	BufferedReader br = new BufferedReader(fr);
        	String line;
        	
        	while((line=br.readLine())!=null){
        		line = line.trim();        		
        		String[] str = line.split("\\s+");
        		idx_tarMask_time[row][0] = Double.parseDouble(str[0]);
        		idx_tarMask_time[row][1] = Double.parseDouble(str[1]);
        		row = row +1;
        	}
        } catch (IOException ex) {
            ex.printStackTrace();
        } 

        double fmriAllTime = idx_tarMask_time[0][1]- idx_tarMask_time[0][0];
        double[][] fmriTime = new double[20][2];
        for(int i=0;i<20;i++){
        	fmriTime[i][0] = idx_tarMask_time[i+1][0]-idx_tarMask_time[0][0];
        	fmriTime[i][1] = idx_tarMask_time[i+1][1]-idx_tarMask_time[0][0];
        	System.out.println("fMRI time: " + fmriTime[i][0] + ", " + fmriTime[i][1]);
        }
        
        double eyetrackTime = 0.0;       
        try {
	        	File mFile = new File(infn2);
	        	FileReader fr = new FileReader(mFile);
	        	BufferedReader br = new BufferedReader(fr);
	        	String line; 
	
	        	while((line=br.readLine())!=null){
	        		line = line.trim();        	 		
	        		String[] str = line.split("\\s+");
	        		      		
	        		if(Integer.parseInt(str[0])==12){
	        			eyetrackTime = Double.parseDouble(str[1]);
	        			
	        		}
	        		
	        	}
	        	

        	} catch (IOException ex) {
    	        ex.printStackTrace();
    	    }    
        	
        	//System.out.println("==============eyetracker time = =============================="  + eyetrackTime);
        	
    	//Calculate the number of rows
    	int ntar = 0; 
    	int nn = 0;
        try {
        	File mFile = new File(infn2);
        	FileReader fr = new FileReader(mFile);
        	BufferedReader br = new BufferedReader(fr);
        	String line; 
        	String[] preline = null;
        	ArrayList targ_coord = new ArrayList();
        	
        	int flag = 0;
        	
        	while((line=br.readLine())!=null){
        		line = line.trim();      
        		nn = nn + 1;
        		String[] str = line.split("\\s+");
        		
        		if(nn>10){
        		if(Integer.parseInt(str[0])==10 && ntar<20 && Double.parseDouble(preline[1])*(fmriAllTime/eyetrackTime)<fmriTime[ntar][0] && Double.parseDouble(str[1])*(fmriAllTime/eyetrackTime)>fmriTime[ntar][1]){
        			System.out.println("fMRI Log Target start === "+ fmriTime[ntar][0] +" =====" + ntar + "  " + nn);
        			System.out.println(Double.parseDouble(preline[1])*(fmriAllTime/eyetrackTime));
        			
        			ArrayList in_targ_coord = new ArrayList();
        			double[] tempd = new double[11];
        			//if(Integer.parseInt(preline[0])!=12){
	            		for(int i=0;i<11;i++){            			
	            			tempd[i]= Double.parseDouble(preline[i]);
	            		} 
	            		//System.out.println(Double.parseDouble(preline[1])*(fmriAllTime/eyetrackTime));
	            		in_targ_coord.add(tempd);
        			//}
        			
            		for(int i=0;i<11;i++){
            			tempd[i]= Double.parseDouble(str[i]);
            		}
            		System.out.println(Double.parseDouble(str[1])*(fmriAllTime/eyetrackTime));
            		in_targ_coord.add(tempd);
            		
        			System.out.println("fMRI Log End === "+ fmriTime[ntar][1] +" =====");
        			//System.out.println("number of time steps: " + in_targ_coord.size());
        			targ_coord.add(in_targ_coord);
        			
        			ntar = ntar + 1;
        			
        		}

        		}        		
//        		if(nn ==15000)
//        			System.out.println("========================================================Test =====");
        		if(Integer.parseInt(str[0])==10 && nn>10 && ntar<20 && Double.parseDouble(str[1])*(fmriAllTime/eyetrackTime)>=fmriTime[ntar][0] && Double.parseDouble(str[1])*(fmriAllTime/eyetrackTime)<=fmriTime[ntar][1]){
        			System.out.println("fMRI Log Target start === "+ fmriTime[ntar][0] +" =====" + ntar + "  " + nn);
        			System.out.println(Double.parseDouble(preline[1])*(fmriAllTime/eyetrackTime));
        			
        			ArrayList in_targ_coord = new ArrayList();
        			double[] tempd = new double[11];
        			//if(Integer.parseInt(preline[0])!=12){
	            		for(int i=0;i<11;i++){            			
	            			tempd[i]= Double.parseDouble(preline[i]);
	            		} 
	            		in_targ_coord.add(tempd);
        			//}
        			
            		for(int i=0;i<11;i++){
            			tempd[i]= Double.parseDouble(str[i]);
            		}
            		System.out.println(Double.parseDouble(str[1])*(fmriAllTime/eyetrackTime));
            		in_targ_coord.add(tempd);
            		
            		double t = 0.0;
        			while(t<=fmriTime[ntar][1] && (line=br.readLine())!=null){   			
                		line = line.trim();    
                		nn = nn + 1;
                		String[] str1 = line.split("\\s+");
                		t = Double.parseDouble(str1[1])*(fmriAllTime/eyetrackTime);
                		double[] temp = new double[11];  				
                		for(int d=0;d<11;d++){
                			temp[d]= Double.parseDouble(str1[d]);
                		}
                		in_targ_coord.add(temp);
                		System.out.println(Double.parseDouble(str1[1])*(fmriAllTime/eyetrackTime));
        			}
        			System.out.println("fMRI Log End === "+ fmriTime[ntar][1] +" =====");
        			//System.out.println("number of time steps: " + in_targ_coord.size());
        			targ_coord.add(in_targ_coord);
        			
        			ntar = ntar + 1;
        			
//        			if(flag ==0){
//        				flag = 1;
//        				ntar = ntar + 1;
//        			}
        			

        		}
        		preline = str;
        	}
        	System.out.println("number of trials ======================================================" + ntar);
       
			FileOutputStream fout = new FileOutputStream(new File(outfn1)); 
			for(int i=0;i<targ_coord.size();i++){  
				double[] head = new double[11];
				head[0] = 12;
				for(int k=1;k<11;k++){
					head[k] = 0;
				}
				for(int k=0;k<11;k++){
					fout.write(((Double)(head[k])+"\t").getBytes());
				}
				fout.write(("\r\n").getBytes()); 
				
				ArrayList al =(ArrayList)targ_coord.get(i);
				for(int j =0;j<al.size();j++){
					double[] tem = (double[])al.get(j);
					for(int d=0;d<tem.length;d++){
						fout.write(((double)(tem[d])+"\t").getBytes());
					}
					fout.write(("\r\n").getBytes()); 
				}
				
			}   
	    } catch (IOException ex) {
	        ex.printStackTrace();
	    }    	   
	    
    }    
        /**
         * @param args the command line arguments
         */
        public static void main(String[] args) {

//        	////Eyetracker-log. file
//        	String fnames[] = {"Floriani_Carmen_Cue_1.txt","Floriani_Carmen_Cue_3.txt","Floriani_Carmen_NoCue_2.txt","Floriani_Carmen_NoCue_4.txt",
//        			  "Marz_Dani_Cue_4.txt","Marz_Dani_NoCue_3.txt",
//        			  "and_teg_cue2.txt","and_teg_cue4.txt","and_teg_nocue1.txt","and_teg_nocue3.txt",	
//        			  "car_har_cue1.txt","car_har_cue3.txt","car_har_nocue2.txt","car_har_nocue4.txt",
//        			  "chr_lip_cue_2_2.txt","chr_lip_cue_4.txt","chr_lip_nocue_1.txt","chr_lip_nocue_3.txt",
//        			  "eva_los_cue_2.txt","eva_los_cue_4.txt","eva_los_nocue_1.txt","eva_los_nocue_3.txt",
//        			  "eva_war_cue_2.txt","eva_war_cue_4.txt","eva_war_nocue_1.txt","eva_war_nocue_3.txt",
//        			  "jul_faz_cue1_2.txt","jul_faz_cue3.txt","jul_faz_nocue2.txt","jul_faz_nocue4.txt",
//        			  "jul_neh_cue_2.txt","jul_neh_cue_4.txt","jul_neh_nocue_1.txt","jul_neh_nocue_3.txt",
//        			  "leo_bar_cue_1.txt","leo_bar_cue_3.txt","leo_bar_nocue_2.txt","leo_bar_nocue_42.txt","leo_bar_nocue_4_td letztes drittel.txt",
//        			  "mel_bee_cue_2.txt","mel_bee_cue_4.txt","mel_bee_nocue_1.txt","mel_bee_nocue_3.txt",
//        			  "mor_tob_cue_1.txt","mor_tob_cue_3.txt","mor_tob_nocue_2.txt","mor_tob_nocue_4.txt",
//        			  "res_Klos_cue_1.txt","res_klos_cue_3.txt","res_klos_nocue_2.txt","res_klos_nocue_4.txt",
//        			  "rut_web_cue_2.txt","rut_web_cue_4.txt","rut_web_nocue_1.txt","rut_web_nocue_3.txt",
//        			  "seb_due_cue_1.txt","seb_due_cue_3.txt","seb_due_nocue_2.txt","seb_due_nocue_4.txt",
//        			  "tor_kas_cue_1.txt","tor_kas_cue_3.txt","tor_kas_nocue_2.txt","tor_kas_nocue_4.txt",
//        			  "ver_mai_cue2.txt","ver_mai_cue4.txt","ver_mai_nocue1.txt","ver_mai_nocue3.txt"};
//        	
//
//
//            String Dir = "F:/eyetracker_logs/";
//            for(int i=0;i<67;i++)
//            {            
//            	System.out.println(i);
//            	String infn = fnames[i];
//	            String outfn1 = fnames[i]+"_out.txt";
//	            String outfn2 = fnames[i]+"_outIdxTarMask-Time.txt";
//	
//	            try {
//	                //read input file
//	            	
//	                Eyetracker track = new Eyetracker();
//	                track.readData(Dir+infn,Dir+outfn1,Dir+outfn2);
//	                
//	            } catch (Exception ex) {
//	                ex.printStackTrace();
//	            }
//            }
            
            
//        	////fmri-log. file
//        	String fnames[] ={"Flor_Carmen_Cue_1_2-VINEVO-fMRI-evoz-audi.log", 
//        			"Flor_Carmen_NoCue_2_3-VINEVO-fMRI-evoz-audiNoCueing.log", 
//        			"Flor_Carmen_Cue_3-VINEVO-fMRI-evoz-audi.log",         			
//        			"Flor_Carmen_NoCue_4-VINEVO-fMRI-evoz-audiNoCueing.log", 
//        			"Marz_Dan_noCue_1-VINEVO-fMRI-evoz-audiNoCueing.log",         			
//        			"Mar_Dani_Cue_2-VINEVO-fMRI-evoz-audi.log", 
//        			"Marz_Dani_NoCue_3-VINEVO-fMRI-evoz-audiNoCueing.log",         			
//        			"Marz_Dani_Cue_4-VINEVO-fMRI-evoz-audi.log", 
//        			"and_teg_nocue1-VINEVO-fMRI-evoz-audiNoCueing.log",         			
//        			"and_teg_cue2-VINEVO-fMRI-evoz-audi.log", 
//        			"and_teg_nocue3-VINEVO-fMRI-evoz-audiNoCueing.log",         			
//        			"and_teg_cue4-VINEVO-fMRI-evoz-audi.log", 
//        			"car_har_cue1-VINEVO-fMRI-evoz-audi.log",
//        			"Car_har_nocue2-VINEVO-fMRI-evoz-audiNoCueing.log",
//        			"car_har_cue3-VINEVO-fMRI-evoz-audi.log", 
//        			"car_har_nocue4-VINEVO-fMRI-evoz-audiNoCueing.log", 
//        			"chr_lip_nocue_1-VINEVO-fMRI-evoz-audiNoCueing.log",         			
//        			"chr_lip_cue_2_2-VINEVO-fMRI-evoz-audi.log", 
//        			"chr_lip_nocue_3-VINEVO-fMRI-evoz-audiNoCueing.log",         			
//        			"chr_lip_cue_4-VINEVO-fMRI-evoz-audi.log", 
//        			"eva_Los_nocue_1-VINEVO-fMRI-evoz-audiNoCueing.log", 
//        			"eva_los_cue_2-VINEVO-fMRI-evoz-audi.log", 
//        			"eva_los_nocue_3-VINEVO-fMRI-evoz-audiNoCueing.log",         			
//        			"eva_los_cue_4-VINEVO-fMRI-evoz-audi.log",  
//        			"eva_war_nocue_-VINEVO-fMRI-evoz-audiNoCueing.log",
//        			"eva_war_cue_2-VINEVO-fMRI-evoz-audi.log", 
//        			"eva_war_nocue_3-VINEVO-fMRI-evoz-audiNoCueing.log",         			
//        			"eva_war_cue_4-VINEVO-fMRI-evoz-audi.log", 
//        			"jul_faz_cue1_2-VINEVO-fMRI-evoz-audi.log",          			
//        			"jul_faz_nocue2-VINEVO-fMRI-evoz-audiNoCueing.log", 
//        			"jul_faz_cue3-VINEVO-fMRI-evoz-audi.log",         			
//        			"jul_faz_nocue4-VINEVO-fMRI-evoz-audiNoCueing.log", 
//        			"jul_neh_nocue_1-VINEVO-fMRI-evoz-audiNoCueing.log",         			
//        			"jul_neh_cue_2-VINEVO-fMRI-evoz-audi.log", 
//        			"jul_neh_nocue_3-VINEVO-fMRI-evoz-audiNoCueing.log",         			
//        			"jul_neh_cue_4-VINEVO-fMRI-evoz-audi.log", 
//        			"leo_bar_cue_1-VINEVO-fMRI-evoz-audi.log", 
//        			"leo_bar_nocue_2-VINEVO-fMRI-evoz-audiNoCueing.log",         			
//        			"leo_bar_cue_3-VINEVO-fMRI-evoz-audi.log", 
//        			"leo_bar_nocue_42-VINEVO-fMRI-evoz-audiNoCueing.log", 
//        			"mel_bee_nocue_1-VINEVO-fMRI-evoz-audiNoCueing.log",         			
//        			"mel_bee_cue_2-VINEVO-fMRI-evoz-audi.log", 
//        			"mel_bee_nocue_3-VINEVO-fMRI-evoz-audiNoCueing.log",         			
//        			"mel_bee_cue_4-VINEVO-fMRI-evoz-audi.log", 
//        			"mor_tob_cue_1-VINEVO-fMRI-evoz-audi.log", 
//        			"mor_tob_nocue_2-VINEVO-fMRI-evoz-audiNoCueing.log",         			
//        			"mor_tob_cue_3-VINEVO-fMRI-evoz-audi.log", 
//        			"mor_tob_nocue_4-VINEVO-fMRI-evoz-audiNoCueing.log", 
//        			"res_Klos_cue_1-VINEVO-fMRI-evoz-audi.log", 
//        			"res_klos_nocue_2-VINEVO-fMRI-evoz-audiNoCueing.log", 
//        			"res_klos_cue_3-VINEVO-fMRI-evoz-audi.log", 
//        			"res_klos_nocue_4-VINEVO-fMRI-evoz-audiNoCueing.log", 
//        			"rut_web_nocue_1-VINEVO-fMRI-evoz-audiNoCueing.log",         			
//        			"rut_web_cue_2-VINEVO-fMRI-evoz-audi.log", 
//        			"rut_web_nocue_3-VINEVO-fMRI-evoz-audiNoCueing.log",         			
//        			"rut_web_cue_4-VINEVO-fMRI-evoz-audi.log", 
//        			"seb_due_cue_1-VINEVO-fMRI-evoz-audi.log", 
//        			"seb_due_nocue_2-VINEVO-fMRI-evoz-audiNoCueing.log", 
//        			"seb_due_cue_3-VINEVO-fMRI-evoz-audi.log", 
//        			"seb_due_nocue_4-VINEVO-fMRI-evoz-audiNoCueing.log", 
//        			"tor_kas_cue_1-VINEVO-fMRI-evoz-audi.log", 
//        			"tor_kas_nocue_2-VINEVO-fMRI-evoz-audiNoCueing.log",         			
//        			"tor_kas_cue_3-VINEVO-fMRI-evoz-audi.log", 
//        			"tor_kas_nocue_4-VINEVO-fMRI-evoz-audiNoCueing.log", 
//        			"ver_mai_nocue1-VINEVO-fMRI-evoz-audiNoCueing.log",         			
//        			"ver_mai_cue2-VINEVO-fMRI-evoz-audi.log", 
//        			"ver_mai_nocue3-VINEVO-fMRI-evoz-audiNoCueing.log",        			
//        			"ver_mai_cue4-VINEVO-fMRI-evoz-audi.log"};
//        	
//        	
//		          String Dir = "F:/eyetracker_logs/fmri-logs/";
//		          for(int i=0;i<68;i++)
//		          {            
//		          		System.out.println(i);
//		          		String infn = fnames[i];
//			            String outfn1 = fnames[i]+"_TarMaskTime.txt";
//			
//			            try {
//			                //read input file
//			            	
//			                Eyetracker track = new Eyetracker();
//			                track.readfmriLogData(Dir+infn,Dir+outfn1);
//			                
//			            } catch (Exception ex) {
//			                ex.printStackTrace();
//			            }
//		          }       
		          
        	// "Marz_Dan_noCue_1-VINEVO-fMRI-evoz-audiNoCueing.log",         			
			// "Mar_Dani_Cue_2-VINEVO-fMRI-evoz-audi.log", 
		        	////fmri-log. file
		        	String fnames1[] ={
		        			"Flor_Carmen_Cue_1_2-VINEVO-fMRI-evoz-audi.log", 
		        			"Flor_Carmen_NoCue_2_3-VINEVO-fMRI-evoz-audiNoCueing.log", 
		        			"Flor_Carmen_Cue_3-VINEVO-fMRI-evoz-audi.log",         			
		        			"Flor_Carmen_NoCue_4-VINEVO-fMRI-evoz-audiNoCueing.log", 
//		        			"Marz_Dan_noCue_1-VINEVO-fMRI-evoz-audiNoCueing.log",
//		        			"Mar_Dani_Cue_2-VINEVO-fMRI-evoz-audi.log",
//		        			"Marz_Dani_NoCue_3-VINEVO-fMRI-evoz-audiNoCueing.log",         			
//		        			"Marz_Dani_Cue_4-VINEVO-fMRI-evoz-audi.log", 
		        			"and_teg_nocue1-VINEVO-fMRI-evoz-audiNoCueing.log",         			
		        			"and_teg_cue2-VINEVO-fMRI-evoz-audi.log", 
		        			"and_teg_nocue3-VINEVO-fMRI-evoz-audiNoCueing.log",         			
		        			"and_teg_cue4-VINEVO-fMRI-evoz-audi.log", 
		        			"car_har_cue1-VINEVO-fMRI-evoz-audi.log",
		        			"Car_har_nocue2-VINEVO-fMRI-evoz-audiNoCueing.log",
		        			"car_har_cue3-VINEVO-fMRI-evoz-audi.log", 
		        			"car_har_nocue4-VINEVO-fMRI-evoz-audiNoCueing.log", 
		        			"chr_lip_nocue_1-VINEVO-fMRI-evoz-audiNoCueing.log",         			
		        			"chr_lip_cue_2_2-VINEVO-fMRI-evoz-audi.log", 
		        			"chr_lip_nocue_3-VINEVO-fMRI-evoz-audiNoCueing.log",         			
		        			"chr_lip_cue_4-VINEVO-fMRI-evoz-audi.log", 
		        			"eva_Los_nocue_1-VINEVO-fMRI-evoz-audiNoCueing.log", 
		        			"eva_los_cue_2-VINEVO-fMRI-evoz-audi.log", 
		        			"eva_los_nocue_3-VINEVO-fMRI-evoz-audiNoCueing.log",         			
		        			"eva_los_cue_4-VINEVO-fMRI-evoz-audi.log",  
		        			"eva_war_nocue_-VINEVO-fMRI-evoz-audiNoCueing.log",
		        			"eva_war_cue_2-VINEVO-fMRI-evoz-audi.log", 
		        			"eva_war_nocue_3-VINEVO-fMRI-evoz-audiNoCueing.log",         			
		        			"eva_war_cue_4-VINEVO-fMRI-evoz-audi.log", 
		        			"jul_faz_cue1_2-VINEVO-fMRI-evoz-audi.log",          			
		        			"jul_faz_nocue2-VINEVO-fMRI-evoz-audiNoCueing.log", 
		        			"jul_faz_cue3-VINEVO-fMRI-evoz-audi.log",         			
		        			"jul_faz_nocue4-VINEVO-fMRI-evoz-audiNoCueing.log", 
		        			"jul_neh_nocue_1-VINEVO-fMRI-evoz-audiNoCueing.log",         			
		        			"jul_neh_cue_2-VINEVO-fMRI-evoz-audi.log", 
		        			"jul_neh_nocue_3-VINEVO-fMRI-evoz-audiNoCueing.log",         			
		        			"jul_neh_cue_4-VINEVO-fMRI-evoz-audi.log", 
		        			"leo_bar_cue_1-VINEVO-fMRI-evoz-audi.log", 
		        			"leo_bar_nocue_2-VINEVO-fMRI-evoz-audiNoCueing.log",         			
		        			"leo_bar_cue_3-VINEVO-fMRI-evoz-audi.log", 
		        			"leo_bar_nocue_42-VINEVO-fMRI-evoz-audiNoCueing.log", 
		        			"mel_bee_nocue_1-VINEVO-fMRI-evoz-audiNoCueing.log",         			
		        			"mel_bee_cue_2-VINEVO-fMRI-evoz-audi.log", 
		        			"mel_bee_nocue_3-VINEVO-fMRI-evoz-audiNoCueing.log",         			
		        			"mel_bee_cue_4-VINEVO-fMRI-evoz-audi.log", 
		        			"mor_tob_cue_1-VINEVO-fMRI-evoz-audi.log", 
		        			"mor_tob_nocue_2-VINEVO-fMRI-evoz-audiNoCueing.log",         			
		        			"mor_tob_cue_3-VINEVO-fMRI-evoz-audi.log", 
		        			"mor_tob_nocue_4-VINEVO-fMRI-evoz-audiNoCueing.log", 
		        			"res_Klos_cue_1-VINEVO-fMRI-evoz-audi.log", 
		        			"res_klos_nocue_2-VINEVO-fMRI-evoz-audiNoCueing.log", 
		        			"res_klos_cue_3-VINEVO-fMRI-evoz-audi.log", 
		        			"res_klos_nocue_4-VINEVO-fMRI-evoz-audiNoCueing.log", 
		        			"rut_web_nocue_1-VINEVO-fMRI-evoz-audiNoCueing.log",         			
		        			"rut_web_cue_2-VINEVO-fMRI-evoz-audi.log", 
		        			"rut_web_nocue_3-VINEVO-fMRI-evoz-audiNoCueing.log",         			
		        			"rut_web_cue_4-VINEVO-fMRI-evoz-audi.log", 
		        			"seb_due_cue_1-VINEVO-fMRI-evoz-audi.log", 
		        			"seb_due_nocue_2-VINEVO-fMRI-evoz-audiNoCueing.log", 
		        			"seb_due_cue_3-VINEVO-fMRI-evoz-audi.log", 
		        			"seb_due_nocue_4-VINEVO-fMRI-evoz-audiNoCueing.log", 
		        			"tor_kas_cue_1-VINEVO-fMRI-evoz-audi.log", 
		        			"tor_kas_nocue_2-VINEVO-fMRI-evoz-audiNoCueing.log",         			
		        			"tor_kas_cue_3-VINEVO-fMRI-evoz-audi.log", 
		        			"tor_kas_nocue_4-VINEVO-fMRI-evoz-audiNoCueing.log", 
		        			"ver_mai_nocue1-VINEVO-fMRI-evoz-audiNoCueing.log",         			
		        			"ver_mai_cue2-VINEVO-fMRI-evoz-audi.log", 
		        			"ver_mai_nocue3-VINEVO-fMRI-evoz-audiNoCueing.log",        			
		        			"ver_mai_cue4-VINEVO-fMRI-evoz-audi.log"
		        			};        	
		          
		        	////Eyetracker-log. file
		        	String fnames2[] = {
		        			  "Floriani_Carmen_Cue_1.txt",
		        			  "Floriani_Carmen_NoCue_2.txt",
		        			  "Floriani_Carmen_Cue_3.txt",		        			  
		        			  "Floriani_Carmen_NoCue_4.txt",
//		        			  "Marz_Dani_NoCue_3.txt",
//		        			  "Marz_Dani_Cue_4.txt",
		        			  "and_teg_nocue1.txt",
		        			  "and_teg_cue2.txt",
		        			  "and_teg_nocue3.txt",
		        			  "and_teg_cue4.txt",	
		        			  "car_har_cue1.txt",
		        			  "car_har_nocue2.txt",
		        			  "car_har_cue3.txt",
		        			  "car_har_nocue4.txt",
		        			  "chr_lip_nocue_1.txt",
		        			  "chr_lip_cue_2_2.txt",
		        			  "chr_lip_nocue_3.txt",
		        			  "chr_lip_cue_4.txt",
		        			  "eva_los_nocue_1.txt",
		        			  "eva_los_cue_2.txt",
		        			  "eva_los_nocue_3.txt",
		        			  "eva_los_cue_4.txt",
		        			  "eva_war_nocue_1.txt",
		        			  "eva_war_cue_2.txt",
		        			  "eva_war_nocue_3.txt",
		        			  "eva_war_cue_4.txt",
		        			  "jul_faz_cue1_2.txt",
		        			  "jul_faz_nocue2.txt",
		        			  "jul_faz_cue3.txt",
		        			  "jul_faz_nocue4.txt",
		        			  "jul_neh_nocue_1.txt",
		        			  "jul_neh_cue_2.txt",
		        			  "jul_neh_nocue_3.txt",
		        			  "jul_neh_cue_4.txt",
		        			  "leo_bar_cue_1.txt",
		        			  "leo_bar_nocue_2.txt",
		        			  "leo_bar_cue_3.txt",
		        			  "leo_bar_nocue_42.txt",
		        			  "mel_bee_nocue_1.txt",
		        			  "mel_bee_cue_2.txt",
		        			  "mel_bee_nocue_3.txt",
		        			  "mel_bee_cue_4.txt",
		        			  "mor_tob_cue_1.txt",
		        			  "mor_tob_nocue_2.txt",
		        			  "mor_tob_cue_3.txt",
		        			  "mor_tob_nocue_4.txt",
		        			  "res_Klos_cue_1.txt",
		        			  "res_klos_nocue_2.txt",
		        			  "res_klos_cue_3.txt",
		        			  "res_klos_nocue_4.txt",
		        			  "rut_web_nocue_1.txt",
		        			  "rut_web_cue_2.txt",
		        			  "rut_web_nocue_3.txt",
		        			  "rut_web_cue_4.txt",
		        			  "seb_due_cue_1.txt",
		        			  "seb_due_nocue_2.txt",
		        			  "seb_due_cue_3.txt",
		        			  "seb_due_nocue_4.txt",
		        			  "tor_kas_cue_1.txt",
		        			  "tor_kas_nocue_2.txt",
		        			  "tor_kas_cue_3.txt",
		        			  "tor_kas_nocue_4.txt",
		        			  "ver_mai_nocue1.txt",
		        			  "ver_mai_cue2.txt",
		        			  "ver_mai_nocue3.txt",
		        			  "ver_mai_cue4.txt"
		        			  };
		        	
		
		
		            String Dir = "F:/eyetracker_logs/";
		            for(int i=0;i<64;i++)
		            {            
		            	System.out.println(i);
		            	String infn1 = fnames1[i]+"_TarMaskTime.txt" ;
		            	String infn2 = fnames2[i];
			            String outfn1 = fnames2[i]+"_coord.txt";
			
			            try {
			                //read input file
			            	
			                Eyetracker track = new Eyetracker();
			                track.readeyeTrackerData(Dir+"fmri-logs/"+infn1,Dir+infn2,Dir+outfn1);
			                
			            } catch (Exception ex) {
			                ex.printStackTrace();
			            }
		            }		          
        	
        	
        	
       }  
        
}