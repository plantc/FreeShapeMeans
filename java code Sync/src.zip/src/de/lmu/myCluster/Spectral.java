/*
 * Spectral.java
 *
 */
package de.lmu.myCluster;

import Jama.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.jmatio.io.MatFileWriter;
import com.jmatio.types.MLDouble;

import de.lmu.database.DataObject;

/**
 *   spectral clustering using scaled adjacency matrix: Ng, Jordan, Weiss 2001. 
 */
public class Spectral {

    double[][] dm; //distance Matrix
    double[][] data; //data Matrix
    int[] clusterIDs;
    int numObj;
    int dim;

    /** Creates a new instance of Spectral */
    public Spectral(double[][] data) {
    	this.data = data;
        clusterIDs = new int[data.length];
        numObj = data.length;
        dim = data[0].length;
    }
    
    /** Creates a new instance of Spectral */
    public Spectral() {
    	
    }

    public int[] cluster(int k) {
        try {

            //calculate affinity matrix
        	System.out.println("calculate affinity matrix");
            double[][] exp = exponentialKernel(data,1);
            //System.out.println(A.length + ", " + A[0].length );
        	System.out.println("compute inverse of degree matrix");
            //compute inverse of degree matrix
            double[][] degree = new double[numObj][numObj];
            for(int x = 0; x < numObj; x++) 
            	for(int y = 0; y < numObj; y++)
            		degree[x][y] = 0.0;
            	     
            for (int i = 0; i < numObj; i++) {
                double sum = 0.0;
                for (int j = 0; j < numObj; j++) {
                    sum += exp[i][j];
                }
                degree[i][i] = 1.0 / Math.sqrt(sum);
            }
            //System.out.println(degree.length + ", " + degree[0].length );
        	System.out.println("Construct matrix L");         
            //Construct matrix L
            Matrix am = new Matrix(exp);
            Matrix D = new Matrix(degree);
            Matrix L = D.times(am).times(D);            
           
            //Decompose the matrix L  ???
            EigenvalueDecomposition eig = new EigenvalueDecomposition(L);    
            Matrix vectors = eig.getV();
            Matrix values = eig.getD();         
            
            MLDouble mv = new MLDouble("v", vectors.getArray());
            ArrayList lv = new ArrayList();
            lv.add(mv);
            String filenamev = "vectors.mat";
            new MatFileWriter(filenamev, lv);
            
            System.out.println("sort the eigenvalues in vectorArray");   
            //sort the eigenvalues in vectorArray according to the size of the eigenvalues.
            //int k = 3; // use specification
            double[][] vectorArray = vectors.getArrayCopy();
            double[][] valueArray = values.getArrayCopy();
            double[][] vectorsSorted = new double[vectorArray.length][k];
            int rows = vectorArray.length;   
            int cols = vectorArray.length;   
            boolean[] used = new boolean[vectorArray.length];
            for(int q = 0; q < rows; q++)
            	used[q] = false;
            for (int i = 0; i < k ; i++){
                double maxEV = -Double.MAX_VALUE;
                int maxIndex = -1;
                for (int j = 0; j < rows; j++) {
                    if (valueArray[j][j] > maxEV && !used[j]) {
                    	maxEV = valueArray[j][j];
                        maxIndex = j;
                    }
                }
                used[maxIndex] = true;
                for (int j = 0; j < rows; j++) {
                    vectorsSorted[j][i] = vectorArray[j][maxIndex];
                }
            }
            System.out.println("Normalize the vector to unit length");            
            //Normalize the vector to unit length.         
            for (int i = 0; i < rows; i++) {
                double columnSum = 0.0;
                for (int j = 0; j < k; j++) {
                    columnSum += vectorsSorted[i][j] * vectorsSorted[i][j];
                }
                for (int j = 0; j < k; j++) {
                	vectorsSorted[i][j] /= Math.sqrt(columnSum);
                }
            }
            System.out.println("cluster columns with k-means");  
            //cluster columns with k-means
            DataObject[] d = new DataObject[rows];
            for(int i = 0; i < rows; i++){
                double[] coord = new double[k];
                for(int j = 0; j < k; j++)
                    coord[j] = vectorsSorted[i][j];
                d[i] = new DataObject(coord, i);
            }
            KMeans km = new KMeans(k-1, d);
            DataObject[] res = km.run();
            //assign the cluster ID
            for(int i = 0; i < k-1; i++){
	            for(int j = 0; j < rows; j++){
	                if(res[j].clusterID == i+1){
	                	clusterIDs[j] = i;
	                }
	            }   
            }
        } catch (Exception ex) {
            Logger.getLogger(Spectral.class.getName()).log(Level.SEVERE, null, ex);
        }
        return clusterIDs;
    }

    private double[][] exponentialKernel(double[][] dmm, double sita) {
    	double[][] dd = new double[numObj][numObj];
    	dm = new double[numObj][numObj];
        for (int i = 0; i < numObj; i++) {
            for (int j = 0; j < numObj; j++) {
            	double dis = 0.0;
            	if(i!=j){
	            	for (int d = 0; d < dim; d++){    
	                   dis =  dis + (dmm[i][d]- dmm[j][d])* (dmm[i][d]- dmm[j][d]);	                   
	            	}
	            	//System.out.println(dis);
	            	dm[i][j] = Math.sqrt(dis);
	            	dd[i][j] = Math.exp(-dis);
	            	//System.out.println(dd[i][j]);
            	}else{
            		dm[i][j] = 0.0;
            		dd[i][j] = 0.0;
            	}
            }
        }
        return dd;
    }
    
    /**
     * save the clustering result
     * @param ArrayList data (result)
     * @param String fn (filename)
     * @return none
     */
    public void norm(double[][] data){
       int n = data.length;
       int d = data[0].length;
       double [] max = new double[d];
       //Initialize
       for(int i=0;i<d;i++){
    	   max[i]= -1e10;
       }
       //Find the maximum value for each variance

       for(int j=0;j<d;j++){
    	  for(int i=0;i<n;i++){
    		  double temp = data[i][j];
    		  if(temp > max[j]){
    			  max[j]= temp;
    		  }    		  
    	  }
       }
       //Normalize the data set
       for(int i=0;i<n;i++){
     	  for(int j=0;j<d;j++){
     		  double temp = data[i][j];
     		  temp = temp/max[j];
     		  data[i][j] = temp;
     	  }
        }	
    } 
  
    
    public static void main(String[] args) {
    	
    	long   start   =   System.currentTimeMillis(); 
    	double[][] data = new double[1198][2]; //1226
    	
        try {
        	File mFile = new File("csym_no.txt");
        	FileReader fr = new FileReader(mFile);
        	BufferedReader br = new BufferedReader(fr);
        	String line;
        	int num = 0;
        	while((line=br.readLine())!=null){
        		line = line.trim();        		
        		String[] str = line.split("\\s+");
        		int dimm = str.length;
        		ArrayList temp = new ArrayList(dimm);
        		for(int i=0;i<dimm;i++){
        			//System.out.println(str[i]);
        			data[num][i] = Double.parseDouble(str[i]);
        		}
    			num = num + 1;
        	}
        } catch (IOException ex) {
            ex.printStackTrace();
        }    
    	Spectral sc = new Spectral(data);
    	sc.norm(data);
    	System.out.println(data.length);

    	int[] ID = sc.cluster(9);
    	System.out.println("Save Results..."); 	        
    	de.lmu.database.SaveData sa = new de.lmu.database.SaveData();
    	sa.save1D(ID,"sc_csym_no_9_K8.txt");	
  	  	long   end   =   System.currentTimeMillis(); 
  	  	System.out.println("All running time:"+Long.toString(end-start)+" ms.");
  	  	System.out.println("Ending");	
    }
}
