/*
 * Kmeans.java
 *
 * Created on February 17, 2005, 3:47 PM
 */

package de.lmu.myCluster;

/**
 *
 * @author  Administrator
 */
import de.lmu.database.DataObject;
//import de.lmu.utils.VisuInfo;
import java.util.*;

public class KMeans {
    int k;
    //DB db;
    DataObject[] obj;
    int dim;
    double[][] means;
    int iteration;
    boolean verbose = true;
    
    /** Creates a new instance of Kmeans */
    public KMeans(int k, DataObject[] obj){
        this.k = k;
        this.obj = obj;
        this.dim = obj[0].coord.length;
        this.means = new double[k][dim];
        this.iteration = 0;
    }
    
    public DataObject[] run(){
        if(verbose)
        System.out.println("k-means: k: " + k + " numObj: " + obj.length);
        //init
        Random r = new Random(18);
        for(int i = 0; i < k; i++){
            int nextMean = r.nextInt(obj.length);
            for(int j = 0; j < dim; j++){
                means[i][j] = obj[nextMean].coord[j];
            }
        }
        boolean b = assignPoints();
        //updateMeans();
        //mdlUpdateMeans();
        iteration++;
        boolean done = false;
        while(!done){
            updateMeans();
            boolean clusterChanged = assignPoints();
            iteration++;
            if(!clusterChanged)
                done = true;
        }
        //mdlAssignPoints();
        
        if(verbose)
        System.out.println(iteration + " iterations");
       //printClusterAss();
       // VisuInfo visu = new VisuInfo(obj, "result");
        //visu.setSize(600,600);
        //visu.setBackground(Color.WHITE);
        //visu.setLocation(500,500);
       // visu.setVisible(true);
        
        return obj;
    }
    
    private void printClusterAss(){
        for(int i = 0; i < obj.length; i++){
            System.out.println("DO " + i + " clusterID " + obj[i].clusterID);
        }
    }
    
    private void printClusterMembers(){
        int[] clMembers = new int[k];
        for(int i = 0; i < obj.length; i++){
            clMembers[obj[i].clusterID-1]++;
        }
        for(int i = 0; i < clMembers.length; i++)
            System.out.println("Cluster " + (i+1) + " " + clMembers[i] + " objects");
        
    }
    
    private void printMeans(){
        System.out.println("printing means");
        for(int i = 0; i < k; i++){
            System.out.println("M ");
            for(int j = 0; j < dim; j++){
                System.out.print(means[i][j] + " ");
            }
            System.out.println();
        }
    }
    
    
    private boolean assignPoints(){
        boolean clusterChanged = false;
        for(int i = 0; i < obj.length; i++){
            int aktClustID = findNextCluster(obj[i]);
            if(obj[i].clusterID != aktClustID)
                clusterChanged = true;
            obj[i].clusterID = aktClustID;
        }
        return clusterChanged;
    }
    
    
    private int findNextCluster(DataObject d){
        double minDist = Double.MAX_VALUE;
        int minIndex = Integer.MAX_VALUE;
        for(int i = 0; i < means.length; i++){
            double[] aktMean = new double[dim];
            for(int j = 0; j < aktMean.length; j++)
                aktMean[j] = means[i][j];
            //double aktDist = mdlDistance(d, aktMean);
            double aktDist = distance(d, aktMean);
            if(aktDist < minDist){
                minDist = aktDist;
                minIndex = i+1;
            }
        }
        return minIndex;
    }
    
    
    
    private double distance(DataObject d, double[] mean){
        double sum = 0.0;
        for (int i = 0; i < d.coord.length; i++){
            double dist = ((d.coord[i] - mean[i])*(d.coord[i] - mean[i]));
            sum = sum + dist;
        }
        return Math.sqrt(sum);
    }
    
    
   
    
    private void updateMeans(){
        for(int i = 0; i < k; i++){
            int counter = 0;
            for(int j = 0; j < obj.length; j++){
                if(obj[j].clusterID == i+1){
                    //for(int l = 0; l < dim; l++)
                    //means[i][l]+= db.store[j].coord[l];
                    counter++;
                }
            }
            if (counter>0){
                for(int j = 0; j < dim; j++){
                    means[i][j] = 0.0;
                }
                for(int j = 0; j < obj.length; j++){
                    if(obj[j].clusterID == i+1){
                        for(int l = 0; l < dim; l++)
                            means[i][l]+= obj[j].coord[l];
                        //counter++;
                    }
                }
                for(int l = 0; l < dim; l++)
                    means[i][l] = means[i][l]/(double)counter;
            }
        }
        //this.means = means;
    }
    
   
    
}
