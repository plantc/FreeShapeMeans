package de.lmu.myCluster;

import com.jmatio.io.MatFileReader;
import com.jmatio.types.MLDouble;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Exploring the Multi-Scale Hierarchical clusters based on local
 * synchronization Extensive Kuramoto model based synchronization
 *
 * @author Junming Shao
 * @param None Created on 16. Jan. 2009,
 */
public class SynC {

    public static final double C = 1;
    private static final String ArrayList = null;
    public double A;
    public static String fname;
    public int num;
    public int dim;
    public boolean normFlag;
    public boolean noiseFlag;
    public ArrayList src;

    public SynC() {
        A = 0.0;
        num = 0;
        dim = 1;
        normFlag = false;
        noiseFlag = false;
        src = new ArrayList();
    }

    /**
     * Set the related parameters
     *
     * @param filename, the threshold for nearest neighbors of one object
     * @return none
     */
    public void setParams(String filename, double e) { //, boolean Flag,boolean noise){
        fname = filename;
        A = e;
        //normFlag = Flag;
        //noiseFlag = noise;
    }

    /**
     * Load the database from a given filename
     *
     * @param Filename
     * @return none
     */

    public void loadMatlabData(String dir, String variableName) {
        double[][] data = new double[1][1];

        MatFileReader mfr = null;
        try {
            mfr = new MatFileReader(dir);
        } catch (IOException e) {
        }
        if (mfr != null) {
            data = ((MLDouble) mfr.getMLArray(variableName)).getArray();
        }
        dim = data[0].length;
        for (int i = 0; i < data.length; i++) {
             ArrayList temp = new ArrayList(dim);
             for (int j = 0; j < dim; j++) {
                    temp.add(data[i][j]);
                }
            src.add(temp);
        }
        num = data.length;

    }

    public void loadData(String fn) {

        try {
            File mFile = new File(fn);
            FileReader fr = new FileReader(mFile);
            BufferedReader br = new BufferedReader(fr);
            String line;

            while ((line = br.readLine()) != null) {
                line = line.trim();
                String[] str = line.split("\\s+");
                //System.out.println(str[0]);
                dim = str.length;
                ArrayList temp = new ArrayList(dim);
                for (int i = 0; i < dim; i++) {
                    temp.add(Double.parseDouble(str[i]));
                }
                src.add(temp);
                num = num + 1;
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public void norm1(ArrayList data) {
        int n = data.size();
        int d = ((ArrayList) data.get(0)).size();
        double[] max = new double[d];
        //Initialize
        for (int i = 0; i < d; i++) {
            max[i] = -1e10;
        }
        //Find the maximum value for each variance

        for (int j = 0; j < d; j++) {
            for (int i = 0; i < n; i++) {
                double temp = (Double) ((ArrayList) data.get(i)).get(j);
                if (temp > max[j]) {
                    max[j] = temp;
                }
            }
        }
        //Normalize the data set
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < d; j++) {
                double temp = (Double) ((ArrayList) data.get(i)).get(j);
                temp = temp / max[j];
                ((ArrayList) data.get(i)).set(j, temp);
            }
        }
        saveData(data, "normx.txt");
    }

    /**
     * save the clustering result
     *
     * @param ArrayList data (result)
     * @param String fn (filename)
     * @return none
     */
    public void norm(ArrayList data) {
        int n = data.size();
        int d = ((ArrayList) data.get(0)).size();
        double[] max = new double[d];
        //Initialize
        for (int i = 0; i < d; i++) {
            max[i] = -1e10;
        }
        //Find the maximum value for each variance

        for (int j = 0; j < d; j++) {
            for (int i = 0; i < n; i++) {
                double temp = (Double) ((ArrayList) data.get(i)).get(j);
                if (temp > max[j]) {
                    max[j] = temp;
                }
            }
        }
        //Normalize the data set
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < d; j++) {
                double temp = (Double) ((ArrayList) data.get(i)).get(j);
                temp = temp / max[j];
                ((ArrayList) data.get(i)).set(j, temp);
            }
        }
        saveData(data, "normx.txt");
    }

    /**
     * save the clustering result
     *
     * @param ArrayList data (result)
     * @param String fn (filename)
     * @return none
     */
    public void saveData(ArrayList data, String fn) {

        int lens = data.size();
        try {
            FileOutputStream fout = new FileOutputStream(new File(fn));
            for (int i = 0; i < lens; i++) {
                for (int j = 0; j < dim; j++) {
                    fout.write(((Double) (((ArrayList) data.get(i)).get(j)) + "\t").getBytes());
                }
                fout.write(("\r\n").getBytes());
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * compute the distance
     *
     * @param double dis
     * @return none
     */
    public double distance(double[] dis) {

        double val = 0.0;
        for (int i = 0; i < dis.length; i++) {
            val = val + Math.pow(dis[i], 2);
        }
        double dist = Math.sqrt(val);
        return dist;
    }

    /**
     * main function - Dynamical clustering
     */
    public static void main(String[] args) {

        long start = System.currentTimeMillis();
        SynC myCluster = new SynC();

        //Set related parameters (User parameter specification)
        String fn = "wisconsin.txt";
        myCluster.setParams(fn, 100.0);
        //load the data set;
        //myCluster.loadData(myCluster.fname);
        myCluster.loadMatlabData("twoMoonsOneGaussianLessOverlap.mat", "data");
        //If necessary, normalize the data set
//    	if(true){//myCluster.normFlag){
//    		myCluster.norm(myCluster.src);
//    	}

        int len = myCluster.src.size();
        int dimm = myCluster.dim;
        System.out.println("Number of Objects:" + len + "; Dimensionality: " + dimm);
        boolean loop = true;
        int loopNum = 0;
        double localOrder = 0.0;
        double allorder = 0.0;
        ArrayList x = myCluster.src;
        ArrayList prex = new ArrayList();

        //Copy data set
        /*
    	for(int i=0;i<len;i++){
    		ArrayList temp1 = new ArrayList(dimm);    		
    		for(int j=0;j<dimm;j++){
    			temp1.add(((ArrayList)x.get(i)).get(j));
    		}
			prex.add(temp1);
    	} */
        //System.out.println(((ArrayList)x.get(0)).get(0));
        while (loop) {

            double[] order = new double[len];
            localOrder = 0.0;
            allorder = 0.0;

            loopNum = loopNum + 1;

            for (int i = 0; i < len; i++) {
                double[] sinValue = new double[dimm];
                double[] diss = new double[dimm];
                double[] temp = new double[dimm];

                double dis = 0.0;
                double kij = 0.0;
                double allk = 0.0;

                int num = 0;
                double sita = 0.0;
                ArrayList diff = new ArrayList();

                for (int j = 0; j < len; j++) {
                    dis = 0.0;
                    kij = 0.0;
                    for (int d = 0; d < dimm; d++) {
//                        diss[d] = ((double[]) (x.get(j)))[d] -  ((double[]) (x.get(i)))[d];
                        
                        diss[d] = (Double)((ArrayList)(x.get(j))).get(d)-(Double)((ArrayList)(x.get(i))).get(d);
                    }

                    dis = myCluster.distance(diss);
                    //System.out.println(dis);

                    if (dis < myCluster.A) {

                        num = num + 1;
                        //Calculating the coupling strength
                        for (int d = 0; d < dimm; d++) {
                            temp[d] = (diss[d] + 1e-10) / ((Double) ((ArrayList) (x.get(j))).get(d) + 1e-10);
                            //temp[d] = (diss[d]+ 1e-10)/((Double)((ArrayList)(prex.get(j))).get(d)+ 1e-10);
                        }
                        // Weighted coupling strength of each object
                        kij = Math.pow(myCluster.distance(temp), 1);
                        allk = allk + kij;

                        for (int d = 0; d < dimm; d++) {
                            sinValue[d] = sinValue[d] + kij * Math.sin(diss[d]);
                        }
                        sita = sita + Math.exp(-dis);
                    }
                }
                if (num > 1) {
                    for (int d = 0; d < dimm; d++) {
                        double[] x1 = new double[dimm];
                        x1[d] = ((Double) ((ArrayList) (x.get(i))).get(d)) + (myCluster.C * sinValue[d] + 1e-10) / (allk + 1e-10);
                        //x1[d] = ((Double)((ArrayList)(prex.get(i))).get(d))+ (myCluster.C*sinValue[d]+1e-10)/(allk+1e-10);
                        ((ArrayList) (x.get(i))).set(d, x1[d]);
                    }
                    order[i] = sita / num;
                }
            }
            for (int k = 0; k < len; k++) {
                allorder = allorder + order[k];
            }
            //Local order parameter
            localOrder = allorder / len;

            //System.out.println(Double.toString(localOrder));
            if (localOrder > 1 - (1e-5) || loopNum >= 100) {
                loop = false;
                System.out.println("LOCAL ORDER PARAMETER:" + Double.toString(localOrder));
                System.out.println("ALL LOOPS:" + Double.toString(loopNum));
            }
            // Save the previous value of the objects of the data set
            /*
	    	for(int i=0;i<len;i++){
	    		ArrayList temp1 = new ArrayList(dimm);    		
	    		for(int j=0;j<dimm;j++){
	    			temp1.add(((ArrayList)x.get(i)).get(j));
	    		}
				prex.set(i, temp1);
	    	}	    	
             */
        }

        long end = System.currentTimeMillis();
        System.out.println("All running time:" + Long.toString(end - start) + " ms.");
        myCluster.saveData(x, "output11.txt");
        System.out.println("Ending");
    }
}
