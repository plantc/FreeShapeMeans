/*
 * SingleLink.java
 *
 * Created on 2 August 2009
 * 
 * Author: Junming Shao
 */

package de.lmu.myCluster;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import de.lmu.utils.*;



public class SingleLink{
	public int[] ID;
	public double[][] disMatrix;
	public double[] valueLevel;
	public int clusterNum = 0;
	public double[][] Z;

	
	public SingleLink(double[][] disMatrix,int num){
		this.ID = new int[disMatrix.length];
		this.disMatrix = disMatrix;
		this.valueLevel = new double[disMatrix.length];
		for(int n=0;n<disMatrix.length;n++){
			ID[n] = -2;
		}
		clusterNum = num;
		Z = new double[disMatrix.length-1][3];
	}
	
	public int[] cluster(){
		int num = disMatrix.length;
		int level = 0;
		int[] index = new int[2];
		int[] label = new int[num];
		ArrayList<ArrayList<ArrayList<Integer>>> clusterLevel = new ArrayList<ArrayList<ArrayList<Integer>>>(); 
		ArrayList<ArrayList<Integer>> clusterID = new ArrayList<ArrayList<Integer>> (); 
		for(int i =0;i<num;i++){
			ArrayList<Integer> temp = new ArrayList<Integer>();
			temp.add(i);
			clusterID.add(temp);
			label[i] = i + 1;
		}
		clusterLevel.add(clusterID);
		
		while(disMatrix.length>1){
			double minV = Double.MAX_VALUE;
			index[0]=-1; index[1]=-1;
			
			
			// Find the least dissimilar pair of clusters
			for(int i=0;i<disMatrix.length;i++){
				for(int j=0;j<disMatrix.length;j++){
					if(disMatrix[i][j]<minV && i!=j){
						minV = disMatrix[i][j];
						index[0] = i;
						index[1] = j;
					}
				}
			}
			
			//Merge clusters
			valueLevel[level] = minV;
			Z[level][0] = label[index[0]];
			Z[level][1] = label[index[1]];
			Z[level][2] = minV;
			level = level + 1;
			
			//Update the similarity matrix
			double[][] temp = new double[disMatrix.length-1][disMatrix.length-1];
			int x = 0, y = 0;
			ArrayList<ArrayList<Integer>> tempAl = new ArrayList<ArrayList<Integer>> ();
			//delete the responding rows and cols
			for(int i=0;i<disMatrix.length;i++){
				if(i!=index[0]&& i!=index[1]){
					y=0;					
					for(int j=0;j<disMatrix.length;j++){
						if(j!= index[0] && j!= index[1]){
							temp[x][y] = disMatrix[i][j];							
							y = y + 1;
						}
					}
					tempAl.add((clusterLevel.get(clusterLevel.size()-1)).get(i));
					label[x] = label[i];
					x = x + 1;
					
				}
			}
			
			//add new distance 			
			int k=0;
			for(int i=0;i<disMatrix.length;i++){
				if(i!=index[0]&& i!=index[1]){
					temp[k][temp.length-1] = Math.min(disMatrix[i][index[0]],disMatrix[i][index[1]]);
					temp[temp.length-1][k] = temp[k][temp.length-1];
					k = k + 1;
				}
			}
			label[temp.length-1] = num + level;
			
			ArrayList<Integer> tem = new ArrayList<Integer>();
			for(int u=0;u<((clusterLevel.get(clusterLevel.size()-1)).get(index[0])).size();u++){
				tem.add(((clusterLevel.get(clusterLevel.size()-1)).get(index[0])).get(u));		
			}
			for(int u=0;u<((clusterLevel.get(clusterLevel.size()-1)).get(index[1])).size();u++){
				tem.add(((clusterLevel.get(clusterLevel.size()-1)).get(index[1])).get(u));		
			}
			tempAl.add(tem);
			temp[temp.length-1][temp.length-1] = 0;
			disMatrix = temp;
			clusterLevel.add(tempAl);
//			if(tempAl.size()==clusterNum){
//				for(int i=0;i<tempAl.size();i++){
//					ArrayList<Integer> al = tempAl.get(i);
//					//System.out.println("Cluster " + i + " Size: " + al.size());
//					for(int j =0;j<al.size();j++){
//						//System.out.print(" , "+al.get(j));
//						ID[al.get(j)] = i;
//					}
//					//System.out.println("");
//				}
//			}
			int n = 0;
			for(int i=1; i<tempAl.size(); i++){
				ArrayList<Integer> al = tempAl.get(i);
				if(al.size()>1)
					n = n + 1;
			}
			if(n==clusterNum){
				for(int i=0;i<tempAl.size();i++){
					ArrayList<Integer> al = tempAl.get(i);
					System.out.println(Z[level][2]);
					if(al.size()>1){
						for(int j =0;j<al.size();j++){
							//System.out.print(" , "+al.get(j));
							ID[al.get(j)] = i;
						}
					}else{
						ID[al.get(0)] = -1; //Noise
					}
					//System.out.println("");
				}
			}			
			//System.out.println(tempAl.size());
			//System.out.println(disMatrix.length);
			
			
		}
		SaveData sd = new SaveData();
		sd.save2D(Z, "treen.txt");
		
		return ID;
	}
	
    public static void main(String[] args) {
    	
    	long   start   =   System.currentTimeMillis(); 
    	double[][] data = new double[1277][2];
    	
        try {
        	File mFile = new File("compare.txt");
        	FileReader fr = new FileReader(mFile);
        	BufferedReader br = new BufferedReader(fr);
        	String line;
        	int num = 0;
        	while((line=br.readLine())!=null){
        		line = line.trim();        		
        		String[] str = line.split("\\s+");
        		int dimm = str.length;
        		ArrayList temp = new ArrayList(dimm);
        		for(int i=0;i<dimm;i++){
        			//System.out.println(str[i]);
        			data[num][i] = Double.parseDouble(str[i]);
        		}
    			num = num + 1;
        	}
        } catch (IOException ex) {
            ex.printStackTrace();
        }    
        double[][] disMatrix = new double[data.length][data.length];
        //Calculate the distance matrix
        System.out.println("Calculate the distance matrix");
        for(int i = 0; i < data.length; i++){
            for(int j = 0; j < data.length; j++){
            	double dis = 0.0;
            	for(int d = 0; d < data[0].length; d++){
            		dis = dis + (data[i][d]-data[j][d])*(data[i][d]-data[j][d]);
            	}
            	disMatrix[i][j] = Math.sqrt(dis);
            }
        }
        //Clustering
        System.out.println("Single Link Clustering");        
        SingleLink sl = new SingleLink(disMatrix, 6);
    	System.out.println(data.length);
    	int[] ID = sl.cluster();
    	System.out.println("Save Results..."); 	        
    	de.lmu.database.SaveData sa = new de.lmu.database.SaveData();
    	sa.save1D(ID,"sl.txt");	
  	  	long   end   =   System.currentTimeMillis(); 
  	  	System.out.println("All running time:"+Long.toString(end-start)+" ms.");
  	  	System.out.println("Ending");	
    }
	
}