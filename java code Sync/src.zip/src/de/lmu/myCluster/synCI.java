package de.lmu.myCluster;

import com.jmatio.io.MatFileReader;
import com.jmatio.types.MLDouble;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Exploring the Multi-Scale Hierarchical clusters based on local
 * synchronization Extensive Kuramoto model based synchronization
 *
 * @author Junming Shao
 * @param None Created on 16. Jan. 2009,
 */
public class synCI {

    public static final double C = 1;
    private static final String ArrayList = null;
    public double A;
    public static String fname;
    public int num;
    public int dim;
    public boolean normFlag;
    public boolean noiseFlag;
    public ArrayList src;
    int[][] biGraph;
    double[] kernelP;
    int ID;
    double[][] datan;
    double[][] data;
    int nf;
    int f;  //loop k
    double[] mdl;
    int lp;
    double minMDL;
    int nc;

    public synCI() {
        A = 0.0;
        num = 0;
        dim = 1;
        normFlag = false;
        noiseFlag = false;
        nf = 0;
        lp = 0;
        nc = 1;
        src = new ArrayList();
        mdl = new double[100];
        for (int i = 0; i < 100; i++) {
            mdl[i] = 0.0;
        }
        minMDL = Double.MAX_VALUE;
    }

    /**
     * Set the related parameters
     *
     * @param filename, the threshold for nearest neighbors of one object
     * @return none
     */
    public void setParams(String filename, double e) { //, boolean Flag,boolean noise){
        fname = filename;
        A = e;
        //normFlag = Flag;
        //noiseFlag = noise;
    }

    /**
     * Load the database from a given filename
     *
     * @param Filename
     * @return none
     */
    public void loadData(String fn) {

        try {
            File mFile = new File(fn);
            FileReader fr = new FileReader(mFile);
            BufferedReader br = new BufferedReader(fr);
            String line;

            while ((line = br.readLine()) != null) {
                line = line.trim();
                String[] str = line.split("\\s+");
                //System.out.println(num);
                dim = str.length;
                ArrayList temp = new ArrayList(dim);
                for (int i = 0; i < dim; i++) {
                    temp.add(Double.parseDouble(str[i]));
                }
                src.add(temp);
                num = num + 1;
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        //Normalize the data set
        data = new double[num][dim];
        for (int i = 0; i < num; i++) {
            for (int j = 0; j < dim; j++) {
                data[i][j] = (Double) ((ArrayList) src.get(i)).get(j);
            }
        }
    }

    public void norm1(ArrayList data) {
        int n = data.size();
        int d = ((ArrayList) data.get(0)).size();
        double[] max = new double[d];
        //Initialize
        for (int i = 0; i < d; i++) {
            max[i] = -1e10;
        }
        //Find the maximum value for each variance

        for (int j = 0; j < d; j++) {
            for (int i = 0; i < n; i++) {
                double temp = (Double) ((ArrayList) data.get(i)).get(j);
                if (temp > max[j]) {
                    max[j] = temp;
                }
            }
        }
        //Normalize the data set
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < d; j++) {
                double temp = (Double) ((ArrayList) data.get(i)).get(j);
                temp = temp / max[j];
                ((ArrayList) data.get(i)).set(j, temp);
            }
        }
        //saveData(data, "normx.txt");
    }

    /**
     * save the clustering result
     *
     * @param ArrayList data (result)
     * @param String fn (filename)
     * @return none
     */
    public void norm(ArrayList data) {
        int n = data.size();
        int d = ((ArrayList) data.get(0)).size();
        double[] max = new double[d];
        double[] min = new double[d];
        //Initialize
        for (int i = 0; i < d; i++) {
            max[i] = -Double.MAX_VALUE;
            min[i] = Double.MAX_VALUE;
        }
        //Find the maximum value for each variance

        for (int j = 0; j < d; j++) {
            for (int i = 0; i < n; i++) {
                double temp = (Double) ((ArrayList) data.get(i)).get(j);
                if (temp > max[j]) {
                    max[j] = temp;
                }
                if (temp < min[j]) {
                    min[j] = temp;
                }
            }
        }
        //Normalize the data set
        datan = new double[n][dim];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < d; j++) {
                double temp = (Double) ((ArrayList) data.get(i)).get(j);
                temp = (temp - min[j]) / (max[j] - min[j]);
                ((ArrayList) data.get(i)).set(j, temp);
                datan[i][j] = temp;
            }
        }

    }

    /**
     * save the clustering result
     *
     * @param ArrayList data (result)
     * @param String fn (filename)
     * @return none
     */
    public void saveData(ArrayList data, String fn) {

        int lens = data.size();
        try {
            FileOutputStream fout = new FileOutputStream(new File(fn));
            for (int i = 0; i < lens; i++) {
                for (int j = 0; j < dim; j++) {
                    fout.write(((Double) (((ArrayList) data.get(i)).get(j)) + "\t").getBytes());
                }
                fout.write(("\r\n").getBytes());
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public void save1D(int[] data, String fn) {

        int row = data.length;

        try {
            FileOutputStream fout = new FileOutputStream(new File(fn));
            //fout.write(("Data ID\t Cluster ID").getBytes());
            //fout.write(("\r\n").getBytes());
            for (int i = 0; i < row; i++) {
                fout.write(((Integer) (data[i]) + "\t").getBytes());
                fout.write(("\r\n").getBytes());
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public void save1D(double[] data, String fn) {

        int row = data.length;

        try {
            FileOutputStream fout = new FileOutputStream(new File(fn));
            //fout.write(("Data ID\t Cluster ID").getBytes());
            //fout.write(("\r\n").getBytes());
            for (int i = 0; i < row; i++) {
                fout.write(((Double) (data[i]) + "\t").getBytes());
                fout.write(("\r\n").getBytes());
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public void save2D(double[][] data, String fn) {

        int row = data.length;

        try {
            FileOutputStream fout = new FileOutputStream(new File(fn));
            //fout.write(("Data ID\t Cluster ID").getBytes());
            //fout.write(("\r\n").getBytes());
            for (int i = 0; i < row; i++) {
                for (int j = 0; j < data[0].length; j++) {
                    fout.write(((Double) (data[i][j]) + "\t").getBytes());
                }
                fout.write(("\r\n").getBytes());
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * compute the distance
     *
     * @param double dis
     * @return none
     */
    public double distance(double[] dis) {

        double val = 0.0;
        for (int i = 0; i < dis.length; i++) {
            val = val + dis[i] * dis[i];
        }
        double dist = Math.sqrt(val);
        return dist;
    }

    public double[][] ArrayListtoDouble(ArrayList src) {
        int num = src.size();
        int dim = ((ArrayList) src.get(0)).size();

        double[][] data = new double[num][dim];

        for (int i = 0; i < num; i++) {
            for (int j = 0; j < dim; j++) {
                data[i][j] = (Double) (((ArrayList) src.get(i)).get(j));
            }
        }

        return data;
    }

    public void cluster(String fn) {
        //Set related parameters (User parameter specification)
        //String fn = "wisconsin.txt";
        //setParams(fn,param);
        //load the data set;
        //loadData(fname);
        //data = ArrayListtoDouble(src);
        //If necessary, normalize the data set

        int len = src.size();
        int dimm = dim;
        //System.out.println("Number of Objects:" + len + "; Dimensionality: " + dimm);
        boolean loop = true;
        int loopNum = 0;
        double localOrder = 0.0;
        double allorder = 0.0;
        ArrayList x = src;
        //saveData(x, "synC0.txt");
        ArrayList prex = new ArrayList();
        double[] rr = new double[50];
//    	double[][] pp = new double[x.size()][50];
        for (int i = 0; i < 50; i++) {
            rr[i] = 0.0;
        }

        //Copy data set
        for (int i = 0; i < len; i++) {
            ArrayList temp1 = new ArrayList(dimm);
            for (int j = 0; j < dimm; j++) {
                temp1.add(((ArrayList) x.get(i)).get(j));
//    			pp[i][loopNum] = (Double)((ArrayList)x.get(i)).get(j);
            }
            prex.add(temp1);

        }

        //System.out.println(((ArrayList)x.get(0)).get(0));
        while (loop) {

            double[] order = new double[len];
            localOrder = 0.0;
            allorder = 0.0;

            loopNum = loopNum + 1;

            for (int i = 0; i < len; i++) {
                double[] sinValue = new double[dimm];
                double[] diss = new double[dimm];
                double[] temp = new double[dimm];

                double dis = 0.0;
                double kij = 0.0;
                double allk = 0.0;

                int num = 0;
                double sita = 0.0;
                ArrayList diff = new ArrayList();

                for (int j = 0; j < len; j++) {
                    dis = 0.0;
                    kij = 0.0;
                    for (int d = 0; d < dimm; d++) {
                        //diss[d] = (Double)((ArrayList)(x.get(j))).get(d)-(Double)((ArrayList)(x.get(i))).get(d);
                        diss[d] = (Double) ((ArrayList) (prex.get(j))).get(d) - (Double) ((ArrayList) (prex.get(i))).get(d);

                    }

                    dis = distance(diss);
                    //System.out.println(dis);

                    if (dis < A) {
                        num = num + 1;
                        //Calculating the coupling strength
                        for (int d = 0; d < dimm; d++) {
                            //temp[d] = (diss[d]+ 1e-10)/((Double)((ArrayList)(x.get(j))).get(d)+ 1e-10);
                            temp[d] = (diss[d] + 1e-10) / ((Double) ((ArrayList) (prex.get(j))).get(d) + 1e-10);
                        }
                        // Weighted coupling strength of each object
                        //kij = Math.pow(distance(temp),1);
                        //allk = allk + kij;	

                        for (int d = 0; d < dimm; d++) {
                            //sinValue[d] = sinValue[d] + kij*Math.sin(diss[d]);		 
                            sinValue[d] = sinValue[d] + Math.sin(diss[d]);
                        }
                        sita = sita + Math.exp(-dis);
                    }
                }
                if (num > 1) {
                    for (int d = 0; d < dimm; d++) {
                        double[] x1 = new double[dimm];
                        //x1[d] = ((Double)((ArrayList)(x.get(i))).get(d))+ (myCluster.C*sinValue[d]+1e-10)/(allk+1e-10);
                        //x1[d] = ((Double)((ArrayList)(prex.get(i))).get(d))+ (C*sinValue[d]+1e-10)/(allk+1e-10);
                        //x1[d] = ((Double)((ArrayList)(x.get(i))).get(d))+ ((C/num)*sinValue[d]+1e-10);
                        x1[d] = ((Double) ((ArrayList) (prex.get(i))).get(d)) + ((C / num) * sinValue[d]);
                        ((ArrayList) (x.get(i))).set(d, x1[d]);
                    }
                    order[i] = sita / num;
                }
            }
            for (int k = 0; k < len; k++) {
                allorder = allorder + order[k];
            }
            //Local order parameter
            localOrder = allorder / len;
            rr[loopNum] = localOrder;

            //saveData(x, "synC"+String.valueOf(loopNum)+".txt");
            //System.out.println(Double.toString(localOrder));
            if (localOrder > 1 - (1e-2) || loopNum >= 20) {
                loop = false;
                //System.out.println("LOCAL ORDER PARAMETER:"+Double.toString(localOrder));
                //System.out.println("ALL LOOPS:"+Double.toString(loopNum));
            }
            // Save the previous value of the objects of the data set

            for (int i = 0; i < len; i++) {
                ArrayList temp1 = new ArrayList(dimm);
                for (int j = 0; j < dimm; j++) {
                    temp1.add(((ArrayList) x.get(i)).get(j));
//	    			pp[i][loopNum] = (Double)((ArrayList)x.get(i)).get(j);
                }
                prex.set(i, temp1);
            }

//	    	saveData(x, "synC.txt");
            this.save1D(rr, "r.txt");
//	    	this.save2D(pp, "pp.txt");
        }

        //System.out.println("Find the synchronization clusters...");
        int[] ids = findSynCluster(x);
        double cc = synCMDL(ids, data);

        mdl[lp] = cc;
        if (cc < minMDL && nc > 1) {
            minMDL = cc;
            System.out.println("...OK");
            save1D(ids, fn + "-synC-ID.txt");
            System.out.println("ids saved");
            //saveData(x, "synC.txt");
        }
        System.out.println("Clusters =" + this.ID);
        lp = lp + 1;

    }

    public void estimationP(double[][] data) {
        int num = data.length;
        int dim = data[0].length;

        double[] h = findBandwidth(data, "plug_bump"); //plug_bump //plug_dirty
//    	for(int i=0;i<h.length;i++){
//    		System.out.println("Bandwidth dimension " + i + "; value = " + h[i]);
//    	}

////============ Test the fitness of the kernel density estimation=========    	
//   	    double[][] x = new double[128][128];
//   	    double[][] y = new double[128][128];
//   	    double[][] pv = new double[128][128]; 
//    	for(int i=0;i<dim;i++){
//        	double minV = Double.MAX_VALUE;
//        	double maxV = -Double.MAX_VALUE;
//    		for(int j=0;j<num;j++){
//    			if(data[j][i]>maxV) maxV = data[j][i];
//    			if(data[j][i]<minV) minV = data[j][i];
//    		}
//    		
//    		if(i==0){
//	    		for(int j=0;j<128;j++){
//	    			for(int k=0;k<128;k++){
//	    				x[j][k] = minV-0.25*(maxV-minV)+k*1.5*(maxV - minV)/128.0;   			
//	    			}
//	    		}
//    		}else{    			
//	    		for(int j=0;j<128;j++){
//	    			for(int k=0;k<128;k++){
//	    				y[j][k] = minV-0.25*(maxV-minV)+j*1.5*(maxV - minV)/128.0;   			
//	    			}
//	    		}
//    		}	
//    	}
//    	
//    	for(int i=0;i<128;i++){
//    		for(int j=0;j<128;j++){
//    			double[] xx = new double[2];
//    			xx[0] = x[i][j];
//    			xx[1] = y[i][j];
//    			pv[i][j] = kernel_estimation(data, xx, h);
//    		}
//    		//System.out.println("number id: " + i + " probability= " + pv[i]);
//    	}  	
//    	save2D(pv, "pValue.txt");
//    	save2D(x, "X.txt");
//    	save2D(y, "Y.txt");
////==================End==============================
        kernelP = new double[num];
        double s = 0.0;
        //double mp = -Double.MAX_VALUE;
        for (int i = 0; i < num; i++) {
            kernelP[i] = kernel_estimation(data, data[i], h);
            //System.out.println("kernelP: " + kernelP[i]);
            s = s + kernelP[i];
            //if(kernelP[i]>mp) mp = kernelP[i];
//    		if(kernelP[i]>1){
//    		System.out.println("number id: " + i + " probability= " + kernelP[i]);
//    		//save2D(data,"ff.txt");
//    		}
        }

        for (int i = 0; i < num; i++) {
            kernelP[i] = kernelP[i] / s;
            //kernelP[i] = kernelP[i]/mp;
            //System.out.println("number id: " + i + " probability= " + kernelP[i]);
        }

    }

    public double[] findBandwidth(double[][] data, String method) {
        double[] h = new double[data[0].length];

        if (method.equalsIgnoreCase("plug_dirty")) {
            double[] stdp = std(data);

            for (int i = 0; i < data[0].length; i++) {
//	    		System.out.println("===std dimension " + i + "; value = " + stdp[i]);
                //h[i] = 1.06*stdp[i]*Math.pow(data.length, -0.2);
                h[i] = Math.pow((4.0 / (dim + 2)), 1.0 / (dim + 4)) * stdp[i] * Math.pow(data.length, -1.0 / (dim + 4));
                //System.out.println("===Bandwidth dimension " + i + "; value = " + h[i]);
            }
        }
        if (method.equalsIgnoreCase("plug_bump")) {
            double[] stdp = std(data);
            double[] R = IQR(data);

            for (int i = 0; i < data[0].length; i++) {
//	    		System.out.println("===std dimension " + i + "; value = " + stdp[i]);
                double temp = Math.min(stdp[i], R[i]);
                //h[i] = 1.06*temp*Math.pow(data.length, -0.2);
                h[i] = Math.pow((4.0 / (dim + 2)), 1.0 / (dim + 4)) * temp * Math.pow(data.length, -1.0 / (dim + 4));
                //System.out.println("===Bandwidth dimension " + i + "; value = " + h[i]);
            }
        }

        return h;
    }

    public double[] std(double[][] data) {
        double[] avg = new double[data[0].length];
        double[] std = new double[data[0].length];
        for (int i = 0; i < data[0].length; i++) {
            avg[i] = 0;
        }

        for (int j = 0; j < data[0].length; j++) {
            for (int i = 0; i < data.length; i++) {
                avg[j] = avg[j] + data[i][j];
            }
            avg[j] = avg[j] / data.length;
            double s = 0.0;
            for (int i = 0; i < data.length; i++) {
                s = s + (data[i][j] - avg[j]) * (data[i][j] - avg[j]);
            }
            std[j] = Math.sqrt(((s + 0.0) / (data.length - 1)));

        }

        return std;
    }

    public double[] IQR(double[][] data) {

        double[] IQR = new double[data[0].length];
        double[][] tempd = new double[data.length][data[0].length];

        for (int j = 0; j < data[0].length; j++) {
            for (int i = 0; i < data.length; i++) {
                tempd[i][j] = data[i][j];
            }
        }

        for (int j = 0; j < data[0].length; j++) {
            for (int i = 0; i < data.length; i++) {
                for (int k = i + 1; k < data.length; k++) {
                    double temp = 0.0;
                    if (tempd[i][j] > tempd[k][j]) {
                        temp = tempd[k][j];
                        tempd[k][j] = tempd[i][j];
                        tempd[i][j] = temp;
                    }
                }
            }
            if (tempd.length > 3) {
                IQR[j] = (tempd[(int) (tempd.length * 0.75 + 0.5)][j] - tempd[(int) (tempd.length * 0.25 + 0.5)][j]) / (2 * 1.34);
            } else {
                IQR[j] = (tempd[1][j] - tempd[0][j]) / (2 * 1.34);
            }
        }

        return IQR;
    }

    public double kernel_estimation(double[][] data, double[] x, double[] h) {

        double sum = 0.0;
        for (int i = 0; i < data.length; i++) {
            double s = 1.0;
            for (int j = 0; j < data[0].length; j++) {
                if (h[j] != 0) {
                    s = s * (1.0 / h[j]) * kernel((x[j] - data[i][j]) / h[j]);
                    //System.out.println("kernel: " + kernel((x[j]-data[i][j])/h[j]) + "; x[j]-data[i][j] = " + (x[j]-data[i][j])+ " s =" +s);
                    if (s == 0) {
                        s = 1e-300;
                    }
                } else {
                    s = s * (1.0 / data.length);
                }
            }
            sum = sum + s;
        }

        //System.out.println("sum: " + sum + "data Length " + data.length);
        return sum / (data.length);

    }

    public double kernel(double x) {

        if ((1.0 / Math.sqrt(2 * Math.PI)) * Math.exp(-x * x / 2.0) == 0) {
            return 1;
        } else {
            return (1.0 / Math.sqrt(2 * Math.PI)) * Math.exp(-x * x / 2.0);
        }
    }

    public int[] findSynCluster(ArrayList x) {
        int len = x.size();
        int[] id = new int[len];
        int[] f = new int[len];
        for (int i = 0; i < len; i++) {
            id[i] = -1;
            f[i] = 0;
        }
        ID = 0;
        nf = 0;
        for (int i = 0; i < len; i++) {
            if (f[i] == 0) {
                //ID = ID + 1;
                double[] diss = new double[dim];
                int num = 0;
                ArrayList al = new ArrayList();
                for (int j = 0; j < len; j++) {
                    if (i != j) {
                        for (int d = 0; d < dim; d++) {
                            diss[d] = (Double) ((ArrayList) (x.get(j))).get(d) - (Double) ((ArrayList) (x.get(i))).get(d);
                        }
                        double dis = distance(diss);
                        //System.out.println("Distance:"+dis);
                        if (Math.abs(dis) < (Math.sqrt(dim) * 1e-2)) {
                            num = num + 1;
                            al.add(j);
                        }
//		    			if(num>0 && Math.abs(dis)<(Math.sqrt(dim)*1e-2)){
//		    				f[j] = 1;
//		    				id[j] = ID;	    				   						    			
//		    			}
                    }
                }
                if (num > 2) {
                    f[i] = 1;
                    for (int k = 0; k < al.size(); k++) {
                        f[(Integer) al.get(k)] = 1;
                        id[(Integer) al.get(k)] = ID;
                    }
                    id[i] = ID;
                    ID = ID + 1;
                } else {
                    nf = 1;
                    if (num > 0) {
                        for (int k = 0; k < al.size(); k++) {
                            //f[(Integer)al.get(k)] = 1;
                            id[(Integer) al.get(k)] = -1;
                        }
                    }
                    id[i] = -1;
                }
            }
        }

        return id;

    }

    public double log2(double x) {
        return Math.log(x) / Math.log(2);
    }

    public double synCMDL(int[] idx, double[][] data) {
        nc = ID;
        if (nf == 1) {
            nc = ID + 1;
        }
        double cc = 0;
        int n = idx.length;
        //System.out.println("Cluster Size: " + nc);
        if (nc == 1) {
            f = 0;
        }
        int[] count = new int[nc];
        for (int i = 0; i < nc; i++) {
            count[i] = 0;
        }
        if (nf == 1) {
            for (int i = 0; i < n; i++) {
                for (int j = -1; j <= ID; j++) {
                    if (idx[i] == j) {
                        count[j + 1] = count[j + 1] + 1;
                    }
                }
            }
        } else {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j <= this.ID; j++) {
                    if (idx[i] == j) {
                        count[j] = count[j] + 1;
                    }
                }
            }
        }

        if (nf == 1) {
            for (int j = -1; j <= this.ID - 1; j++) {
                int[] cluster = new int[count[j + 1]];
                double[][] cdata = new double[count[j + 1]][dim];
                int nn = 0;
                for (int i = 0; i < n; i++) {
                    if (idx[i] == j) {
                        for (int k = 0; k < dim; k++) {
                            cdata[nn][k] = data[i][k];
                        }
                        cluster[nn] = i;
                        nn = nn + 1;
                    }
                }
//	    		if(count[0]<2*(num/(double)nc)){ 
                double ccost = coding_cost(cluster, cdata);
                cc = cc + ccost;
                System.out.println("Coding for Cluster " + j + "; Size: " + (nn) + "; Coding cost = " + ccost);
//	    		}
//	    		else{ //most objects are noise;
//	    			return Double.MAX_VALUE; 
//	    		}
            }
        } else {
            for (int j = 0; j <= this.ID - 1; j++) {
                int[] cluster = new int[count[j]];
                double[][] cdata = new double[count[j]][dim];
                int nn = 0;
                for (int i = 0; i < n; i++) {
                    if (idx[i] == j) {
                        for (int k = 0; k < dim; k++) {
                            cdata[nn][k] = data[i][k];
                        }
                        cluster[nn] = i;
                        nn = nn + 1;
                    }
                }

                double ccost = coding_cost(cluster, cdata);
                cc = cc + ccost;
                System.out.println("Coding for Cluster " + j + "; Size: " + (nn) + "; Coding cost = " + ccost);
            }
        }

        //===========Description complex term coding====================//
//    	//========= 1. Number of clusters====
        cc = cc + logstar2(nc);
//    	cc = cc + log2(nc);
//    	//cc = cc + Math.log(nc);
//    	//System.out.println("Coding cost for number of cluster is: " + log2(nc));
//    	//========= 2. Cluster Size
//    	for(int i=0;i<nc;i++){
//    		double ss = 0.0;
//    		for(int j=i;j<nc;j++){
//    			ss = ss + count[j];
//    		}
//    		cc = cc + log2(ss-nc+i+1);
//    	}

        System.out.println("Total Coding cost is: " + cc);
        return cc;
    }

    public double coding_cost(int[] cluster, double[][] cdata) {
        double c = 0.0;

        if (cluster.length > 1) {
            estimationP(cdata);

            for (int i = 0; i < cluster.length; i++) {
                if ((cluster.length) / (double) (num) > 0.8) { // the extreme case: one cluster (with coding CLUSTER_ID: 1 )
                    if (kernelP[i] > 1e-5) {
                        c = c + log2((double) (num) / (cluster.length) + 1) + log2(1.0 / (kernelP[i]));
                    } else {
                        c = c + log2((double) (num)) + log2(2.0);
                    }
                } else {
                    if (kernelP[i] > 1e-5) {
                        c = c + log2((double) (num) / (cluster.length)) + log2(1.0 / (kernelP[i]));
                    } else {
                        c = c + log2((double) (num)) + log2(2.0);
                    }
                    //c = c + Math.log((double)num/(cluster.length))+ Math.log(1.0/(kernelP[i]));
                    //System.out.println("Data Object" + i + ", coding:" + log2(1.0/(kernelP[i]+1e-20)));
                    //c = c + log2(1.0/(kernelP[i])); // Coding data
                }
                //System.out.println("Data Object" + i + ", coding:" + log2(1.0/(kernelP[i]+1e-20)));
            }

        } else {
            c = c + log2((double) num) + log2(2.0);
            //c = Math.log((double)num) + Math.log(1.0);
            //System.out.println("Data Object coding:" + c);
            //c = log2(1.0);
        }

//    	if(cluster.length>1){
//    		
//    		
//	    	for(int i=0;i<cluster.length;i++){
//	    		//kernelP[cluster[i]] = kernelP[cluster[i]]/s;
//	    		c = c + log2((double)num/(cluster.length))+ log2(1.0/(kernelP[cluster[i]])); // Coding Cluster-id and data
//	    		//System.out.println("Data Object" + i + ", coding:" + log2(1.0/(kernelP[i])));
//	    		//c = c + log2(1.0/(kernelP[cluster[i]])); // Coding data
//	    	}
//    	}else{
//    		c = log2((double)num) + log2(1.0);
//    		//c = log2(1.0);
//    	}
        //c = c + log2((double)num/(cluster.length)); //Coding Cluster-id
        //c = c + Math.log((double)num/(cluster.length));
        //====parameter coding=======
        double pc = ((dim) / 2.0) * log2(cluster.length + 1);
        //double pc = (dim/2.0)*Math.log(cluster.length);    	
        c = c + pc;
        //System.out.println("Free-parameters' coding:" + pc);
        return c;
    }

    public double logstar2(double x) {
        double l = 0.0;
        while (x > 1) {
            x = log2(x);
            l = l + x;
        }
        return l;
    }

    public double dist(ArrayList al1, ArrayList al2) {
        double res = 0.0;

        if (al1.size() != al2.size()) {
            return 0.0;
        } else {
            double[] diss = new double[al1.size()];
            for (int d = 0; d < al1.size(); d++) {
                diss[d] = (Double) (al1.get(d)) - (Double) (al2.get(d));
            }
            res = distance(diss);
        }

        return res;

    }

    public double kNN(String fn, int k) {

        double res = 0.0;

        // check inputs for validity
        if (src.size() == 0 || k <= 0) {
            return 0.0; // bail on bad input
        }
        for (int s = 0; s < src.size(); s++) {

            double[] d = new double[k];
            int n = 0; // number of element in the res

            double dd = dist((ArrayList) src.get(s), (ArrayList) src.get(0)); // load first one into list
            d[n++] = dd;

            // go through all other data points
            for (int i = 1; i < src.size(); i++) {
                dd = dist((ArrayList) src.get(s), (ArrayList) src.get(i));
                if (n < k || d[k - 1] > dd) { //add one
                    if (n < k) {
                        d[n++] = dd;
                    }
                    int j = n - 1;
                    while (j > 0 && dd < d[j - 1]) { // slide big data up
                        d[j] = d[j - 1];
                        j--;
                    }
                    d[j] = dd;
                }
            }

            res = res + d[k - 1];

        }
        return res / src.size();
    }

    public double kNN(int k) {

        double res = 0.0;

        // check inputs for validity
        if (src.size() == 0 || k <= 0) {
            return 0.0; // bail on bad input
        }
        for (int s = 0; s < src.size(); s++) {

            double[] d = new double[k];
            int n = 0; // number of element in the res

            double dd = dist((ArrayList) src.get(s), (ArrayList) src.get(0)); // load first one into list
            d[n++] = dd;

            // go through all other data points
            for (int i = 1; i < src.size(); i++) {
                dd = dist((ArrayList) src.get(s), (ArrayList) src.get(i));
                if (n < k || d[k - 1] > dd) { //add one
                    if (n < k) {
                        d[n++] = dd;
                    }
                    int j = n - 1;
                    while (j > 0 && dd < d[j - 1]) { // slide big data up
                        d[j] = d[j - 1];
                        j--;
                    }
                    d[j] = dd;
                }
            }

            res = res + d[k - 1];

        }
        return res / src.size();
    }

    public void loadMatlabData(String dir, String variableName) {
        double[][] dd = new double[1][1];

        MatFileReader mfr = null;
        try {
            mfr = new MatFileReader(dir);
        } catch (IOException e) {
        }
        if (mfr != null) {
            dd = ((MLDouble) mfr.getMLArray(variableName)).getArray();
        }
        dim = dd[0].length;
        for (int i = 0; i < dd.length; i++) {
            ArrayList temp = new ArrayList(dim);
            for (int j = 0; j < dim; j++) {
                temp.add(dd[i][j]);
            }
            src.add(temp);
        }
        num = dd.length;

        //Normalize the data set
        data = new double[num][dim];
        for (int i = 0; i < num; i++) {
            for (int j = 0; j < dim; j++) {
                data[i][j] = (Double) ((ArrayList) src.get(i)).get(j);
            }
        }

    }

    /**
     * main function - Dynamical clustering
     */
    public static void main(String[] args) {

        long start = System.currentTimeMillis();
        String fn = "bla"; ///wisconsin.txt //diabetes.txt //outliers
        synCI myCluster = new synCI();
//    	myCluster.loadData(fn+".txt");

        //myCluster.loadMatlabData("twoMoonsOneGaussianLessOverlap.mat", "data");
        // myCluster.loadMatlabData("twoMoons5000scatter015.mat", "data");
          //myCluster.loadMatlabData("dist3_4.mat", "data");
             myCluster.loadMatlabData("outlierStronger1.mat", "data");
          //String dir = "twoMoons5000scatter015.mat"; //perfekt mit seed 5
         //myCluster.loadMatlabData("leaf.mat", "data");
          //myCluster.loadMatlabData("zoo.mat", "data");


        //myCluster.estimationP(myCluster.data); // Test
        //====Normalize the data to [0 1]
        myCluster.norm(myCluster.src);
        double K0 = myCluster.kNN(3);
        double K1 = myCluster.kNN(4);

        myCluster.f = 1;
        double K = K0;
        double[] kk = new double[50];
        //int n = 0;
        while (myCluster.f == 1 && myCluster.lp < 50) {
            K = K + (K1 - K0) * (myCluster.lp);
            kk[myCluster.lp] = K;
            System.out.println("=============Perform the clustering on K = " + K + " ============");
            myCluster.setParams(fn, K);
            myCluster.cluster(fn);
        }
        myCluster.save1D(myCluster.mdl, "mdl1.txt");
        myCluster.save1D(kk, "params.txt");
        long end = System.currentTimeMillis();
        System.out.println("Minimum Coding Cost:" + Double.toString(myCluster.minMDL));
        System.out.println("All running time:" + Long.toString((end - start) / 1000) + " s.");
        System.out.println("Ending");
    }
}
