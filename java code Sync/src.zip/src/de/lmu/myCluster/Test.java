package de.lmu.myCluster;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Exploring the Multi-Scale Hierarchical clusters based on local synchronization
 * Extensive Kuramoto model based synchronization
 * 
 * @author Junming Shao
 * @param None
 * Created on 16. Jan. 2009, 
 */


public class Test{
	
    public static final double C = 1;
    public static final int loopnum = 200;
	private static final String ArrayList = null;
    public double A;
    public static String fname;
    public int num;
    public int dim;
    public boolean normFlag;
    public boolean noiseFlag;
    public ArrayList src; 
    int[][] biGraph;
    double[] kernelP;
    int ID;
    double[][] datan;
    double[][] data;
    int nf;
    int f;  //loop k
    double[] mdl;
    double[] mdl_no;//no outlier mdl
    int[][] clusterID;
    int lp;
    double minMDL;
    int nc;
    String testindex = "";
    
    double[] movRange; 
    
    public Test() {
    	A = 0.0;
    	num = 0;
    	dim = 1; 
    	normFlag = false;
    	noiseFlag = false;
    	nf = 0;
    	lp  = 0;
    	nc = 1;
    	src = new ArrayList();
    	mdl = new double[loopnum];
    	for(int i=0;i<loopnum;i++){
    		mdl[i] = 0.0;
    	}
    	mdl_no = new double[loopnum];
    	for(int i=0;i<loopnum;i++){
    		mdl_no[i] = 0.0;
    	}
    	minMDL = Double.MAX_VALUE;
    }
    /**
     * Set the related parameters
     * @param filename, the threshold for nearest neighbors of one object
     * @return none
     */  
    public void setParams(String filename, double e){ //, boolean Flag,boolean noise){
    	fname = filename;
    	A = e;	
    	//normFlag = Flag;
    	//noiseFlag = noise;
    }
    /**
     * Load the database from a given filename
     * @param Filename
     * @return none
     */
    public void loadData(String fn){
            
        try {
        	File mFile = new File(fn);
        	FileReader fr = new FileReader(mFile);
        	BufferedReader br = new BufferedReader(fr);
        	String line;
        	
        	while((line=br.readLine())!=null){
        		line = line.trim();        		
        		String[] str = line.split("\\s+");
        		//System.out.println(num);
        		dim = str.length;
        		ArrayList temp = new ArrayList(dim);    		
        		for(int i=0;i<dim;i++){
        			temp.add(Double.parseDouble(str[i]));
        		}
    			src.add(temp);
    			num = num + 1;
        	}
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        
        //Normalize the data set
        data = new double[num][dim];
        for(int i=0;i<num;i++){
      	  for(int j=0;j<dim;j++){	  
      		data[i][j] = (Double)((ArrayList)src.get(i)).get(j); 
      	  }
         }
    }

    public void norm1(ArrayList data){
       int n = data.size();
       int d = ((ArrayList)data.get(0)).size();
       double [] max = new double[d];
       //Initialize
       for(int i=0;i<d;i++){
    	   max[i]= -1e10;
       }
       //Find the maximum value for each variance

       for(int j=0;j<d;j++){
    	  for(int i=0;i<n;i++){
    		  double temp = (Double)((ArrayList)data.get(i)).get(j);
    		  if(temp > max[j]){
    			  max[j]= temp;
    		  }    		  
    	  }
       }
       //Normalize the data set
       for(int i=0;i<n;i++){
     	  for(int j=0;j<d;j++){
     		  double temp = (Double)((ArrayList)data.get(i)).get(j);
     		  temp = temp/max[j];
     		 ((ArrayList)data.get(i)).set(j, temp);
     	  }
        }	
       //saveData(data, "normx.txt");
    }    
    
    /**
     * save the clustering result
     * @param ArrayList data (result)
     * @param String fn (filename)
     * @return none
     */
    public void norm(ArrayList data){
       int n = data.size();
       int d = ((ArrayList)data.get(0)).size();
       double [] max = new double[d];
       double [] min = new double[d];
       //Initialize
       for(int i=0;i<d;i++){
    	   max[i]= -Double.MAX_VALUE;
    	   min[i]= Double.MAX_VALUE;
       }
       //Find the maximum value for each variance

       for(int j=0;j<d;j++){
    	  for(int i=0;i<n;i++){
    		  double temp = (Double)((ArrayList)data.get(i)).get(j);
    		  if(temp > max[j]){
    			  max[j]= temp;
    		  }    		  
    		  if(temp < min[j]){
    			  min[j]= temp;
    		  } 
    	  }
       }
       //Normalize the data set
       datan = new double[n][dim];
       for(int i=0;i<n;i++){
     	  for(int j=0;j<d;j++){
     		  double temp = (Double)((ArrayList)data.get(i)).get(j);
     		  temp = (temp-min[j])/(max[j]-min[j]);     		  
     		 ((ArrayList)data.get(i)).set(j, temp);
     		datan[i][j] = temp;
     	  }
        }	
       
    }   
    
    /**
     * save the clustering result
     * @param ArrayList data (result)
     * @param String fn (filename)
     * @return none
     */
    public void saveData(ArrayList data, String fn){
        
    	int lens = data.size();
        try{
			FileOutputStream fout = new FileOutputStream(new File(fn));     
			for(int i=0;i<lens;i++){   
				for(int j=0; j<dim;j++){   
					fout.write(((Double)(((ArrayList)data.get(i)).get(j))+"\t").getBytes());   
				}   
			fout.write(("\r\n").getBytes());   
			}   
        } catch (IOException ex) {
            ex.printStackTrace();
        }    		
    }
    
	public void save1D(int[] data, String fn){
	    
		int row = data.length;
		
	    try{
			FileOutputStream fout = new FileOutputStream(new File(fn)); 
			//fout.write(("Data ID\t Cluster ID").getBytes());
			//fout.write(("\r\n").getBytes());
			for(int i=0;i<row;i++){   
			fout.write(((Integer)(data[i])+"\t").getBytes());    
			fout.write(("\r\n").getBytes());   
			}   
	    } catch (IOException ex) {
	        ex.printStackTrace();
	    }    		
	}
	
	public void save1D(double[] data, String fn){
	    
		int row = data.length;
		
	    try{
			FileOutputStream fout = new FileOutputStream(new File(fn)); 
			//fout.write(("Data ID\t Cluster ID").getBytes());
			//fout.write(("\r\n").getBytes());
			for(int i=0;i<row;i++){   
			fout.write(((Double)(data[i])+"\t").getBytes());    
			fout.write(("\r\n").getBytes());   
			}   
	    } catch (IOException ex) {
	        ex.printStackTrace();
	    }    		
	}
	
	public void save2D(double[][] data, String fn){
	    
		int row = data.length;
		
	    try{
			FileOutputStream fout = new FileOutputStream(new File(fn)); 
			//fout.write(("Data ID\t Cluster ID").getBytes());
			//fout.write(("\r\n").getBytes());
			for(int i=0;i<row;i++){ 
				for(int j=0;j<data[0].length;j++){
					fout.write(((Double)(data[i][j])+"\t").getBytes());  
				}
			fout.write(("\r\n").getBytes());   
			}   
	    } catch (IOException ex) {
	        ex.printStackTrace();
	    }    		
	}
    /**
     * compute the distance
     * @param double dis
     * @return none
     */    
    public double distance(double[] dis){
    	
    	double val = 0.0;
    	for(int i=0;i<dis.length;i++){
    		val = val + dis[i]*dis[i];
    	}   
    	double dist = Math.sqrt(val);
    	return dist;
    }
    
    public double[][] ArrayListtoDouble(ArrayList src){
    	int num = src.size();
    	int dim = ((ArrayList)src.get(0)).size();
    	
    	double[][] data = new double[num][dim];
    	
    	for(int i=0;i< num; i++){
    		for(int j=0;j<dim;j++){
    			data[i][j] = (Double)(((ArrayList)src.get(i)).get(j));
    		}
    	}
    	
    	return data;
    }
    
    
    
    public void cluster(){
    	//Set related parameters (User parameter specification)
    	//String fn = "wisconsin.txt";
    	//setParams(fn,param);
    	//load the data set;
    	//loadData(fname);
    	//data = ArrayListtoDouble(src);
    	//If necessary, normalize the data set
    	
    	int len = src.size();
    	int dimm = dim;
    	//System.out.println("Number of Objects:" + len + "; Dimensionality: " + dimm);
    	boolean loop = true;
    	int loopNum = 0;
    	double localOrder = 0.0;
    	double allorder = 0.0;
    	ArrayList x = src;
    	//saveData(x, "synC0.txt");
    	ArrayList prex = new ArrayList();
    	double[] rr = new double[50];
//    	double[][] pp = new double[x.size()][50];
    	for(int i=0;i<50;i++)
    		rr[i] = 0.0;
    	
    	//Copy data set
    	
    	for(int i=0;i<len;i++){
    		ArrayList temp1 = new ArrayList(dimm);    		
    		for(int j=0;j<dimm;j++){
    			temp1.add(((ArrayList)x.get(i)).get(j));
//    			pp[i][loopNum] = (Double)((ArrayList)x.get(i)).get(j);
    		}
			prex.add(temp1);
			
    	} 

    	//System.out.println(((ArrayList)x.get(0)).get(0));
    	while(loop){

    		double[] order = new double[len];
    		localOrder = 0.0;
    		allorder = 0.0;
    		
    		loopNum = loopNum + 1;
    		
	    	for(int i=0;i<len;i++){	    		
	    		double[] sinValue = new double[dimm]; 
    			double[] diss = new double[dimm]; 
    			double[] temp = new double[dimm];
    			
    			double dis = 0.0;
    			double kij = 0.0;
    			double allk = 0.0;
    			double move = 0.0;
    			
	    		int num = 0; double sita = 0.0; 
    			ArrayList diff = new ArrayList();
			
	    		for(int j=0;j<len;j++){	    			
	    			dis = 0.0; kij = 0.0; 
	    			for(int d=0;d<dimm;d++){
	    				//diss[d] = (Double)((ArrayList)(x.get(j))).get(d)-(Double)((ArrayList)(x.get(i))).get(d);
	    				diss[d] = (Double)((ArrayList)(prex.get(j))).get(d)-(Double)((ArrayList)(prex.get(i))).get(d);
	    				
	    			}
	    			
	    			dis = distance(diss);  
	    			//System.out.println(dis);
	    			
	    			if(dis < A){
	    				num = num + 1;
	    				//Calculating the coupling strength
		    			for(int d=0;d<dimm;d++){
		    				//temp[d] = (diss[d]+ 1e-10)/((Double)((ArrayList)(x.get(j))).get(d)+ 1e-10);
		    				temp[d] = (diss[d]+ 1e-10)/((Double)((ArrayList)(prex.get(j))).get(d)+ 1e-10);
		    			}	    	
		    			// Weighted coupling strength of each object
	    				//kij = Math.pow(distance(temp),1);
	    				//allk = allk + kij;	
	    				
		    			for(int d=0;d<dimm;d++){
		    				//sinValue[d] = sinValue[d] + kij*Math.sin(diss[d]);		 
		    				sinValue[d] = sinValue[d] + Math.sin(diss[d]);
		    			}	 
	    				sita = sita + Math.exp(-dis);
	    				move = move + dis;
	    			}
	    		}
	    		if(num > 1){
	    			for(int d=0;d<dimm;d++){
	    				double[] x1 = new double[dimm];
	    				//x1[d] = ((Double)((ArrayList)(x.get(i))).get(d))+ (myCluster.C*sinValue[d]+1e-10)/(allk+1e-10);
	    				//x1[d] = ((Double)((ArrayList)(prex.get(i))).get(d))+ (C*sinValue[d]+1e-10)/(allk+1e-10);
	    				//x1[d] = ((Double)((ArrayList)(x.get(i))).get(d))+ ((C/num)*sinValue[d]+1e-10);
	    				x1[d] = ((Double)((ArrayList)(prex.get(i))).get(d))+ ((C/num)*sinValue[d]);
		    			((ArrayList)(x.get(i))).set(d, x1[d]);    			
	    			}
	    			order[i] = sita/num;
	    			movRange[i] = movRange[i]+move;
	    		}
	    	}
	    	for(int k = 0; k < len; k++){
	    		allorder = allorder + order[k];	    		
	    	}
	    	//Local order parameter
	    	localOrder = allorder/len;
	    	rr[loopNum] = localOrder;
	    	
	    	//saveData(x, "synC"+String.valueOf(loopNum)+".txt");
	    	
	    	
	    	//System.out.println(Double.toString(localOrder));
	    	if( localOrder > 1 - (1e-2)|| loopNum >= 10){
	    		loop = false;
	    		//System.out.println("LOCAL ORDER PARAMETER:"+Double.toString(localOrder));
	    		//System.out.println("ALL LOOPS:"+Double.toString(loopNum));
	    	}
	    	
	    	// Save the previous value of the objects of the data set
	    	
	    	for(int i=0;i<len;i++){
	    		ArrayList temp1 = new ArrayList(dimm);    		
	    		for(int j=0;j<dimm;j++){
	    			temp1.add(((ArrayList)x.get(i)).get(j));
//	    			pp[i][loopNum] = (Double)((ArrayList)x.get(i)).get(j);
	    		}
				prex.set(i, temp1);
	    	}	   	
	    	
	    	
//	    	saveData(x, "synC.txt");
	    	//this.save1D(rr, "r.txt");
//	    	this.save2D(pp, "pp.txt");
    	}
    	
    	//System.out.println("Find the synchronization clusters...");
    	//int[] ids = findSynCluster(x);
    	clusterID[lp] = findSynCluster(x);
    	
    	double[] cc = synCMDL1(clusterID[lp], data);
    	
    	mdl[lp] = cc[0];
    	mdl_no[lp] = cc[1];
    	if(cc[0]<minMDL && nc>1){ 
    		minMDL = cc[0];
    		//save1D(ids, "synCID5.txt");
    		//saveData(x, "synC1.txt");
        	//save1D(movRange,"movR5.txt");		
    	}
    	//System.out.println("Coding cost =" + cc);   	
    	lp = lp + 1;

    }
    
    public void estimationP(double[][] data){
    	int num = data.length;
    	int dim = data[0].length;
    	
    	double[] h = findBandwidth(data,"plug_bump"); //plug_bump //plug_dirty
//    	for(int i=0;i<h.length;i++){
//    		System.out.println("Bandwidth dimension " + i + "; value = " + h[i]);
//    	}

////============ Test the fitness of the kernel density estimation=========    	
//   	    double[][] x = new double[128][128];
//   	    double[][] y = new double[128][128];
//   	    double[][] pv = new double[128][128]; 
//    	for(int i=0;i<dim;i++){
//        	double minV = Double.MAX_VALUE;
//        	double maxV = -Double.MAX_VALUE;
//    		for(int j=0;j<num;j++){
//    			if(data[j][i]>maxV) maxV = data[j][i];
//    			if(data[j][i]<minV) minV = data[j][i];
//    		}
//    		
//    		if(i==0){
//	    		for(int j=0;j<128;j++){
//	    			for(int k=0;k<128;k++){
//	    				x[j][k] = minV-0.25*(maxV-minV)+k*1.5*(maxV - minV)/128.0;   			
//	    			}
//	    		}
//    		}else{    			
//	    		for(int j=0;j<128;j++){
//	    			for(int k=0;k<128;k++){
//	    				y[j][k] = minV-0.25*(maxV-minV)+j*1.5*(maxV - minV)/128.0;   			
//	    			}
//	    		}
//    		}	
//    	}
//    	
//    	for(int i=0;i<128;i++){
//    		for(int j=0;j<128;j++){
//    			double[] xx = new double[2];
//    			xx[0] = x[i][j];
//    			xx[1] = y[i][j];
//    			pv[i][j] = kernel_estimation(data, xx, h);
//    		}
//    		//System.out.println("number id: " + i + " probability= " + pv[i]);
//    	}  	
//    	save2D(pv, "pValue.txt");
//    	save2D(x, "X.txt");
//    	save2D(y, "Y.txt");
////==================End==============================
    	
    	kernelP = new double[num];
    	double s = 0.0;
    	//double mp = -Double.MAX_VALUE;
    	for(int i= 0;i<num;i++){
    		kernelP[i] = kernel_estimation(data, data[i], h);
    		s = s + kernelP[i];
    		//if(kernelP[i]>mp) mp = kernelP[i];
//    		if(kernelP[i]>1){
//    		System.out.println("number id: " + i + " probability= " + kernelP[i]);
//    		//save2D(data,"ff.txt");
//    		}
    	}  	
    	//System.out.println("Sum probability: " + s);
    	for(int i= 0;i<num;i++){
    		kernelP[i] = kernelP[i]/s;
    		//kernelP[i] = kernelP[i]/mp;
    		//System.out.println("number id: " + i + " probability= " + kernelP[i]);
    	}
    	
    	
    	
    	
    }
    
    public double[] findBandwidth(double[][] data, String method){
    	double[] h = new double[data[0].length];
    	
    	if(method.equalsIgnoreCase("plug_dirty")){
	    	double[] stdp = std(data); 
	    	
	    	for(int i=0;i<data[0].length;i++){
//	    		System.out.println("===std dimension " + i + "; value = " + stdp[i]);
	    		//h[i] = 1.06*stdp[i]*Math.pow(data.length, -0.2);
	    		h[i] = Math.pow((4.0/(dim+2)),1.0/(dim+4))*stdp[i]*Math.pow(data.length, -1.0/(dim+4));
	    		//System.out.println("===Bandwidth dimension " + i + "; value = " + h[i]);
	    	}
    	}
    	if(method.equalsIgnoreCase("plug_bump")){
	    	double[] stdp = std(data); 
	    	double[] R = IQR(data);
	    	
	    	for(int i=0;i<data[0].length;i++){
//	    		System.out.println("===std dimension " + i + "; value = " + stdp[i]);
	    		double temp = Math.min(stdp[i], R[i]);
	    		//h[i] = 1.06*temp*Math.pow(data.length, -0.2);
	    		h[i] = Math.pow((4.0/(dim+2)),1.0/(dim+4))*temp*Math.pow(data.length, -1.0/(dim+4));
	    		//System.out.println("===Bandwidth dimension " + i + "; value = " + h[i]);
	    	}
    	}
    	
    	return h;
    }
    
    public double[] std(double[][] data){
    	double[] avg = new double[data[0].length];
    	double[] std = new double[data[0].length];
    	for(int i=0;i<data[0].length;i++){
    		avg[i] = 0;
    	}
    	
    	for(int j=0;j<data[0].length;j++){
    		for(int i=0;i<data.length;i++){    		
    			avg[j] = avg[j] + data[i][j];
    		}
    		avg[j] = avg[j]/data.length;
    		double s = 0.0;
    		for(int i=0;i<data.length;i++){    		
    			s = s + (data[i][j]-avg[j])*(data[i][j]-avg[j]);
    		}
    		std[j] = Math.sqrt(((s+0.0)/(data.length-1)));

    	}
    	
    	return std;
    }
    
    
    public double[] IQR(double[][] data){
    	
    	double[] IQR = new double[data[0].length];
    	double[][] tempd = new double[data.length][data[0].length];
    	
    	for(int j=0;j<data[0].length;j++){
    		for(int i=0;i<data.length;i++){  
    			tempd[i][j] = data[i][j];
    		}
    	}
    	
    	for(int j=0;j<data[0].length;j++){
    		for(int i=0;i<data.length;i++){  
    			for(int k=i+1;k<data.length;k++){
    				double temp = 0.0;
    				if(tempd[i][j]>tempd[k][j]){
    					temp = tempd[k][j];
    					tempd[k][j] = tempd[i][j];
    					tempd[i][j] = temp;
    				}
    			}  			
    		}
    		if(tempd.length>3)
    			IQR[j] = (tempd[(int)(tempd.length*0.75 + 0.5)][j] - tempd[(int)(tempd.length*0.25 + 0.5)][j])/(2*1.34);
    		else
    			IQR[j] = (tempd[1][j] - tempd[0][j])/(2*1.34);
    	}    	

    	return IQR;
    }
    
    
    public double kernel_estimation(double[][]data, double[] x, double[] h){
  
    	double sum = 0.0;    	
    	for(int i=0;i<data.length;i++){
    		double s = 1.0;
    		for(int j=0;j<data[0].length;j++){
    			if(h[j]!=0){
    				s = s* (1.0/h[j])*kernel((x[j]-data[i][j])/h[j]);
    			}else{
    				s = s* (1.0/data.length);
    			}
    		}
    		sum = sum + s;		
    	}   	
    	return sum/(data.length);
    	
    	
    	
    }
    
    public double kernel(double x){
    	
    	return (1.0/Math.sqrt(2*Math.PI))*Math.exp(-x*x/2.0);
    }

    public int[] findSynCluster(ArrayList x){
    	int len = x.size();
    	int[] id = new int[len];
    	int[] f = new int[len];
    	for(int i=0;i<len;i++){
    		id[i] = -1;
    		f[i] = 0;
    	}
    	ID = 0;
    	nf = 0;
    	for(int i=0;i<len;i++){
    		if(f[i]==0){   
    			//ID = ID + 1;
    			double[] diss = new double[dim];
    			int num  =0;
    			ArrayList al = new ArrayList();
	    		for(int j=0;j<len;j++){
	    			if(i!=j){
			    		for(int d=0;d<dim;d++){
			    			diss[d] = (Double)((ArrayList)(x.get(j))).get(d)-(Double)((ArrayList)(x.get(i))).get(d);			    			
			    		}
		    			double dis = distance(diss);
		    			//System.out.println("Distance:"+dis);
		    			if(Math.abs(dis)<(Math.sqrt(dim)*1e-2)){	   				    				
		    				num = num + 1;
		    				al.add(j);
		    			}	    			
//		    			if(num>0 && Math.abs(dis)<(Math.sqrt(dim)*1e-2)){
//		    				f[j] = 1;
//		    				id[j] = ID;	    				   						    			
//		    			}
	    			}
	    		}
	    		if(num>(len/50)){	    			
	    			f[i] = 1;
	    			for(int k=0;k<al.size();k++){
	    				f[(Integer)al.get(k)] = 1;
	    				id[(Integer)al.get(k)] = ID; 
	    			}
	    			id[i] = ID;
	    			ID = ID + 1;
	    		}else{
	    			nf = 1;
	    			if(num>0){
		    			for(int k=0;k<al.size();k++){
		    				//f[(Integer)al.get(k)] = 1;
		    				id[(Integer)al.get(k)] = -1; 
		    			}
	    			}
	    			id[i] = -1;
	    		}
    		}
    	}
    		
    	return id;
    	
    }
    
    public double log2(double x){
    	return Math.log(x)/Math.log(2);
    }

    public double synCMDL(int[] idx, double[][] data){
    	nc = ID;
    	if(nf==1){ // if there are outliers 
    		nc = ID + 1;
    	}
    	double cc = 0;  
    	int n = idx.length;
    	//System.out.println("Cluster Size: " + nc);
    	if(nc==1) f = 0;
    	int[] count = new int[nc];
    	for(int i=0;i<nc;i++){
    		count[i] = 0;
    	}
    	if(nf==1){
	    	for(int i=0;i<n;i++){
	    		for(int j=-1;j<=ID;j++){
	    			if(idx[i]==j){
	    				count[j+1] = count[j+1] + 1;
	    			}   				
	    		}
	    	}
    	}else{
	    	for(int i=0;i<n;i++){
	    		for(int j=0;j<=this.ID;j++){
	    			if(idx[i]==j){
	    				count[j] = count[j] + 1;
	    			}   				
	    		}
	    	}
    	}
    	
    	if(nf==1){
	    	for(int j=-1;j<=this.ID-1;j++){
	    		int[] cluster = new int[count[j+1]];
	    		double[][] cdata = new double[count[j+1]][dim];
	    		int nn = 0;
	    		for(int i=0;i<n;i++){    		
	    			if(idx[i]==j){
	    				for(int k=0;k<dim;k++){
	    					cdata[nn][k] = data[i][k];
	    				}
	    				cluster[nn]= i;
	    				nn = nn + 1;
	    			}   				
	    		}
	    		if(count[0]<2*(num/(double)nc)){ 
		    		double ccost = coding_cost(cluster, cdata);
		    		cc = cc+ccost; 		
		    		System.out.println("Coding for Cluster "+ j + "; Size: " + (nn) + "; Coding cost = " + ccost);
	    		}else{ //most objects are noise;
	    			return Double.MAX_VALUE; 
	    		}
	    	}
    	}else{
	    	for(int j=0;j<=this.ID-1;j++){
	    		int[] cluster = new int[count[j]];
	    		double[][] cdata = new double[count[j]][dim];
	    		int nn = 0;
	    		for(int i=0;i<n;i++){    		
	    			if(idx[i]==j){
	    				for(int k=0;k<dim;k++){
	    					cdata[nn][k] = data[i][k];
	    				}
	    				cluster[nn]= i;
	    				nn = nn + 1;
	    			}   				
	    		}
	    		
	    		double ccost = coding_cost(cluster, cdata);
	    		cc = cc+ccost; 		
	    		System.out.println("Coding for Cluster "+ j + "; Size: " + (nn) + "; Coding cost = " + ccost);
	    	}
    	}
    	
    	//===========Description complex term coding====================//
    	
//    	//========= 1. Number of clusters====
    	cc = cc + logstar2(nc);
//    	cc = cc + log2(nc);
//    	//cc = cc + Math.log(nc);
//    	//System.out.println("Coding cost for number of cluster is: " + log2(nc));
//    	//========= 2. Cluster Size
//    	for(int i=0;i<nc;i++){
//    		double ss = 0.0;
//    		for(int j=i;j<nc;j++){
//    			ss = ss + count[j];
//    		}
//    		cc = cc + log2(ss-nc+i+1);
//    	}
    	
    	System.out.println("Total Coding cost is: " + cc);
    	return cc;
    }
    
    public double[] synCMDL1(int[] idx, double[][] data){
    	nc = ID;
    	if(nf==1){ // if there are outliers 
    		nc = ID + 1;
    	}
    	double cc = 0;
    	double cc_no = 0;
    	int n = idx.length;
    	//System.out.println("Cluster Size: " + nc);
    	if(nc==1) f = 0;
    	int[] count = new int[nc];
    	for(int i=0;i<nc;i++){
    		count[i] = 0;
    	}
    	if(nf==1){
	    	for(int i=0;i<n;i++){
	    		for(int j=-1;j<=ID;j++){
	    			if(idx[i]==j){
	    				count[j+1] = count[j+1] + 1;
	    			}   				
	    		}
	    	}
    	}else{
	    	for(int i=0;i<n;i++){
	    		for(int j=0;j<=this.ID;j++){
	    			if(idx[i]==j){
	    				count[j] = count[j] + 1;
	    			}   				
	    		}
	    	}
    	}
    	
    	if(nf==1){
	    	for(int j=-1;j<=this.ID-1;j++){
	    		int[] cluster = new int[count[j+1]];
	    		double[][] cdata = new double[count[j+1]][dim];
	    		int nn = 0;
	    		for(int i=0;i<n;i++){    		
	    			if(idx[i]==j){
	    				for(int k=0;k<dim;k++){
	    					cdata[nn][k] = data[i][k];
	    				}
	    				cluster[nn]= i;
	    				nn = nn + 1;
	    			}   				
	    		}
//	    		if(count[0]<2*(num/(double)nc)){ 
		    		double ccost = coding_cost(cluster, cdata);
		    		cc = cc+ccost;
		    		if(j != -1){
		    			cc_no = cc_no+ccost;
		    		}
		    		System.out.println("Coding for Cluster "+ j + "; Size: " + (nn) + "; Coding cost = " + ccost);
//	    		}else{ //most objects are noise;
//	    			double[] max = new double [2];
//	    			max[0] = Double.MAX_VALUE;
//	    			max[1] = Double.MAX_VALUE;
//	    			return max; 
//	    		}
	    	}
    	}else{
	    	for(int j=0;j<=this.ID-1;j++){
	    		int[] cluster = new int[count[j]];
	    		double[][] cdata = new double[count[j]][dim];
	    		int nn = 0;
	    		for(int i=0;i<n;i++){    		
	    			if(idx[i]==j){
	    				for(int k=0;k<dim;k++){
	    					cdata[nn][k] = data[i][k];
	    				}
	    				cluster[nn]= i;
	    				nn = nn + 1;
	    			}   				
	    		}
	    		
	    		double ccost = coding_cost(cluster, cdata);
	    		cc = cc+ccost;
	    		cc_no = cc_no + ccost;
	    		System.out.println("Coding for Cluster "+ j + "; Size: " + (nn) + "; Coding cost = " + ccost);
	    	}
    	}
    	
    	//===========Description complex term coding====================//
    	
//    	//========= 1. Number of clusters====
    	cc = cc + logstar2(nc);
    	cc_no = cc_no + logstar2(nc);
//    	cc = cc + log2(nc);
//    	//cc = cc + Math.log(nc);
//    	//System.out.println("Coding cost for number of cluster is: " + log2(nc));
//    	//========= 2. Cluster Size
//    	for(int i=0;i<nc;i++){
//    		double ss = 0.0;
//    		for(int j=i;j<nc;j++){
//    			ss = ss + count[j];
//    		}
//    		cc = cc + log2(ss-nc+i+1);
//    	}
    	
    	System.out.println("Total Coding cost is: " + cc);
    	double[] codingcost = new double [2];
    	codingcost[0] = cc;
    	codingcost[1] = cc_no;
    	return codingcost;
    }
    
    public double coding_cost(int[] cluster, double[][] cdata){
    	double c = 0.0;
    	
    	if(cluster.length>1){
    		estimationP(cdata);
    		
	    	for(int i=0;i<cluster.length;i++){
	    		if((cluster.length)/(double)(num)>0.9){ // the extreme case: one cluster (with coding CLUSTER_ID: 1 )
	    			c = c + log2((double)(num)/(cluster.length)+1)+ log2(1.0/(kernelP[i])); 
	    		}else{
		    		c = c + log2((double)(num)/(cluster.length))+ log2(1.0/(kernelP[i])); 
		    		//c = c + Math.log((double)num/(cluster.length))+ Math.log(1.0/(kernelP[i]));
		    		//System.out.println("Data Object" + i + ", coding:" + log2(1.0/(kernelP[i])));
		    		//c = c + log2(1.0/(kernelP[i])); // Coding data
	    		}
	    	}
    	}else{
    		c = c + log2((double)num) + log2(2.0);
    		//c = Math.log((double)num) + Math.log(1.0);
    		//System.out.println("Data Object coding:" + c);
    		//c = log2(1.0);
    	}
    	
//    	if(cluster.length>1){
//    		
//    		
//	    	for(int i=0;i<cluster.length;i++){
//	    		//kernelP[cluster[i]] = kernelP[cluster[i]]/s;
//	    		c = c + log2((double)num/(cluster.length))+ log2(1.0/(kernelP[cluster[i]])); // Coding Cluster-id and data
//	    		//System.out.println("Data Object" + i + ", coding:" + log2(1.0/(kernelP[i])));
//	    		//c = c + log2(1.0/(kernelP[cluster[i]])); // Coding data
//	    	}
//    	}else{
//    		c = log2((double)num) + log2(1.0);
//    		//c = log2(1.0);
//    	}
    	
    	//c = c + log2((double)num/(cluster.length)); //Coding Cluster-id
    	
    	//c = c + Math.log((double)num/(cluster.length));
    	
    	//====parameter coding=======
    	double pc = ((dim)/2.0)*log2(cluster.length+1);
    	//double pc = (dim/2.0)*Math.log(cluster.length);    	
    	c = c + pc;
    	//System.out.println("Free-parameters' coding:" + pc);
    	return c;
    }
    
    public double logstar2(double x){
    	double l = 0.0;
    	while(x>1){
    		x = log2(x);
    		l = l + x;
    	}
    	return l;
    }
    public double dist(ArrayList al1, ArrayList al2){
    	double res = 0.0;
    	
    	if(al1.size()!=al2.size()) return 0.0;
    	else{
    		double[] diss = new double[al1.size()];
			for(int d=0;d<al1.size();d++){
				diss[d] = (Double)(al1.get(d))-(Double)(al2.get(d));		
			}
			res = distance(diss);
    	}
    	
    	return res;
    	
    }
    public double kNN(String fn, int k){
    	
    	  double res = 0.0;
    	 

    	  
    	  // check inputs for validity
    	  if(src.size() == 0 || k<=0) return 0.0; // bail on bad input
    	 
    	  for(int s=0;s<src.size();s++){  
    		  
        	  double[] d = new double[k];
        	  int n = 0; // number of element in the res
    		  
	    	  double dd = dist((ArrayList)src.get(s),(ArrayList)src.get(0)); // load first one into list
	    	  d[n++] = dd;
	    	 
	    	  // go through all other data points
	    	  for(int i = 1; i<src.size(); i++){
	    		dd = dist((ArrayList)src.get(s),(ArrayList)src.get(i));  
	    	    if( n<k || d[k-1] > dd){ //add one
	    	      if(n<k){
	    	    	  d[n++] = dd;
	    	      }
	    	      int j = n-1;
	    	      while(j>0 && dd < d[j-1]){ // slide big data up
	    	        d[j] = d[j-1]; 
	    	        j--;
	    	      }
	    	      d[j] = dd;
	    	    }
	    	  }
	    	  
	    	  res = res + d[k-1];
	    	  
    	  }
    	  return res/src.size();
    	}

    public void save1D(String[] data, String fn){
		int row = data.length;
		
	    try{
			FileOutputStream fout = new FileOutputStream(new File(fn)); 
			//fout.write(("Data ID\t Cluster ID").getBytes());
			//fout.write(("\r\n").getBytes());
			for(int i=0;i<row;i++){   
			fout.write(((String)(data[i])).getBytes());    
			fout.write(("\r\n").getBytes());   
			}   
	    } catch (IOException ex) {
	        ex.printStackTrace();
	    }    	
    }
    
    public double[] norm2(double[] data){
    	double[] ndata = new double [lp];
    	double min = Double.MAX_VALUE;
    	double max = -Double.MAX_VALUE;
    	
    	for(int i=0; i<lp; i++){
    		if( data[i] != Double.MAX_VALUE ){
    			if( data[i] > max){
    				max = data[i];
    			}
    			if( data[i] < min){
    				min = data[i];
    			}
    		}
    	}
    	for(int i=0; i<lp; i++){	
    		if( data[i] == Double.MAX_VALUE ){
    			ndata[i] = 1;
    		}
    		else{
    			ndata[i] = (data[i] - min)/(max - min); 
    		}
    	}
    	return ndata;
    }
    
    public double[] norm3(double[] data){
    	double[] ndata = new double [lp];
    	double min = Double.MAX_VALUE;
    	double max = -Double.MAX_VALUE;
    	
    	for(int i=0; i<lp; i++){
    		if( data[i] != Double.MAX_VALUE ){
    			if( data[i] > max){
    				max = data[i];
    			}
    			if( data[i] < min){
    				min = data[i];
    			}
    		}
    	}
    	for(int i=0; i<lp; i++){	
    		if( data[i] == Double.MAX_VALUE ){
    			ndata[i] = max;
    		}
    		else{
    			ndata[i] = data[i];
    		}
    	}
    	return ndata;
    }
    
    public double[] CalcGradient(double[] nmdl, double[] nk){
    	double[] grad = new double [lp];
    	for(int i=0; i<lp-1; i++){
    		if( nmdl[i] == 1){
    			grad[i] = 1;
    		}
    		else{
    			grad[i] = Math.abs(nmdl[i] - nmdl[i+1])/Math.abs(nk[i] - nk[i+1]);
    		}
    	}

    	return grad;
    }
    
    public void findHier(double[] mdl, double[] k){
    	String index = "";
    	int num = 0;
    	int flag = 0;
    	int tmpnum = 0;
    	double[] nmdl = norm2(mdl);
    	double[] nk = norm2(k);
    	int[] KeyMdlIndex = new int [lp-2];
    	
    	double[] gradient = CalcGradient(nmdl, nk);
    	
    	for(int i=1; i<lp-1; i++){
    		if (Math.atan(gradient[i]) < Math.PI/12){
    			if( tmpnum == 0){
    				flag = i; 				
    			}
    			tmpnum ++;
    		}
    		else{
    			if( (tmpnum >1 && tmpnum > lp/20) || tmpnum >3){
    				KeyMdlIndex[num++] = flag + tmpnum/2;				
    			}
    			tmpnum = 0;
    			flag = 0;
    		}
    	}
    	KeyMdlIndex[num++] = lp-1;
    	
//    	for(int i=1; i<lp-1; i++){
//    		if (Math.atan(gradient[i]) > Math.PI/9){    				
//    			if (num == 0)
//    				KeyMdlIndex[num++] = i;
//    			else if (i > KeyMdlIndex[num-1] + lp/10)
//    				KeyMdlIndex[num++] = i;
//    		}
//    	}
//    	KeyMdlIndex[num++] = lp;
    	
//    	int tmp = 0;
//    	for(int i=1; i<lp-1; i++){
//    		if(Math.abs(nmdl[i] - nmdl[i-1]) < 0.01){
//    			tmp ++;
//    		}
//    		else{
//    			tmp = 0;
//    		}
//    		
//		   	if((tmp > lp/10) && (nmdl[i] != 1)){
//		   		if( num == 0 ){
//			   		KeyMdlIndex[num++] = i;
//			   		tmp = 0;
//		   		}
//		   		else if (Math.abs(nmdl[i] - nmdl[KeyMdlIndex[num-1]]) > 0.01){
//			   		KeyMdlIndex[num++] = i;
//			   		tmp = 0;
//		   		}
//		   	}
//    	}
//    	KeyMdlIndex[num++] = lp-1;
    	
    	int[] SynCID = new int [num];
    	double[] SynCK = new double [num];
    	String[] strSynCID = new String [num];
    	
    	for(int i=0; i<num; i++){
    		int temp = KeyMdlIndex[i];
    		//int temp = (KeyMdlIndex[i+1] + KeyMdlIndex[i])/2;
    		index = String.valueOf(temp);
    		SynCID[i] = temp;
    		SynCK[i] = k[temp];
    		strSynCID[i] = "E:/Document/workplace/SynCluster/synCID"+testindex+index+".txt";
    		save1D(clusterID[temp], "synCID"+testindex+index+".txt");
    	}
    	
    	save1D(norm3(mdl),"mdl"+testindex+".txt");
    	save1D(norm3(k),"params"+testindex+".txt");
    	save1D(SynCK, "keymdlK"+testindex+".txt");
    	save1D(SynCID, "keymdlid"+testindex+".txt");
    	save1D(strSynCID,"keymdl"+testindex+".txt");
    }
    
    /**
     * main function - Dynamical clustering
     */
    public static void main(String[] args) {
    	
    	long   start   =   System.currentTimeMillis();
    	Test myCluster = new Test();
    	//myCluster.testindex = "200";
    	//String fn = "Hier"+myCluster.testindex+".txt"; ///wisconsin.txt //diabetes.txt //outliers
    	String fn = "dataset2.txt";
    	myCluster.loadData(fn);
    	myCluster.movRange = new double [myCluster.src.size()];
    	myCluster.clusterID = new int [loopnum][myCluster.src.size()];
    	
    	//myCluster.estimationP(myCluster.data); // Test
    	
    	//====Normalize the data to [0 1]
    	myCluster.norm(myCluster.src);
    	double K0 = myCluster.kNN(fn,1);
    	double K1 = myCluster.kNN(fn,2);

    	double K2 = myCluster.kNN(fn,3);
    	double K3 = myCluster.kNN(fn,4);
    	double K4 = myCluster.kNN(fn,5);
    	double K5 = myCluster.kNN(fn,6);
//    	double K6 = myCluster.kNN(fn,7);
//    	double K7 = myCluster.kNN(fn,8);
//    	double K8 = myCluster.kNN(fn,9);
//    	double K9 = myCluster.kNN(fn,10);
    	
//    	double delta = 0.0005*6;
//    	System.out.println("delta = " + delta);
    	
    	myCluster.f = 1;
    	double K = 0;
    	double[] kk = new double[loopnum];
    	//int n = 0;
    	while(myCluster.f==1 && myCluster.lp<loopnum){
    		//K = K + 0.001;
    		//K = (K1-K0)*(myCluster.lp+1)*2;
    		//K = 0.001 + K + delta*myCluster.lp; //Hier1.txt
    		//K = 0.05 + 0.01*myCluster.lp; //Hier2.txt
    		//K = 0.005 + (K5-K1)*myCluster.lp; //Hier3.txt
    		K = 0.05+0.025*myCluster.lp;
    		kk[myCluster.lp]=K;
    		System.out.println("=============Perform the clustering on K = " + K +" ============");
    		System.out.println("=============Perform the clustering on lp = " + myCluster.lp +" ============");    		
    		myCluster.setParams(fn,K);	    	
	    	myCluster.cluster();
    	}
    	myCluster.findHier(myCluster.mdl, kk);
    	//myCluster.save1D(myCluster.mdl, "mdl.txt");
    	//myCluster.save1D(myCluster.mdl_no, "mdl_no.txt");
    	//myCluster.save1D(kk, "params5.txt");
  	  	long   end   =   System.currentTimeMillis(); 
  	  	System.out.println("Minimum Coding Cost:"+ Double.toString(myCluster.minMDL)); 
  	  	System.out.println("All running time:"+Long.toString((end-start)/1000)+" s.");      
  	  	System.out.println("Ending");	
    }
}
