package de.lmu.database;

import java.io.*;
import java.util.Map;
import java.util.Iterator;
import java.util.ArrayList;
import com.jmatio.io.MatFileReader;
import com.jmatio.types.*;


/**
 * Read the matrix data (.mat) from matlab
 * 
 * @author Junming Shao
 * @param None
 * Created on 17. Mar. 2009, 
 */


public class SaveData {
   
    /** Creates a new instance of ReadMat
     * @param none
     */
    public SaveData() {

    }
	/**
	 * save the 2-D DATA
	 * @param 2-D data (result)
	 * @param String fn (filename)
	 * @return none
	 */
	public void save2D(double[][] data, String fn){
	    
		int row = data.length;
		int col = data[0].length;
		
	    try{
			FileOutputStream fout = new FileOutputStream(new File(fn));     
			for(int i=0;i<row;i++){   
				for(int j=0; j<col;j++){   
					fout.write(((Double)(data[i][j])+"\t").getBytes());   
				}   
			fout.write(("\r\n").getBytes());   
			}   
	    } catch (IOException ex) {
	        ex.printStackTrace();
	    }    		
	}
	public void save2D(int[][] data, String fn){
	    
		int row = data.length;
		int col = data[0].length;
		
	    try{
			FileOutputStream fout = new FileOutputStream(new File(fn)); 
			//fout.write(("Data ID\t Cluster ID").getBytes());
			//fout.write(("\r\n").getBytes());
			for(int i=0;i<row;i++){   
				for(int j=0; j<col;j++){   
					fout.write(((Integer)(data[i][j])+"\t").getBytes());   
				}   
			fout.write(("\r\n").getBytes());   
			}   
	    } catch (IOException ex) {
	        ex.printStackTrace();
	    }    		
	}		
	
	public void save1D(int[] data, String fn){
	    
		int row = data.length;
		
	    try{
			FileOutputStream fout = new FileOutputStream(new File(fn)); 
			//fout.write(("Data ID\t Cluster ID").getBytes());
			//fout.write(("\r\n").getBytes());
			for(int i=0;i<row;i++){   
			fout.write(((Integer)(data[i])+"\t").getBytes());    
			fout.write(("\r\n").getBytes());   
			}   
	    } catch (IOException ex) {
	        ex.printStackTrace();
	    }    		
	}	
}