package de.lmu.database;

import weka.core.*;
import java.io.*;
import java.util.*;


/*
 * DataObject.java
 *
 *
 */

/**
 *
 * @author  Claudia
 *
 */


/**Class DataObject for creating data objects and computing the Manhattan Distance between them.*/

public class DataObject{
    /**coordinates*/
    public double[] coord;
    /**dimensionality*/
    
    public int clusterID;
    
    public int classID;
    
    public int number;    //numerierung der Datenobjekte mit 0 beginnend wie eingelesen
    
    public int[] dimensions;
    
    
    
    
    /** Creates a new instance of data object.
     * @param k the coordinates of the new data object.
     * @param d the dimensionality of the new data object.
     */
    public DataObject(double[] k, int num) {
        this.coord = k;
        this.number = num;
        this.clusterID = 0;
    }

    public DataObject(int number, int[] dimensions) {
        this.number = number;
        this.dimensions = dimensions;
    }

    public DataObject(int number, double[] coord, int[] dimensions) {
        this.coord = coord;
        this.number = number;
        this.dimensions = dimensions;
    }
    
    
    
    
    
   
    public DataObject(DataObject d){
        this.coord = d.coord;
        this.clusterID = d.clusterID;
        this.classID = d.classID;
        this.number = d.number;
    }
    
    public DataObject(double[] k, int num, int classID) {
        this.classID = classID;
        this.coord = k;
        this.number = num;
        this.clusterID = 0;
    }
    
    public DataObject(double[] k, int num, int classID, int clusterID) {
        this.classID = classID;
        this.clusterID = clusterID;
        this.coord = k;
        this.number = num;
    }
    
    public DataObject(Instance inst){
        coord = new double[inst.numAttributes()-1];
        for(int i = 0; i < coord.length; i++)
            coord[i] = inst.value(i);
    }
   
    
    /**
     * Creates a subspace object of d with coordinates specified in coord.
     * @param d DataObject
     * @param coord coordinates for subspace object
     */
    public DataObject(DataObject d, int[]coord){
        this.classID = d.classID;
        this.clusterID = d.clusterID;
        this.number = d.number;
        this.coord = new double[coord.length];
        for(int i = 0; i < coord.length; i++)
            this.coord[i] = d.coord[coord[i]];
    }
    
    public DataObject(double[] k){
        this.coord = k;
    }
    
    public DataObject(int dim){
        coord = new double[dim];
    }
    
    /**Returns the coordinates of this data object.*/
    public double[] getCoord(){
        return this.coord;
    }
    
     public String getObjectInfo(){
        StringBuffer sb = new StringBuffer();
        sb.append("<html> data object: " + number + "<br> coordinates: (");
        for(int i = 0; i < coord.length-1; i++)
            sb.append(coord[i] + ", ");
        sb.append(coord[coord.length-1] + ") <br>");
        sb.append("classID " + classID + "<br>");
        sb.append("clusterID " + clusterID + "<br>");
        sb.append("</font>");
        sb.append("</html>");
        return sb.toString();
    }
     
     public String getSubspaceInfo(){
          StringBuffer sb = new StringBuffer();
        sb.append("<html> data object: " + number + "<br> dimensions: (");
        for(int i = 0; i < dimensions.length-1; i++)
            sb.append(dimensions[i] + ", ");
        sb.append(dimensions[dimensions.length-1] + ") <br>");
        sb.append("clusterID " + clusterID + "<br>");
        sb.append("</font>");
        sb.append("</html>");
        return sb.toString();
     }
    
    public double distance(double[] mean){
        double sum = 0.0;
        for (int i = 0; i < coord.length; i++){
            double dist = ((coord[i] - mean[i])*(coord[i] - mean[i]));
            sum = sum + dist;
        }
        return Math.sqrt(sum);
    }
    
    
    
    /**Computes the Manhattan-Distance in respect to data object b.
     * @param b the data object to which the distance should be computed.
     */
    public double manhattanDistance(DataObject b) {
        DataObject other = b;
        DataObject thisDo = this;
        double sum = 0.0;
        for (int i = 0; i < b.coord.length; i++){
            double dist = Math.abs((other.coord[i] - thisDo.coord[i]));
            sum = sum + dist;
        }
        return sum;
    }
    
    public double distance(DataObject b) {
        DataObject other = b;
        DataObject thisDo = this;
        double sum = 0.0;
        for (int i = 0; i < b.coord.length; i++){
            double dist = ((other.coord[i] - thisDo.coord[i])*(other.coord[i] - thisDo.coord[i]));
            sum = sum + dist;
        }
        return Math.sqrt(sum);
    }
    
    
    
}


