package de.lmu.database;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class Generator {
	
    private static Random RANDOM = new Random();
    private static String DIRECTORY="E:/Document/workplace/SynCluster/";

    public static List<Double[]> randomGauss(int corrDim, int dataDim, Random random) {
        if (corrDim > dataDim || corrDim < 1 || dataDim < 1) {
            throw new IllegalArgumentException("Illegal arguments: corrDim=" + corrDim + " - dataDim=" + dataDim + ".");
        }

        double multiplier = 1000;
        List<Double[]> gauss = new ArrayList<Double[]>(corrDim);
        for (int i = 0; i < corrDim; i++) {
            Double[] coefficients = new Double[dataDim + 1];
            for (int d = 0; d < coefficients.length; d++) {
                coefficients[d] = random.nextDouble();
                if (d == dataDim) {
                    coefficients[d] *= corrDim * multiplier;
                }
            }
            gauss.add(coefficients);
        }
        return gauss;
    }

   public static void clusterSize(int dataDim, int minSize, int increment, int steps) {
        try {
            for (int i = 0; i < steps; i++) {
                int size = minSize + i * increment;
                File output = new File(DIRECTORY + (size / 1000) + "_T_" + dataDim + ".txt");
                output.getParentFile().mkdirs();
                OutputStreamWriter out = new OutputStreamWriter(new FileOutputStream(output));
                //final double[] radii = new double[]{2.0, 5.0, 10.0, 15.0, 20.0};
                //final double[] radii = new double[]{5.0, 5.0, 5.0, 5.0, 5.0}; //dim 5
                //final double[] radii = new double[]{5.0, 5.0, 5.0, 5.0}; //dim10
                final double[] radii = new double[]{15.0, 15.0, 15.0, 15.0,15.0}; //dim40
                generateClusters(size, dataDim, radii, 0.0, true, 0, 100, out);           
              //generateRandom(size, dataDim, 0.0, 100.0, out);
                out.flush();
                out.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private static void generateNoise(int noPoints, double[] minima, double[] maxima, String label, OutputStreamWriter out) throws IOException {

        if (minima.length != maxima.length) {
            throw new IllegalArgumentException("minima.length != maxima.length");
        }

        int dim = minima.length;
        for (int i = 0; i < noPoints; i++) {
            double[] values = new double[dim];
            for (int d = 0; d < dim; d++) {
                values[d] = RANDOM.nextDouble() * (maxima[d] - minima[d]) + minima[d];
                out.write(values[d] + " ");
            }
            out.write(label + "\n");
        }
    }

    private static void generateClusters(int noPoints, int dim, double[] radii,
            double noisePct, boolean overlap,
            double min, double max, OutputStreamWriter out) throws IOException {

        Double[][] featureVectors = new Double[noPoints][dim];
        String[] labels = new String[noPoints];

        // number of clusters
        int noCluster = radii.length;
        System.out.println("noCluster " + noCluster);

        // noNoise of points in each cluster
        int pointsPerCluster = (int) ((1.0 - noisePct) * noPoints / noCluster);
        System.out.println("pointsPerCluster " + pointsPerCluster);

        // number of noise points
        int noNoise = noPoints - noCluster * pointsPerCluster;
        System.out.println("noNoise " + noNoise);

        // determine centroids of clusters
        List<Double[]> centroids = new ArrayList<Double[]>();
        for (int c = 0; c < noCluster; c++) {
            Double[] centroid = new Double[dim];
            for (int d = 0; d < dim; d++) {
                centroid[d] = radii[c] + ((max - min) - 2.0 * radii[c]) * RANDOM.nextDouble();
            }

            boolean ok = true;
            if (!overlap) {
                for (int j = 0; j < c; j++) {
                    Double[] otherCenter = centroids.get(j);
                    double l = 0;
                    for (int a = 0; a < dim; a++) {
                        l += (centroid[a] - otherCenter[a]) * (centroid[a] - otherCenter[a]);
                    }
                    l = Math.sqrt(l);
                    if (l <= radii[c] + radii[j]) {
                        ok = false;
                        break;
                    }
                }
            }
            if (ok) {
                System.out.println("center " + c + " ok");
                centroids.add(centroid);
            } else {
                c--;
            }
        }
        System.out.println("all center ok");

        // create clusters
        int n = 0;
        for (int c = 0; c < noCluster; c++) {
            for (int j = 0; j < pointsPerCluster; j++) {
                Double[] featureVector = new Double[dim];

                double l = 0;
                for (int d = 0; d < dim; d++) {
                    Double[] centroid = centroids.get(c);
                    double value = centroid[d] +
                            (2.0 * RANDOM.nextDouble() - 1.0) * radii[c];
                    featureVector[d] = value;

                    l += (centroid[d] - value) * (centroid[d] - value);
                }
                l = Math.sqrt(l);
                //System.out.println(l);
                if (overlap || l <= radii[c]) {
                    featureVectors[n++] = featureVector;
                    labels[n - 1] = "cluster_" + c;
                    //System.out.println("Cluster " + (c + 1) + " ok");
                } else {
                    j--;
                }
            }
            System.out.println("Cluster " + (c + 1) + " ok");
        }

        // create noise
        for (int i = 0; i < noNoise; i++) {
            Double[] featureVector = new Double[dim];

            for (int d = 0; d < dim; d++) {
                featureVector[d] = (max - min) * RANDOM.nextDouble();
            }

            featureVectors[n++] = featureVector;
            labels[n - 1] = "noise";
        }

        /*
        Double[] minVector = new Double[dim];
        for (int d = 0; d < dim; d++) {
        minVector[d] = min;
        }
        featureVectors[n++] = minVector;

        Double[] maxVector = new Double[dim];
        for (int d = 0; d < dim; d++) {
        maxVector[d] = max;
        }
        featureVectors[n++] = maxVector;
         */

        // write to out
        for (n = 0; n < noPoints; n++) {
            for (int d = 0; d < dim; d++) {
                out.write(featureVectors[n][d] + " ");
            }
            out.write(labels[n] + "\n");
        }
    }

    private static void generateRandom(int noPoints, int dim, double min, double max,
            OutputStreamWriter out) throws IOException {

        Double[][] featureVectors = new Double[noPoints][dim];

        Double[] minVector = new Double[dim];
        for (int d = 0; d < dim; d++) {
            minVector[d] = min;
        }
        featureVectors[0] = minVector;

        Double[] maxVector = new Double[dim];
        for (int d = 0; d < dim; d++) {
            maxVector[d] = max;
        }
        featureVectors[1] = maxVector;

        for (int n = 2; n < noPoints; n++) {
            Double[] featureVector = new Double[dim];
            for (int d = 0; d < dim; d++) {
                featureVector[d] = RANDOM.nextDouble() * (max - min) + min;
            }

            featureVectors[n] = featureVector;
        }

        // write to out
        for (int n = 0; n < noPoints; n++) {
            for (int d = 0; d < dim; d++) {
                if (d < dim - 1) {
                    out.write(featureVectors[n][d] + " ");
                } else {
                    out.write(featureVectors[n][d] + "\n");
                }
            }
        }
    }
    
    public static void main(String[] args) {

        clusterSize(40, 1000, 0, 1);
   }
}
