package de.lmu.database;

/**
 * @author  Junming Shao
 */

public class CurveObject{
    
    public double[][] data; //data matrix 
    public int ID; //Object ID
    public int dim; //dimensionality   
    public int num; //the number of points on the curve
    public int clusterID;  //Cluster ID 
    
    // for optics
    public boolean clustered; //Clustering status
    public double reachDist;
    public double coreDist;
    public double infoGain;
    /** Creates a new instance of curve object.
     * 
     * @param data the data of the curve object.
     * 
     * @return A Curve Object
     */
    public CurveObject(double[][] data) {
        this.data = data;
        this.ID = 0;
        this.dim = data[0].length;
        this.num = data.length;
        this.clusterID = 0;
        this.clusterID = 0;
        this.infoGain = 0;
        this.coreDist = Double.MAX_VALUE;
        this.reachDist = Double.MAX_VALUE;
    }
    /** Creates a new instance of curve object.
     * 
     * @param data the data of the curve object.
     * @param ID the ID of the curve object.
     * 
     * @return A Curve Object
     */
    public CurveObject(double[][] data, int ID) {
        this.data = data;
        this.ID = ID;
        this.dim = data[0].length;
        this.num = data.length;
        this.clusterID = 0;
        this.infoGain = 0;
        this.clustered = false;
        this.coreDist = Double.MAX_VALUE;
        this.reachDist = Double.MAX_VALUE;
    }    
    /** Creates a new instance of curve object.
     * 
     * @param CurveObject the curve object.
     * 
     * @return A Curve Object
     */
    public CurveObject(CurveObject c) {
        this.data = c.data;
        this.ID = c.ID;
        this.dim = c.dim;
        this.num = c.num;
        this.clusterID = c.clusterID;
        this.infoGain = c.infoGain;
        this.clustered = c.clustered;
        this.coreDist = c.coreDist;
        this.reachDist = c.reachDist;
    }    
        
    /** Creates a new instance of curve object.
     * 
     * @param data the data of the curve object.
     * @param dim the dimensionality of the points of Curve.
     * @param num the number of the points of Curve.
     * 
     * @return A Curve Object
     */
    public CurveObject() {

    }
    
    /** Returns the data of this Curve object.
     *  
     * @return A Curve Object
     */
    public double[][] getData(){
        return this.data;
    }
    
    /** Returns the dimensionality of points on this Curve object.
     *  
     * @return int dimensionality
     */
    public int getDim(){
        return this.dim;
    } 
    
    /** Returns the number of points on this Curve object.
     *  
     * @return int number
     */
    public int getNum(){
        return this.num;
    }     
    
    /** Returns the cluster ID of this Curve object.
     *  
     * @return int Cluster ID
     */
    public int getClusterID(){
        return this.clusterID;
    }        
    /** set the clustering status of for this Curve object.
     *  
     * @return none
     */
    public boolean getClustered(){
    	return this.clustered;
    } 
            
    
    /** Set the data for this Curve object.
     *  
     * @return A Curve Object
     */
    public void setData(double[][] data){
        this.data = data;
    }
    
    /** Set the dimensionality of points on this Curve object.
     *  
     * @return none
     */
    public void setDim(int dim){
        this.dim = dim;
    } 
    
    /** Set the number of points for this Curve object.
     *  
     * @return none
     */
    public void setNum(int num){
        this.num = num;
    }     
    
    /** set the cluster ID for this Curve object.
     *  
     * @return none
     */
    public void setClusterID(int clusterID){
        this.clusterID = clusterID;
    } 
    
    
    /** set the clustering status of for this Curve object.
     *  
     * @return none
     */
    public void setClustered(boolean clustered){
        this.clustered = clustered;
    } 
        
    /** Returns the description of this Curve object.
     *  
     * @return String description [HTML FORMAT]
     */
     public String getDescription(){
        StringBuffer sb = new StringBuffer();
        sb.append("<HTML>");
        sb.append("Curve includes points: " + this.num + "<BR>");
        sb.append("Point dimensionality:" + this.dim + "<BR>");
        sb.append("Cluster ID: " + this.clusterID + "<BR>");
        sb.append("ID:" + this.ID + "<BR>");
        sb.append("</HTML>");
        return sb.toString();
    }     
}


